"""Create a separate preview database containing fictional data only."""
import os
from datetime import date, datetime, timedelta
from pathlib import Path

os.environ["CLINOVA_DATABASE_PATH"] = str(Path(__file__).parent / "demo_preview.db")

import models
import pharmacy_models
import billing_models
import appointments_models
import radiology_models
from auth import hash_password
from database import Base, engine, SessionLocal
from models import Clinic, Patient, User, Visit
from pharmacy_models import Medicine
from pharmacy_service import create_order, dispense_order, receive_stock


def seed():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        if db.query(Clinic).first():
            print("Preview database already exists; kept existing demo data.")
            return
        clinic = Clinic(name="عيادة كلينوفا التجريبية", phone="0000000000", address="بيانات وهمية للعرض فقط")
        db.add(clinic); db.flush()
        admin = User(clinic_id=clinic.id, username="demo", full_name="حساب العرض التجريبي", role="admin",
                     password_hash=hash_password("DemoClinic2026!"), is_active=True)
        db.add(admin); db.flush()
        for username, role in [("demo_doctor", "doctor"), ("demo_pharmacist", "pharmacist")]:
            db.add(User(clinic_id=clinic.id, username=username, role=role, full_name="حساب تجريبي",
                        password_hash=hash_password("DemoClinic2026!"), is_active=True))
        patients = [Patient(clinic_id=clinic.id, medical_number=f"DEMO-{i:03d}",
                            full_name=name, gender=gender, birth_date=date(1990+i, 3, 15),
                            phone="0000000000", notes="مريض وهمي لتجربة الموقع")
                    for i, (name, gender) in enumerate([
                        ("أحمد الاختباري", "ذكر"), ("مريم التجريبية", "أنثى"), ("سارة الافتراضية", "أنثى")], 1)]
        db.add_all(patients)
        medicines = [Medicine(clinic_id=clinic.id, code=code, name=name, generic_name=generic,
                              strength=strength, unit=unit, sale_price=price, minimum_stock=minimum)
                     for code, name, generic, strength, unit, price, minimum in [
                         ("MED-001", "باراسيتامول", "Paracetamol", "500mg أقراص", "قرص", 2.5, 30),
                         ("MED-002", "محلول إماهة فموي", "Oral rehydration salts", "أكياس", "كيس", 8, 10),
                         ("MED-003", "سيتريزين", "Cetirizine", "10mg أقراص", "قرص", 3, 20),
                         ("MED-004", "مستحضر تجريبي", "Demo stock", "للعرض فقط", "عبوة", 20, 5)]]
        db.add_all(medicines); db.commit()
        for i, medicine in enumerate(medicines):
            receive_stock(db, clinic.id, admin.id, medicine.id, f"DEMO-B{i+1}",
                          date.today()+timedelta(days=50 if i==1 else 400),
                          [180, 8, 65, 0][i] or 1, purchase_price=1, supplier="مورد تجريبي")
        first = create_order(db, clinic.id, admin.id, patients[0].id, None,
                             [{"medicine_id": medicines[0].id, "quantity": 12, "instructions": "بند تجريبي لعرض الصرف والفاتورة"}],
                             diagnosis="مثال لعرض النظام، لا يمثل وصفة علاجية")
        dispense_order(db, first.id, clinic.id, admin.id)
        create_order(db, clinic.id, admin.id, patients[1].id, None,
                     [{"medicine_id": medicines[1].id, "quantity": 3}], diagnosis="بيانات تجريبية لمراجعة الصرف")
        db.add(Visit(clinic_id=clinic.id, patient_id=patients[2].id, visit_date=datetime.now(),
                     diagnosis="زيارة تجريبية", prescription="وصفة نصية قديمة تحتاج مراجعة الأصناف والكميات"))
        db.commit()
        print("Demo preview created. All patient and stock data are fictional.")


if __name__ == "__main__":
    seed()
