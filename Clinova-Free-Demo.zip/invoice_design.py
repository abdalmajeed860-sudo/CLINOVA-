from pathlib import Path

from fastapi.responses import HTMLResponse
from jinja2 import Environment, FileSystemLoader, select_autoescape

from auth import has_permission
from models import Clinic
from pharmacy_models import PharmacyOrder

templates = Environment(loader=FileSystemLoader(Path(__file__).parent / "templates"),
                        autoescape=select_autoescape(["html"]))
templates.filters["money"] = lambda value: f"{float(value or 0):,.2f}"


def render_invoice(request, db, invoice, print_mode=False):
    clinic = db.query(Clinic).filter_by(id=request.state.billing_clinic_id).first()
    order = db.query(PharmacyOrder).filter_by(invoice_id=invoice.id,
        clinic_id=request.state.billing_clinic_id).first()
    return HTMLResponse(templates.get_template("invoice.html").render(
        invoice=invoice, patient=invoice.patient, clinic=clinic, order=order, print_mode=print_mode,
        can_pay=has_permission(request, db, "billing", "full")))
