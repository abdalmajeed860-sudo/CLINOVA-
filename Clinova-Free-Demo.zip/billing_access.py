"""Shared authorization and clinic boundaries for all billing endpoints."""
from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from auth import get_current_user, has_permission
from billing_models import Invoice
from database import get_db
from models import Patient


async def require_billing(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    writes = request.method != "GET" or request.url.path.endswith(("/new", "/payment"))
    if not user or not has_permission(request, db, "billing", "full" if writes else "view"):
        raise HTTPException(403, "ليس لديك صلاحية لهذا الإجراء في الفواتير")
    if not user.clinic_id:
        raise HTTPException(403, "الحساب غير مرتبط بمنشأة طبية")
    request.state.billing_user = user
    request.state.billing_clinic_id = user.clinic_id
    invoice_id = request.path_params.get("invoice_id")
    if invoice_id is not None:
        try:
            invoice_id = int(invoice_id)
        except ValueError:
            raise HTTPException(404, "الفاتورة غير موجودة")
        invoice = db.query(Invoice).join(Patient, Patient.id == Invoice.patient_id).filter(
            Invoice.id == invoice_id, Patient.clinic_id == user.clinic_id).first()
        if not invoice:
            raise HTTPException(404, "الفاتورة غير موجودة في المنشأة الحالية")
    if request.method == "POST" and request.url.path == "/billing/create":
        form = await request.form()
        try:
            patient_id = int(form.get("patient_id", ""))
        except (TypeError, ValueError):
            raise HTTPException(400, "اختر المريض")
        if not db.query(Patient.id).filter_by(id=patient_id, clinic_id=user.clinic_id).first():
            raise HTTPException(404, "المريض غير موجود في المنشأة الحالية")


def invoice_query(db, clinic_id):
    return db.query(Invoice).join(Patient, Patient.id == Invoice.patient_id).filter(Patient.clinic_id == clinic_id)
