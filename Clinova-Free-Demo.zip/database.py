# ============================================================
# CLINOVA
# database.py
# إدارة قاعدة البيانات
# ============================================================

from pathlib import Path
import os

from sqlalchemy import (
    create_engine,
    inspect,
    text,
)

from sqlalchemy.orm import (
    sessionmaker,
    declarative_base,
)


# ============================================================
# مسار المشروع
# ============================================================

BASE_DIR = Path(__file__).resolve().parent


# ============================================================
# قاعدة البيانات
# ============================================================

DATABASE_FILE = Path(os.environ.get("CLINOVA_DATABASE_PATH", str(BASE_DIR / "clinic.db")))

DATABASE_URL = f"sqlite:///{DATABASE_FILE}"


# ============================================================
# Engine
# ============================================================

engine = create_engine(
    DATABASE_URL,
    connect_args={
        "check_same_thread": False,
    },
)


# ============================================================
# Session
# ============================================================

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)


# ============================================================
# Base
# ============================================================

Base = declarative_base()


# ============================================================
# الحصول على Session
# ============================================================

def get_db():

    db = SessionLocal()

    try:
        yield db

    finally:
        db.close()


# ============================================================
# التحقق من وجود جدول
# ============================================================

def table_exists(table_name):

    inspector = inspect(engine)

    try:

        tables = inspector.get_table_names()

        return table_name in tables

    except Exception:

        return False


# ============================================================
# التحقق من وجود عمود
# ============================================================

def column_exists(
    table_name,
    column_name,
):

    if not table_exists(table_name):
        return False

    inspector = inspect(engine)

    try:

        columns = inspector.get_columns(
            table_name,
        )

    except Exception:

        return False

    return any(
        column["name"] == column_name
        for column in columns
    )


# ============================================================
# إضافة عمود إذا لم يكن موجودًا
# ============================================================

def add_column_if_missing(
    table_name,
    column_name,
    column_definition,
):

    if not table_exists(table_name):
        return False

    if column_exists(
        table_name,
        column_name,
    ):
        return False

    with engine.begin() as connection:

        connection.execute(
            text(
                f"""
                ALTER TABLE {table_name}
                ADD COLUMN {column_name}
                {column_definition}
                """
            )
        )

    return True


# ============================================================
# إنشاء Index إذا لم يكن موجودًا
# ============================================================

def create_index_if_missing(
    index_name,
    table_name,
    column_name,
):

    if not table_exists(table_name):
        return False

    if not column_exists(
        table_name,
        column_name,
    ):
        return False

    try:

        with engine.begin() as connection:

            connection.execute(
                text(
                    f"""
                    CREATE INDEX IF NOT EXISTS
                    {index_name}
                    ON {table_name}
                    ({column_name})
                    """
                )
            )

        return True

    except Exception as error:

        print(
            f"⚠ خطأ أثناء إنشاء الفهرس "
            f"{index_name}:",
            error,
        )

        return False


# ============================================================
# تحديث قاعدة البيانات
# ============================================================

def migrate_database():

    # Legacy tables may predate clinic ownership. Only a single-clinic database
    # has an unambiguous owner for formerly shared patient/catalogue records.
    for table in ("patients", "doctors", "appointments", "laboratory_tests"):
        add_column_if_missing(table, "clinic_id", "INTEGER")
    add_column_if_missing("visits", "doctor_id", "INTEGER")
    with engine.begin() as connection:
        if table_exists("clinics"):
            clinics = connection.execute(text("SELECT id FROM clinics")).scalars().all()
            if len(clinics) == 1:
                for table in ("patients", "doctors", "laboratory_tests"):
                    if table_exists(table):
                        connection.execute(text(f"UPDATE {table} SET clinic_id=:owner WHERE clinic_id IS NULL"), {"owner": clinics[0]})
        # Empty legacy date strings represent missing values. Normalize only
        # nullable date columns; never guess a non-empty or invalid date.
        from sqlalchemy import Date, DateTime
        for table in Base.metadata.sorted_tables:
            if not table_exists(table.name): continue
            existing = {item["name"] for item in inspect(engine).get_columns(table.name)}
            for column in table.columns:
                if column.name in existing and column.nullable and isinstance(column.type, (Date, DateTime)):
                    connection.execute(text(f'UPDATE "{table.name}" SET "{column.name}"=NULL WHERE TRIM("{column.name}")=\'\''))

    print(
        "========================================"
    )

    print(
        " CLINOVA - Database Migration"
    )

    print(
        "========================================"
    )


    # ========================================================
    # Laboratory
    # ========================================================

    try:

        added = add_column_if_missing(
            "laboratory_orders",
            "visit_id",
            "INTEGER",
        )

        if added:

            print(
                "✓ تمت إضافة visit_id "
                "إلى laboratory_orders"
            )

        else:

            print(
                "✓ visit_id موجود مسبقًا "
                "أو الجدول غير موجود"
            )

    except Exception as error:

        print(
            "⚠ خطأ أثناء إضافة "
            "visit_id إلى laboratory_orders:",
            error,
        )


    create_index_if_missing(
        "ix_laboratory_orders_visit_id",
        "laboratory_orders",
        "visit_id",
    )


    # ========================================================
    # Radiology
    # ========================================================

    if table_exists(
        "radiology_requests"
    ):

        print(
            "✓ تم العثور على جدول "
            "radiology_requests"
        )


        # ----------------------------------------------------
        # patient_id
        # ----------------------------------------------------

        create_index_if_missing(
            "ix_radiology_requests_patient_id",
            "radiology_requests",
            "patient_id",
        )


        # ----------------------------------------------------
        # visit_id
        # ----------------------------------------------------

        try:

            added = add_column_if_missing(
                "radiology_requests",
                "visit_id",
                "INTEGER",
            )

            if added:

                print(
                    "✓ تمت إضافة visit_id "
                    "إلى radiology_requests"
                )

            else:

                print(
                    "✓ visit_id موجود مسبقًا "
                    "في radiology_requests"
                )

        except Exception as error:

            print(
                "⚠ خطأ أثناء إضافة "
                "visit_id إلى radiology_requests:",
                error,
            )


        create_index_if_missing(
            "ix_radiology_requests_visit_id",
            "radiology_requests",
            "visit_id",
        )


        # ----------------------------------------------------
        # appointment_id
        # ----------------------------------------------------

        create_index_if_missing(
            "ix_radiology_requests_appointment_id",
            "radiology_requests",
            "appointment_id",
        )


        # ----------------------------------------------------
        # status
        # ----------------------------------------------------

        create_index_if_missing(
            "ix_radiology_requests_status",
            "radiology_requests",
            "status",
        )


        # ----------------------------------------------------
        # imaging_type
        # ----------------------------------------------------

        create_index_if_missing(
            "ix_radiology_requests_imaging_type",
            "radiology_requests",
            "imaging_type",
        )


        print(
            "✓ تم التأكد من فهارس "
            "التصوير الشعاعي"
        )

    else:

        print(
            "✓ جدول radiology_requests "
            "غير موجود وسيتم إنشاؤه"
        )


    print(
        "========================================"
    )

    print(
        "✓ Database migration completed"
    )

    print(
        "========================================"
    )


# ============================================================
# إنشاء الجداول
# ============================================================

def create_tables():

    print(
        "========================================"
    )

    print(
        " CLINOVA - Database Initialization"
    )

    print(
        "========================================"
    )


    try:

        Base.metadata.create_all(
            bind=engine,
        )

        print(
            "✓ تم التأكد من إنشاء جميع الجداول"
        )

    except Exception as error:

        print(
            "✗ خطأ أثناء إنشاء الجداول:",
            error,
        )

        raise


    try:

        migrate_database()

    except Exception as error:

        print(
            "⚠ تحذير أثناء تحديث "
            "قاعدة البيانات:",
            error,
        )


    print(
        "========================================"
    )

    print(
        "✓ Database ready"
    )

    print(
        "========================================"
    )
