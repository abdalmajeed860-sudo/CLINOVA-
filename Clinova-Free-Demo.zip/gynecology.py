from input_validation import calendar_date, appointment_clock, required_name
# ============================================================
# CLINOVA
# قسم النسائية والتوليد
# gynecology.py
# ============================================================

from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from clinic_security import tenant_text as text, section_guard
from database import SessionLocal
from models import PregnancyFollowUp
from input_validation import calendar_date
import datetime
import html


router = APIRouter(
    prefix="/gynecology",
    tags=["Gynecology"], dependencies=[section_guard("visits")]
)


# ============================================================
# فلترة المريضات
# ============================================================

FEMALE_GENDER_SQL = "LOWER(TRIM(COALESCE(gender, ''))) IN ('أنثى', 'female', 'f')"


# ============================================================
# أدوات عامة
# ============================================================

def esc(value):
    if value is None:
        return ""
    return html.escape(str(value))


def parse_date(value):
    """
    يقبل:
    2026-04-07
    2026-04-07 00:00:00
    datetime
    date
    """
    if not value:
        return None

    if isinstance(value, datetime.datetime):
        return value.date()

    if isinstance(value, datetime.date):
        return value

    value = str(value).strip()

    formats = [
        "%Y-%m-%d",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%d/%m/%Y",
        "%d-%m-%Y",
    ]

    for fmt in formats:
        try:
            return datetime.datetime.strptime(value, fmt).date()
        except ValueError:
            pass

    return None


def format_date(value):
    d = parse_date(value)

    if not d:
        return "-"

    return d.strftime("%Y-%m-%d")


def today_string():
    return datetime.date.today().strftime("%Y-%m-%d")


def calculate_pregnancy(lmp):
    lmp_date = parse_date(lmp)

    if not lmp_date:
        return {
            "weeks": 0,
            "days": 0,
            "total_days": 0,
            "due_date": None
        }

    today = datetime.date.today()

    total_days = (today - lmp_date).days

    if total_days < 0:
        total_days = 0

    weeks = total_days // 7
    days = total_days % 7

    due_date = lmp_date + datetime.timedelta(days=280)

    return {
        "weeks": weeks,
        "days": days,
        "total_days": total_days,
        "due_date": due_date
    }


def get_db():
    return SessionLocal()


def get_patient(db, patient_id):
    result = db.execute(
        text("\n            SELECT\n                id,\n                medical_number,\n                file_number,\n                full_name,\n                gender,\n                birth_date,\n                phone,\n                address,\n                blood_type,\n                allergies,\n                chronic_diseases,\n                notes\n            FROM (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS patients\n            WHERE id = :id\n              AND LOWER(TRIM(COALESCE(gender, ''))) IN ('أنثى', 'انثى', 'female', 'f', 'female انثى', 'female أنثى')\n        "),
        {"id": patient_id}
    ).mappings().first()

    if result is None:
        raise HTTPException(404, "المريضة غير موجودة في المنشأة الحالية")
    return result


def get_pregnancy(db, pregnancy_id):
    return db.execute(
        text('\n            SELECT *\n            FROM (SELECT * FROM pregnancies WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS pregnancies\n            WHERE id = :id\n        '),
        {"id": pregnancy_id}
    ).mappings().first()


# ============================================================
# CSS
# ============================================================

STYLE = """
<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Tahoma, Arial, sans-serif;
    background: #f4f7fb;
    color: #172033;
    direction: rtl;
}

a {
    text-decoration: none;
}

.container {
    width: min(1400px, 94%);
    margin: 30px auto;
}

.header {
    background: linear-gradient(135deg, #0f766e, #115e59);
    color: white;
    padding: 28px;
    border-radius: 20px;
    margin-bottom: 22px;
    box-shadow: 0 10px 30px rgba(0,0,0,.08);
}

.header h1 {
    margin: 0 0 8px;
    font-size: 30px;
}

.header p {
    margin: 0;
    opacity: .9;
}

.toolbar {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.btn {
    display: inline-block;
    padding: 11px 17px;
    border-radius: 10px;
    background: #0f766e;
    color: white;
    border: none;
    cursor: pointer;
    font-size: 14px;
}

.btn:hover {
    opacity: .9;
}

.btn.secondary {
    background: #475569;
}

.btn.blue {
    background: #2563eb;
}

.btn.green {
    background: #16a34a;
}

.btn.red {
    background: #dc2626;
}

.btn.orange {
    background: #ea580c;
}

.btn.light {
    background: #e2e8f0;
    color: #172033;
}

.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 18px;
}

.card {
    background: white;
    border-radius: 18px;
    padding: 22px;
    box-shadow: 0 5px 20px rgba(15,23,42,.06);
    border: 1px solid #e5e7eb;
}

.card h3 {
    margin-top: 0;
}

.stat {
    font-size: 34px;
    font-weight: bold;
    color: #0f766e;
}

.table-wrap {
    overflow-x: auto;
    background: white;
    border-radius: 18px;
    box-shadow: 0 5px 20px rgba(15,23,42,.06);
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 13px;
    border-bottom: 1px solid #e5e7eb;
    text-align: right;
    white-space: nowrap;
}

th {
    background: #f8fafc;
    color: #334155;
}

tr:hover td {
    background: #f8fafc;
}

.form-card {
    background: white;
    padding: 28px;
    border-radius: 20px;
    box-shadow: 0 5px 20px rgba(15,23,42,.06);
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 18px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 7px;
}

.form-group.full {
    grid-column: 1 / -1;
}

label {
    font-weight: bold;
    color: #334155;
}

input,
select,
textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #cbd5e1;
    border-radius: 10px;
    font-family: inherit;
    font-size: 14px;
    background: white;
}

textarea {
    min-height: 110px;
    resize: vertical;
}

.section-title {
    margin: 30px 0 15px;
    color: #0f766e;
}

.patient-banner {
    background: white;
    padding: 20px;
    border-radius: 18px;
    margin-bottom: 20px;
    border-right: 5px solid #0f766e;
}

.patient-name {
    font-size: 24px;
    font-weight: bold;
}

.badge {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 20px;
    background: #dcfce7;
    color: #166534;
    font-size: 12px;
}

.badge.warning {
    background: #fef3c7;
    color: #92400e;
}

.badge.danger {
    background: #fee2e2;
    color: #991b1b;
}

.empty {
    text-align: center;
    padding: 40px;
    color: #64748b;
}

.alert {
    padding: 15px;
    border-radius: 12px;
    margin-bottom: 18px;
    background: #eff6ff;
    color: #1e40af;
}

@media(max-width: 750px) {
    .form-grid {
        grid-template-columns: 1fr;
    }

    .form-group.full {
        grid-column: auto;
    }
}

</style>
"""


# ============================================================
# Layout
# ============================================================

def page(title, content):
    return HTMLResponse(
        f"""
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>{esc(title)} - CLINOVA</title>
            {STYLE}
        </head>
        <body>
            <div class="container">

                <div class="toolbar">
                    <a class="btn secondary" href="/">🏠 الرئيسية</a>
                    <a class="btn" href="/gynecology">👩‍⚕️ قسم النسائية</a>
                    <a class="btn blue" href="/patients">👥 المرضى</a>
                    <a class="btn" href="/pharmacy/orders">الصيدلية والوصفات</a>
                </div>

                {content}

            </div>
        </body>
        </html>
        """
    )


# ============================================================
# لوحة قسم النسائية
# ============================================================

@router.get("", response_class=HTMLResponse)
@router.get("/", response_class=HTMLResponse)
def gynecology_dashboard(request: Request):

    db = get_db()

    try:
        total_pregnancies = db.execute(
            text('SELECT COUNT(*) FROM (SELECT * FROM pregnancies WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS pregnancies')
        ).scalar() or 0

        active_pregnancies = db.execute(
            text("\n                SELECT COUNT(*)\n                FROM (SELECT * FROM pregnancies WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS pregnancies\n                WHERE pregnancy_status = 'حامل'\n                   OR pregnancy_status IS NULL\n            ")
        ).scalar() or 0

        family_planning = db.execute(
            text('SELECT COUNT(*) FROM (SELECT * FROM family_planning WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS family_planning')
        ).scalar() or 0

        women = db.execute(
            text("\n                SELECT COUNT(*)\n                FROM (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS patients\n                WHERE LOWER(TRIM(COALESCE(gender, ''))) IN ('أنثى', 'انثى', 'female', 'f', 'female انثى', 'female أنثى')\n            ")
        ).scalar() or 0

    finally:
        db.close()

    content = f"""
    <div class="header">
        <h1>👩‍⚕️ قسم النسائية والتوليد</h1>
        <p>إدارة الحمل والمتابعة وتنظيم الأسرة والاستشارات النسائية</p>
    </div>

    <div class="grid">

        <div class="card">
            <h3>🤰 إجمالي ملفات الحمل</h3>
            <div class="stat">{total_pregnancies}</div>
            <a class="btn" href="/gynecology/pregnancies">
                عرض الحوامل
            </a>
        </div>

        <div class="card">
            <h3>❤️ حالات الحمل الحالية</h3>
            <div class="stat">{active_pregnancies}</div>
            <a class="btn green" href="/gynecology/pregnancies">
                المتابعة
            </a>
        </div>

        <div class="card">
            <h3>💗 تنظيم الأسرة</h3>
            <div class="stat">{family_planning}</div>
            <a class="btn blue" href="/gynecology/family-planning">
                فتح السجلات
            </a>
        </div>

        <div class="card">
            <h3>👩 المريضات</h3>
            <div class="stat">{women}</div>
            <a class="btn secondary" href="/patients?gender=female">
                المريضات
            </a>
        </div>

    </div>

    <h2 class="section-title">الوصول السريع</h2>

    <div class="grid">

        <div class="card">
            <h3>🤰 إضافة حمل جديد</h3>
            <p>تسجيل حالة حمل جديدة وربطها بالمريضة.</p>
            <a class="btn green" href="/gynecology/pregnancies">
                اختيار المريضة
            </a>
        </div>

        <div class="card">
            <h3>💗 تنظيم الأسرة</h3>
            <p>تسجيل وسائل منع الحمل والاستشارات.</p>
            <a class="btn blue" href="/gynecology/family-planning">
                فتح القسم
            </a>
        </div>

        <div class="card">
            <h3>🩺 الاستشارات</h3>
            <p>عرض الزيارات والاستشارات النسائية.</p>
            <a class="btn orange" href="/gynecology/consultations">
                الاستشارات
            </a>
        </div>

        <div class="card">
            <h3>📜 السجل</h3>
            <p>عرض النشاطات والزيارات النسائية.</p>
            <a class="btn secondary" href="/gynecology/history">
                فتح السجل
            </a>
        </div>

    </div>
    """

    return page("قسم النسائية", content)


# ============================================================
# قائمة الحوامل
# ============================================================

@router.get("/pregnancies", response_class=HTMLResponse)
def pregnancies():

    db = get_db()

    try:

        rows = db.execute(
            text("\n                SELECT\n                    p.id,\n                    p.patient_id,\n                    p.last_menstrual_period,\n                    p.expected_delivery_date,\n                    p.pregnancy_status,\n                    p.pregnancy_type,\n                    p.risk_level,\n                    p.gravida,\n                    p.para,\n                    p.abortions,\n                    p.living_children,\n                    pt.full_name,\n                    pt.medical_number,\n                    pt.file_number\n                FROM (SELECT * FROM pregnancies WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS p\n                LEFT JOIN (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS pt\n                    ON pt.id = p.patient_id\n                WHERE LOWER(TRIM(COALESCE(pt.gender, ''))) IN ('أنثى', 'انثى', 'female', 'f', 'female انثى', 'female أنثى')\n                ORDER BY p.id DESC\n            ")
        ).mappings().all()

        patients = db.execute(
            text("\n                SELECT id, full_name, medical_number, file_number\n                FROM (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS patients\n                WHERE LOWER(TRIM(COALESCE(gender, ''))) IN ('أنثى', 'انثى', 'female', 'f', 'female انثى', 'female أنثى')\n                ORDER BY full_name\n            ")
        ).mappings().all()

    finally:
        db.close()

    rows_html = ""

    for row in rows:

        calc = calculate_pregnancy(
            row["last_menstrual_period"]
        )

        rows_html += f"""
        <tr>

            <td>{row["id"]}</td>

            <td>
                <a href="/gynecology/patient/{row["patient_id"]}">
                    <strong>{esc(row["full_name"])}</strong>
                </a>
                <br>
                <small>
                    ملف: {esc(row["file_number"] or "-")}
                </small>
            </td>

            <td>
                {format_date(row["last_menstrual_period"])}
            </td>

            <td>
                {format_date(
                    row["expected_delivery_date"]
                    or calc["due_date"]
                )}
            </td>

            <td>
                {calc["weeks"]} أسبوع و {calc["days"]} يوم
            </td>

            <td>
                {esc(row["pregnancy_status"] or "حامل")}
            </td>

            <td>
                {esc(row["risk_level"] or "طبيعي")}
            </td>

            <td>
                <a class="btn blue"
                   href="/gynecology/patient/{row["patient_id"]}">
                   الملف
                </a>

                <a class="btn green"
                   href="/gynecology/pregnancy/{row["id"]}">
                   المتابعة
                </a>
            </td>

        </tr>
        """

    if not rows_html:
        rows_html = """
        <tr>
            <td colspan="8" class="empty">
                لا توجد سجلات حمل حتى الآن
            </td>
        </tr>
        """

    patient_options = ""

    for patient in patients:
        patient_options += f"""
        <option value="{patient["id"]}">
            {esc(patient["full_name"])}
            - {esc(patient["file_number"] or patient["medical_number"] or "")}
        </option>
        """

    content = f"""
    <div class="header">
        <h1>🤰 ملفات الحمل</h1>
        <p>إدارة ومتابعة حالات الحمل</p>
    </div>

    <div class="form-card">

        <h2>➕ تسجيل حمل جديد</h2>

        <form method="post"
              action="/gynecology/pregnancy/new">

            <div class="form-grid">

                <div class="form-group">
                    <label>المريضة</label>

                    <select name="patient_id" required>
                        <option value="">اختر المريضة</option>
                        {patient_options}
                    </select>
                </div>

                <div class="form-group">
                    <label>آخر دورة شهرية</label>
                    <input
                        type="date"
                        name="last_menstrual_period"
                    >
                </div>

            </div>

            <br>

            <button class="btn green" type="submit">
                💾 تسجيل الحمل
            </button>

        </form>

    </div>

    <br>

    <div class="table-wrap">

        <table>

            <thead>
                <tr>
                    <th>#</th>
                    <th>المريضة</th>
                    <th>آخر دورة</th>
                    <th>موعد الولادة</th>
                    <th>عمر الحمل</th>
                    <th>الحالة</th>
                    <th>الخطورة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>

            <tbody>
                {rows_html}
            </tbody>

        </table>

    </div>
    """

    return page("ملفات الحمل", content)


# ============================================================
# إنشاء حمل
# ============================================================

@router.post("/pregnancy/new")
def create_pregnancy(
    patient_id: int = Form(...),
    last_menstrual_period: str = Form("")
):

    last_menstrual_period = calendar_date(last_menstrual_period, "تاريخ آخر دورة", allow_future=False)

    db = get_db()

    try:

        patient = get_patient(db, patient_id)

        if not patient:
            return RedirectResponse(
                "/gynecology/pregnancies",
                status_code=303
            )

        lmp = parse_date(last_menstrual_period)

        due_date = None

        if lmp:
            due_date = lmp + datetime.timedelta(days=280)

        db.execute(
            text("\n                INSERT INTO pregnancies (clinic_id, \n                    patient_id,\n                    last_menstrual_period,\n                    expected_delivery_date,\n                    pregnancy_status,\n                    pregnancy_type,\n                    risk_level,\n                    gravida,\n                    para,\n                    abortions,\n                    living_children,\n                    created_at\n                )\n                VALUES (:active_clinic_id, \n                    :patient_id,\n                    :lmp,\n                    :edd,\n                    'حامل',\n                    'مفرد',\n                    'طبيعي',\n                    1,\n                    0,\n                    0,\n                    0,\n                    :created_at\n                )\n            "),
            {
                "patient_id": patient_id,
                "lmp": lmp.strftime("%Y-%m-%d") if lmp else None,
                "edd": due_date.strftime("%Y-%m-%d")
                       if due_date else None,
                "created_at": datetime.datetime.now()
            }
        )

        db.commit()

    finally:
        db.close()

    return RedirectResponse(
        f"/gynecology/patient/{patient_id}",
        status_code=303
    )


# ============================================================
# ملف المريضة النسائي
# ============================================================

@router.get("/patient/{patient_id}", response_class=HTMLResponse)
def patient_gynecology_file(patient_id: int):

    db = get_db()

    try:

        patient = get_patient(db, patient_id)

        if not patient:
            return page(
                "المريضة غير موجودة",
                """
                <div class="alert">
                    المريضة غير موجودة.
                </div>
                """
            )

        pregnancies = db.execute(
            text('\n                SELECT *\n                FROM (SELECT * FROM pregnancies WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS pregnancies\n                WHERE patient_id = :patient_id\n                ORDER BY id DESC\n            '),
            {"patient_id": patient_id}
        ).mappings().all()

        family_records = db.execute(
            text('\n                SELECT *\n                FROM (SELECT * FROM family_planning WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS family_planning\n                WHERE patient_id = :patient_id\n                ORDER BY id DESC\n            '),
            {"patient_id": patient_id}
        ).mappings().all()

        visits = db.execute(
            text('\n                SELECT *\n                FROM (SELECT * FROM visits WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS visits\n                WHERE patient_id = :patient_id\n                ORDER BY id DESC\n                LIMIT 50\n            '),
            {"patient_id": patient_id}
        ).mappings().all()

    finally:
        db.close()

    pregnancy_html = ""

    for pregnancy in pregnancies:

        calc = calculate_pregnancy(
            pregnancy["last_menstrual_period"]
        )

        pregnancy_html += f"""
        <div class="card">

            <h3>
                🤰 حمل رقم {pregnancy["id"]}
            </h3>

            <p>
                <strong>آخر دورة:</strong>
                {format_date(pregnancy["last_menstrual_period"])}
            </p>

            <p>
                <strong>موعد الولادة المتوقع:</strong>
                {format_date(
                    pregnancy["expected_delivery_date"]
                    or calc["due_date"]
                )}
            </p>

            <p>
                <strong>عمر الحمل:</strong>
                {calc["weeks"]} أسبوع و {calc["days"]} يوم
            </p>

            <p>
                <strong>الحالة:</strong>
                {esc(pregnancy["pregnancy_status"] or "حامل")}
            </p>

            <p>
                <strong>درجة الخطورة:</strong>
                {esc(pregnancy["risk_level"] or "طبيعي")}
            </p>

            <p>
                <strong>نوع الحمل:</strong>
                {esc(pregnancy["pregnancy_type"] or "-")}
            </p>

            <p>
                <strong>عدد مرات الحمل:</strong>
                {esc(pregnancy["gravida"] or 0)}
            </p>

            <p>
                <strong>الولادات:</strong>
                {esc(pregnancy["para"] or 0)}
            </p>

            <p>
                <strong>الإجهاض:</strong>
                {esc(pregnancy["abortions"] or 0)}
            </p>

            <p>
                <strong>الأطفال الأحياء:</strong>
                {esc(pregnancy["living_children"] or 0)}
            </p>

            <a class="btn green"
               href="/gynecology/pregnancy/{pregnancy["id"]}">
                فتح متابعة الحمل
            </a>

        </div>
        """

    if not pregnancy_html:
        pregnancy_html = """
        <div class="card">
            <div class="empty">
                لا يوجد حمل مسجل لهذه المريضة.
            </div>
        </div>
        """

    family_html = ""

    for record in family_records:

        family_html += f"""
        <tr>
            <td>{record["id"]}</td>
            <td>{esc(record["method"] or "-")}</td>
            <td>{esc(record["contraceptive_type"] or "-")}</td>
            <td>{esc(record["pregnancy_test"] or "-")}</td>
            <td>{esc(record["doctor_name"] or "-")}</td>
            <td>{esc(
                record["consultation_date"]
                or record["visit_date"]
                or "-"
            )}</td>
        </tr>
        """

    if not family_html:
        family_html = """
        <tr>
            <td colspan="6" class="empty">
                لا توجد سجلات لتنظيم الأسرة
            </td>
        </tr>
        """

    visits_html = ""

    for visit in visits:

        visits_html += f"""
        <tr>
            <td>{esc(visit["visit_date"] or "-")}</td>
            <td>{esc(visit["doctor_name"] or "-")}</td>
            <td>{esc(visit["chief_complaint"] or "-")}</td>
            <td>{esc(visit["diagnosis"] or "-")}</td>
            <td>{esc(visit["treatment"] or "-")}</td>
        </tr>
        """

    if not visits_html:
        visits_html = """
        <tr>
            <td colspan="5" class="empty">
                لا توجد زيارات مسجلة
            </td>
        </tr>
        """

    content = f"""

    <div class="header">
        <h1>👩‍⚕️ الملف النسائي</h1>
        <p>ملف المريضة الطبي والنسائي</p>
    </div>

    <div class="patient-banner">

        <div class="patient-name">
            {esc(patient["full_name"])}
        </div>

        <p>
            رقم الملف:
            <strong>
                {esc(patient["file_number"] or "-")}
            </strong>
        </p>

        <p>
            الرقم الطبي:
            <strong>
                {esc(patient["medical_number"] or "-")}
            </strong>
        </p>

        <p>
            الهاتف:
            {esc(patient["phone"] or "-")}
        </p>

    </div>

    <div class="toolbar">

        <a class="btn green"
           href="/gynecology/patient/{patient_id}/pregnancy/new">
            ➕ إضافة حمل
        </a>

        <a class="btn blue"
           href="/gynecology/family-planning/{patient_id}">
            💗 تنظيم الأسرة
        </a>

        <a class="btn orange"
           href="/gynecology/consultations/{patient_id}">
            🩺 استشارة نسائية
        </a>

        <a class="btn secondary"
           href="/gynecology/routine-visits/{patient_id}">
            📅 زيارة روتينية
        </a>

    </div>

    <h2 class="section-title">
        🤰 حالات الحمل
    </h2>

    <div class="grid">
        {pregnancy_html}
    </div>

    <h2 class="section-title">
        💗 تنظيم الأسرة
    </h2>

    <div class="table-wrap">

        <table>

            <thead>
                <tr>
                    <th>#</th>
                    <th>الوسيلة</th>
                    <th>نوع المانع</th>
                    <th>اختبار الحمل</th>
                    <th>الطبيب</th>
                    <th>التاريخ</th>
                </tr>
            </thead>

            <tbody>
                {family_html}
            </tbody>

        </table>

    </div>

    <h2 class="section-title">
        🩺 الزيارات الطبية
    </h2>

    <div class="table-wrap">

        <table>

            <thead>
                <tr>
                    <th>التاريخ</th>
                    <th>الطبيب</th>
                    <th>الشكوى</th>
                    <th>التشخيص</th>
                    <th>العلاج</th>
                </tr>
            </thead>

            <tbody>
                {visits_html}
            </tbody>

        </table>

    </div>
    """

    return page(
        f"ملف {patient['full_name']}",
        content
    )


# ============================================================
# إضافة حمل من ملف المريضة
# ============================================================

@router.get(
    "/patient/{patient_id}/pregnancy/new",
    response_class=HTMLResponse
)
def new_pregnancy_form(patient_id: int):

    db = get_db()

    try:
        patient = get_patient(db, patient_id)
    finally:
        db.close()

    if not patient:
        return page(
            "المريضة غير موجودة",
            "<div class='alert'>المريضة غير موجودة.</div>"
        )

    content = f"""

    <div class="header">
        <h1>🤰 تسجيل حمل جديد</h1>
        <p>{esc(patient["full_name"])}</p>
    </div>

    <div class="form-card">

        <form method="post"
              action="/gynecology/patient/{patient_id}/pregnancy/new">

            <div class="form-grid">

                <div class="form-group">
                    <label>آخر دورة شهرية</label>
                    <input
                        type="date"
                        name="last_menstrual_period"
                    >
                </div>

                <div class="form-group">
                    <label>حالة الحمل</label>

                    <select name="pregnancy_status">
                        <option value="حامل">حامل</option>
                        <option value="انتهى">انتهى</option>
                        <option value="إجهاض">إجهاض</option>
                        <option value="ولادة">ولادة</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>نوع الحمل</label>

                    <select name="pregnancy_type">
                        <option value="مفرد">مفرد</option>
                        <option value="توأم">توأم</option>
                        <option value="متعدد">متعدد</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>درجة الخطورة</label>

                    <select name="risk_level">
                        <option value="طبيعي">طبيعي</option>
                        <option value="متوسط الخطورة">متوسط الخطورة</option>
                        <option value="عالي الخطورة">عالي الخطورة</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>عدد مرات الحمل Gravida</label>
                    <input type="number"
                           name="gravida"
                           value="1"
                           min="0">
                </div>

                <div class="form-group">
                    <label>عدد الولادات Para</label>
                    <input type="number"
                           name="para"
                           value="0"
                           min="0">
                </div>

                <div class="form-group">
                    <label>عدد الإجهاضات</label>
                    <input type="number"
                           name="abortions"
                           value="0"
                           min="0">
                </div>

                <div class="form-group">
                    <label>الأطفال الأحياء</label>
                    <input type="number"
                           name="living_children"
                           value="0"
                           min="0">
                </div>

                <div class="form-group">
                    <label>نبض الجنين</label>
                    <input name="fetal_heart_rate">
                </div>

                <div class="form-group">
                    <label>ضغط الدم</label>
                    <input name="blood_pressure"
                           placeholder="120/80">
                </div>

                <div class="form-group">
                    <label>الوزن</label>
                    <input name="weight">
                </div>

                <div class="form-group">
                    <label>ارتفاع قاع الرحم</label>
                    <input name="fundal_height">
                </div>

                <div class="form-group">
                    <label>وضعية الجنين</label>
                    <input name="fetal_position">
                </div>

                <div class="form-group full">
                    <label>ملاحظات</label>
                    <textarea name="notes"></textarea>
                </div>

            </div>

            <br>

            <button class="btn green">
                💾 حفظ الحمل
            </button>

            <a class="btn light"
               href="/gynecology/patient/{patient_id}">
                إلغاء
            </a>

        </form>

    </div>
    """

    return page("إضافة حمل", content)


@router.post(
    "/patient/{patient_id}/pregnancy/new"
)
def save_pregnancy(
    patient_id: int,
    last_menstrual_period: str = Form(""),
    pregnancy_status: str = Form("حامل"),
    pregnancy_type: str = Form("مفرد"),
    risk_level: str = Form("طبيعي"),
    gravida: int = Form(1),
    para: int = Form(0),
    abortions: int = Form(0),
    living_children: int = Form(0),
    fetal_heart_rate: str = Form(""),
    blood_pressure: str = Form(""),
    weight: str = Form(""),
    fundal_height: str = Form(""),
    fetal_position: str = Form(""),
    notes: str = Form("")
):

    if min(gravida, para, abortions, living_children) < 0: raise HTTPException(400, "أعداد الحمل والأطفال لا يمكن أن تكون سالبة")

    last_menstrual_period = calendar_date(last_menstrual_period, "تاريخ آخر دورة", allow_future=False)

    db = get_db()

    try:

        patient = get_patient(db, patient_id)

        if not patient:
            return RedirectResponse(
                "/gynecology/pregnancies",
                status_code=303
            )

        lmp = parse_date(last_menstrual_period)

        due = None

        if lmp:
            due = lmp + datetime.timedelta(days=280)

        db.execute(
            text('\n                INSERT INTO pregnancies (clinic_id, \n                    patient_id,\n                    last_menstrual_period,\n                    expected_delivery_date,\n                    pregnancy_status,\n                    pregnancy_type,\n                    risk_level,\n                    gravida,\n                    para,\n                    abortions,\n                    living_children,\n                    fetal_heart_rate,\n                    blood_pressure,\n                    weight,\n                    fundal_height,\n                    fetal_position,\n                    notes,\n                    created_at\n                )\n                VALUES (:active_clinic_id, \n                    :patient_id,\n                    :lmp,\n                    :due,\n                    :status,\n                    :type,\n                    :risk,\n                    :gravida,\n                    :para,\n                    :abortions,\n                    :living_children,\n                    :fhr,\n                    :bp,\n                    :weight,\n                    :fundal,\n                    :position,\n                    :notes,\n                    :created_at\n                )\n            '),
            {
                "patient_id": patient_id,
                "lmp": lmp.strftime("%Y-%m-%d")
                       if lmp else None,
                "due": due.strftime("%Y-%m-%d")
                       if due else None,
                "status": pregnancy_status,
                "type": pregnancy_type,
                "risk": risk_level,
                "gravida": gravida,
                "para": para,
                "abortions": abortions,
                "living_children": living_children,
                "fhr": fetal_heart_rate,
                "bp": blood_pressure,
                "weight": weight,
                "fundal": fundal_height,
                "position": fetal_position,
                "notes": notes,
                "created_at": datetime.datetime.now()
            }
        )

        db.commit()

    finally:
        db.close()

    return RedirectResponse(
        f"/gynecology/patient/{patient_id}",
        status_code=303
    )


# ============================================================
# متابعة الحمل
# ============================================================

@router.get(
    "/pregnancy/{pregnancy_id}",
    response_class=HTMLResponse
)
def pregnancy_details(pregnancy_id: int):

    db = get_db()

    try:

        pregnancy = get_pregnancy(db, pregnancy_id)

        if not pregnancy:
            return page(
                "الحمل غير موجود",
                "<div class='alert'>السجل غير موجود.</div>"
            )

        patient = get_patient(
            db,
            pregnancy["patient_id"]
        )

        if not patient:
            return page(
                "المريضة غير موجودة",
                "<div class='alert'>المريضة غير موجودة أو ليست ضمن قسم النسائية.</div>"
            )

    finally:
        db.close()

    calc = calculate_pregnancy(
        pregnancy["last_menstrual_period"]
    )

    content = f"""

    <div class="header">
        <h1>🤰 متابعة الحمل</h1>
        <p>{esc(patient["full_name"] if patient else "")}</p>
    </div>

    <div class="patient-banner">

        <div class="patient-name">
            {esc(patient["full_name"] if patient else "-")}
        </div>

        <p>
            رقم الملف:
            {esc(patient["file_number"] if patient else "-")}
        </p>

        <p>
            الرقم الطبي:
            {esc(patient["medical_number"] if patient else "-")}
        </p>

    </div>

    <div class="grid">

        <div class="card">
            <h3>📅 آخر دورة</h3>
            <div class="stat">
                {format_date(
                    pregnancy["last_menstrual_period"]
                )}
            </div>
        </div>

        <div class="card">
            <h3>👶 موعد الولادة</h3>
            <div class="stat">
                {format_date(
                    pregnancy["expected_delivery_date"]
                    or calc["due_date"]
                )}
            </div>
        </div>

        <div class="card">
            <h3>⏱ عمر الحمل</h3>
            <div class="stat">
                {calc["weeks"]}
            </div>
            <p>
                أسبوع و {calc["days"]} يوم
            </p>
        </div>

        <div class="card">
            <h3>⚠️ الخطورة</h3>
            <div class="stat">
                {esc(pregnancy["risk_level"] or "طبيعي")}
            </div>
        </div>

    </div>

    <h2 class="section-title">
        🩺 البيانات السريرية
    </h2>

    <div class="grid">

        <div class="card">
            <h3>❤️ نبض الجنين</h3>
            <p>
                {esc(pregnancy["fetal_heart_rate"] or "-")}
            </p>
        </div>

        <div class="card">
            <h3>🩸 ضغط الدم</h3>
            <p>
                {esc(pregnancy["blood_pressure"] or "-")}
            </p>
        </div>

        <div class="card">
            <h3>⚖️ الوزن</h3>
            <p>
                {esc(pregnancy["weight"] or "-")}
            </p>
        </div>

        <div class="card">
            <h3>📏 ارتفاع قاع الرحم</h3>
            <p>
                {esc(pregnancy["fundal_height"] or "-")}
            </p>
        </div>

        <div class="card">
            <h3>👶 وضعية الجنين</h3>
            <p>
                {esc(pregnancy["fetal_position"] or "-")}
            </p>
        </div>

    </div>

    <h2 class="section-title">
        📝 الملاحظات
    </h2>

    <div class="card">
        {esc(pregnancy["notes"] or "لا توجد ملاحظات")}
    </div>

    <br>

    <div class="form-card">

        <h2>
            ➕ تسجيل متابعة جديدة
        </h2>

        <form method="post"
              action="/gynecology/pregnancy/{pregnancy_id}/follow-up">

            <div class="form-grid">

                <div class="form-group">
                    <label>نبض الجنين</label>
                    <input name="fetal_heart_rate">
                </div>

                <div class="form-group">
                    <label>ضغط الدم</label>
                    <input name="blood_pressure"
                           placeholder="120/80">
                </div>

                <div class="form-group">
                    <label>الوزن</label>
                    <input name="weight">
                </div>

                <div class="form-group">
                    <label>ارتفاع قاع الرحم</label>
                    <input name="fundal_height">
                </div>

                <div class="form-group">
                    <label>وضعية الجنين</label>
                    <input name="fetal_position">
                </div>

                <div class="form-group">
                    <label>حالة الحمل</label>

                    <select name="pregnancy_status">
                        <option value="حامل">حامل</option>
                        <option value="مستقر">مستقر</option>
                        <option value="عالي الخطورة">
                            عالي الخطورة
                        </option>
                        <option value="إجهاض">إجهاض</option>
                        <option value="ولادة">ولادة</option>
                        <option value="انتهى">انتهى</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>درجة الخطورة</label>

                    <select name="risk_level">
                        <option value="طبيعي">طبيعي</option>
                        <option value="متوسط الخطورة">
                            متوسط الخطورة
                        </option>
                        <option value="عالي الخطورة">
                            عالي الخطورة
                        </option>
                    </select>
                </div>

                <div class="form-group full">
                    <label>نتيجة السونار</label>
                    <textarea name="ultrasound"></textarea>
                </div>

                <div class="form-group full">
                    <label>التحاليل</label>
                    <textarea name="laboratory"></textarea>
                </div>

                <div class="form-group full">
                    <label>الأعراض</label>
                    <textarea name="symptoms"></textarea>
                </div>

                <div class="form-group full">
                    <label>التشخيص</label>
                    <textarea name="diagnosis"></textarea>
                </div>

                <div class="form-group full">
                    <label>العلاج</label>
                    <textarea name="treatment"></textarea>
                </div>

                <div class="form-group full">
                    <label>الأدوية</label>
                    <textarea name="medications"></textarea>
                </div>

                <div class="form-group full">
                    <label>ملاحظات الطبيب</label>
                    <textarea name="doctor_notes"></textarea>
                </div>

            </div>

            <br>

            <button class="btn green">
                💾 حفظ المتابعة
            </button>

        </form>

    </div>
    """

    return page("متابعة الحمل", content)


# ============================================================
# حفظ متابعة الحمل
#
# ملاحظة:
# لا نستخدم PregnancyFollowUp لأن الجدول غير موجود
# في قاعدة البيانات الحالية.
#
# نخزن آخر بيانات متابعة في سجل الحمل نفسه.
# ============================================================

@router.post(
    "/pregnancy/{pregnancy_id}/follow-up"
)
def save_pregnancy_followup(
    pregnancy_id: int,
    fetal_heart_rate: str = Form(""),
    blood_pressure: str = Form(""),
    weight: str = Form(""),
    fundal_height: str = Form(""),
    fetal_position: str = Form(""),
    pregnancy_status: str = Form("حامل"),
    risk_level: str = Form("طبيعي"),
    ultrasound: str = Form(""),
    laboratory: str = Form(""),
    symptoms: str = Form(""),
    diagnosis: str = Form(""),
    treatment: str = Form(""),
    medications: str = Form(""),
    doctor_notes: str = Form("")
):

    db = get_db()

    try:

        pregnancy = get_pregnancy(
            db,
            pregnancy_id
        )

        if not pregnancy:
            return RedirectResponse(
                "/gynecology/pregnancies",
                status_code=303
            )

        patient = get_patient(db, pregnancy["patient_id"])

        if not patient:
            return RedirectResponse(
                "/gynecology/pregnancies",
                status_code=303
            )

        old_notes = pregnancy["notes"] or ""
        age = calculate_pregnancy(pregnancy["last_menstrual_period"])
        db.add(PregnancyFollowUp(
            pregnancy_id=pregnancy_id, visit_date=datetime.datetime.now(),
            gestational_weeks=age["weeks"] if pregnancy["last_menstrual_period"] else None,
            gestational_days=age["days"] if pregnancy["last_menstrual_period"] else None,
            gestational_total_days=age["total_days"] if pregnancy["last_menstrual_period"] else None,
            blood_pressure=blood_pressure, weight=weight, fetal_heart_rate=fetal_heart_rate,
            fundal_height=fundal_height, fetal_position=fetal_position,
            ultrasound_result=ultrasound, laboratory_results=laboratory,
            symptoms=symptoms, diagnosis=diagnosis, treatment=treatment,
            medications=medications, doctor_notes=doctor_notes,
        ))

        date_text = datetime.datetime.now().strftime(
            "%Y-%m-%d %H:%M"
        )

        followup_text = f"""
متابعة بتاريخ: {date_text}

الأعراض:
{symptoms}

التشخيص:
{diagnosis}

العلاج:
{treatment}

الأدوية:
{medications}

نتيجة السونار:
{ultrasound}

التحاليل:
{laboratory}

ملاحظات الطبيب:
{doctor_notes}

-------------------------
"""

        new_notes = followup_text + "\n" + old_notes

        db.execute(
            text('\n                UPDATE pregnancies\n                SET\n                    pregnancy_status = :status,\n                    risk_level = :risk,\n                    fetal_heart_rate = :fhr,\n                    blood_pressure = :bp,\n                    weight = :weight,\n                    fundal_height = :fundal,\n                    fetal_position = :position,\n                    notes = :notes\n                WHERE id = :id AND (patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id))\n'),
            {
                "status": pregnancy_status,
                "risk": risk_level,
                "fhr": fetal_heart_rate,
                "bp": blood_pressure,
                "weight": weight,
                "fundal": fundal_height,
                "position": fetal_position,
                "notes": new_notes,
                "id": pregnancy_id
            }
        )

        db.commit()

        patient_id = pregnancy["patient_id"]

    finally:
        db.close()

    return RedirectResponse(
        f"/gynecology/pregnancy/{pregnancy_id}",
        status_code=303
    )


# ============================================================
# تنظيم الأسرة
# ============================================================

@router.get(
    "/family-planning",
    response_class=HTMLResponse
)
def family_planning():

    db = get_db()

    try:

        records = db.execute(
            text("\n                SELECT\n                    fp.*,\n                    p.full_name,\n                    p.file_number,\n                    p.medical_number\n                FROM (SELECT * FROM family_planning WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS fp\n                LEFT JOIN (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS p\n                    ON p.id = fp.patient_id\n                WHERE LOWER(TRIM(COALESCE(p.gender, ''))) IN ('أنثى', 'انثى', 'female', 'f', 'female انثى', 'female أنثى')\n                ORDER BY fp.id DESC\n            ")
        ).mappings().all()

        patients = db.execute(
            text("\n                SELECT id, full_name, file_number\n                FROM (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS patients\n                WHERE LOWER(TRIM(COALESCE(gender, ''))) IN ('أنثى', 'انثى', 'female', 'f', 'female انثى', 'female أنثى')\n                ORDER BY full_name\n            ")
        ).mappings().all()

    finally:
        db.close()

    rows = ""

    for r in records:

        rows += f"""
        <tr>
            <td>{r["id"]}</td>

            <td>
                <a href="/gynecology/patient/{r["patient_id"]}">
                    {esc(r["full_name"] or "-")}
                </a>
            </td>

            <td>{esc(r["method"] or "-")}</td>

            <td>
                {esc(r["contraceptive_type"] or "-")}
            </td>

            <td>
                {esc(r["pregnancy_test"] or "-")}
            </td>

            <td>
                {esc(r["doctor_name"] or "-")}
            </td>

            <td>
                {esc(
                    r["consultation_date"]
                    or r["visit_date"]
                    or "-"
                )}
            </td>

        </tr>
        """

    if not rows:
        rows = """
        <tr>
            <td colspan="7" class="empty">
                لا توجد سجلات
            </td>
        </tr>
        """

    options = ""

    for p in patients:
        options += f"""
        <option value="{p["id"]}">
            {esc(p["full_name"])}
            - {esc(p["file_number"] or "")}
        </option>
        """

    content = f"""

    <div class="header">
        <h1>💗 تنظيم الأسرة</h1>
        <p>إدارة الاستشارات ووسائل تنظيم الأسرة</p>
    </div>

    <div class="form-card">

        <h2>➕ تسجيل استشارة تنظيم أسرة</h2>

        <form method="post"
              action="/gynecology/family-planning/new">

            <div class="form-grid">

                <div class="form-group">
                    <label>المريضة</label>

                    <select name="patient_id" required>
                        <option value="">
                            اختر المريضة
                        </option>

                        {options}
                    </select>
                </div>

                <div class="form-group">
                    <label>التاريخ</label>
                    <input
                        type="date"
                        name="consultation_date"
                        value="{today_string()}"
                    >
                </div>

                <div class="form-group">
                    <label>الطبيب</label>
                    <input name="doctor_name">
                </div>

                <div class="form-group">
                    <label>الحالة الاجتماعية</label>
                    <input name="marital_status">
                </div>

                <div class="form-group">
                    <label>عدد الأطفال</label>
                    <input name="number_of_children">
                </div>

                <div class="form-group">
                    <label>العدد المرغوب من الأطفال</label>
                    <input name="desired_number_of_children">
                </div>

                <div class="form-group">
                    <label>وسيلة تنظيم الأسرة</label>
                    <input name="method">
                </div>

                <div class="form-group">
                    <label>نوع الوسيلة</label>
                    <input name="contraceptive_type">
                </div>

                <div class="form-group">
                    <label>جدول الجرعة / الاستخدام</label>
                    <input name="dose_or_schedule">
                </div>

                <div class="form-group">
                    <label>اختبار الحمل</label>
                    <select name="pregnancy_test">
                        <option value="">غير محدد</option>
                        <option value="سلبي">سلبي</option>
                        <option value="إيجابي">إيجابي</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>ضغط الدم</label>
                    <input name="blood_pressure">
                </div>

                <div class="form-group">
                    <label>الوزن</label>
                    <input name="weight">
                </div>

                <div class="form-group full">
                    <label>تفاصيل الوسيلة</label>
                    <textarea name="method_details"></textarea>
                </div>

                <div class="form-group full">
                    <label>التاريخ الطبي</label>
                    <textarea name="medical_history"></textarea>
                </div>

                <div class="form-group full">
                    <label>الفحص</label>
                    <textarea name="examination"></textarea>
                </div>

                <div class="form-group full">
                    <label>التشخيص</label>
                    <textarea name="diagnosis"></textarea>
                </div>

                <div class="form-group full">
                    <label>المضاعفات</label>
                    <textarea name="complications"></textarea>
                </div>

                <div class="form-group full">
                    <label>التوصيات</label>
                    <textarea name="recommendations"></textarea>
                </div>

                <div class="form-group full">
                    <label>ملاحظات الطبيب</label>
                    <textarea name="doctor_notes"></textarea>
                </div>

            </div>

            <br>

            <button class="btn green">
                💾 حفظ السجل
            </button>

        </form>

    </div>

    <br>

    <div class="table-wrap">

        <table>

            <thead>
                <tr>
                    <th>#</th>
                    <th>المريضة</th>
                    <th>الوسيلة</th>
                    <th>نوع الوسيلة</th>
                    <th>اختبار الحمل</th>
                    <th>الطبيب</th>
                    <th>التاريخ</th>
                </tr>
            </thead>

            <tbody>
                {rows}
            </tbody>

        </table>

    </div>

    """

    return page("تنظيم الأسرة", content)


# ============================================================
# حفظ تنظيم الأسرة
# ============================================================

@router.post(
    "/family-planning/new"
)
def create_family_planning(
    patient_id: int = Form(...),
    consultation_date: str = Form(""),
    doctor_name: str = Form(""),
    marital_status: str = Form(""),
    number_of_children: str = Form(""),
    desired_number_of_children: str = Form(""),
    method: str = Form(""),
    contraceptive_type: str = Form(""),
    dose_or_schedule: str = Form(""),
    pregnancy_test: str = Form(""),
    blood_pressure: str = Form(""),
    weight: str = Form(""),
    method_details: str = Form(""),
    medical_history: str = Form(""),
    examination: str = Form(""),
    diagnosis: str = Form(""),
    complications: str = Form(""),
    recommendations: str = Form(""),
    doctor_notes: str = Form("")
):

    consultation_date = calendar_date(consultation_date, "تاريخ الاستشارة")

    db = get_db()

    try:

        patient = get_patient(db, patient_id)

        if not patient:
            return RedirectResponse(
                "/gynecology/family-planning",
                status_code=303
            )

        db.execute(
            text('\n                INSERT INTO family_planning (clinic_id, \n                    patient_id,\n                    visit_date,\n                    method,\n                    method_details,\n                    side_effects,\n                    counseling,\n                    pregnancy_test,\n                    notes,\n                    created_at,\n                    consultation_date,\n                    doctor_name,\n                    marital_status,\n                    number_of_children,\n                    desired_number_of_children,\n                    contraceptive_type,\n                    dose_or_schedule,\n                    complications,\n                    blood_pressure,\n                    weight,\n                    medical_history,\n                    examination,\n                    diagnosis,\n                    recommendations,\n                    doctor_notes\n                )\n                VALUES (:active_clinic_id, \n                    :patient_id,\n                    :visit_date,\n                    :method,\n                    :method_details,\n                    :side_effects,\n                    :counseling,\n                    :pregnancy_test,\n                    :notes,\n                    :created_at,\n                    :consultation_date,\n                    :doctor_name,\n                    :marital_status,\n                    :number_of_children,\n                    :desired_number_of_children,\n                    :contraceptive_type,\n                    :dose_or_schedule,\n                    :complications,\n                    :blood_pressure,\n                    :weight,\n                    :medical_history,\n                    :examination,\n                    :diagnosis,\n                    :recommendations,\n                    :doctor_notes\n                )\n            '),
            {
                "patient_id": patient_id,
                "visit_date": consultation_date,
                "method": method,
                "method_details": method_details,
                "side_effects": "",
                "counseling": recommendations,
                "pregnancy_test": pregnancy_test,
                "notes": "",
                "created_at": datetime.datetime.now().strftime(
                    "%Y-%m-%d %H:%M:%S"
                ),
                "consultation_date": consultation_date,
                "doctor_name": doctor_name,
                "marital_status": marital_status,
                "number_of_children": number_of_children,
                "desired_number_of_children": desired_number_of_children,
                "contraceptive_type": contraceptive_type,
                "dose_or_schedule": dose_or_schedule,
                "complications": complications,
                "blood_pressure": blood_pressure,
                "weight": weight,
                "medical_history": medical_history,
                "examination": examination,
                "diagnosis": diagnosis,
                "recommendations": recommendations,
                "doctor_notes": doctor_notes
            }
        )

        db.commit()

    finally:
        db.close()

    return RedirectResponse(
        f"/gynecology/patient/{patient_id}",
        status_code=303
    )


# ============================================================
# تنظيم الأسرة لمريضة محددة
# ============================================================

@router.get(
    "/family-planning/{patient_id}",
    response_class=HTMLResponse
)
def patient_family_planning(patient_id: int):

    db = get_db()

    try:

        patient = get_patient(db, patient_id)

        records = db.execute(
            text('\n                SELECT *\n                FROM (SELECT * FROM family_planning WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS family_planning\n                WHERE patient_id = :patient_id\n                ORDER BY id DESC\n            '),
            {"patient_id": patient_id}
        ).mappings().all()

    finally:
        db.close()

    if not patient:
        return page(
            "المريضة غير موجودة",
            "<div class='alert'>المريضة غير موجودة.</div>"
        )

    rows = ""

    for r in records:

        rows += f"""
        <tr>
            <td>{r["id"]}</td>
            <td>{esc(r["method"] or "-")}</td>
            <td>{esc(r["contraceptive_type"] or "-")}</td>
            <td>{esc(r["diagnosis"] or "-")}</td>
            <td>{esc(r["recommendations"] or "-")}</td>
            <td>
                {esc(
                    r["consultation_date"]
                    or r["visit_date"]
                    or "-"
                )}
            </td>
        </tr>
        """

    if not rows:
        rows = """
        <tr>
            <td colspan="6" class="empty">
                لا توجد سجلات
            </td>
        </tr>
        """

    content = f"""

    <div class="header">
        <h1>💗 تنظيم الأسرة</h1>
        <p>{esc(patient["full_name"])}</p>
    </div>

    <div class="toolbar">

        <a class="btn green"
           href="/gynecology/family-planning">
            ➕ سجل جديد
        </a>

        <a class="btn secondary"
           href="/gynecology/patient/{patient_id}">
            ↩ ملف المريضة
        </a>

    </div>

    <div class="table-wrap">

        <table>

            <thead>
                <tr>
                    <th>#</th>
                    <th>الوسيلة</th>
                    <th>النوع</th>
                    <th>التشخيص</th>
                    <th>التوصيات</th>
                    <th>التاريخ</th>
                </tr>
            </thead>

            <tbody>
                {rows}
            </tbody>

        </table>

    </div>
    """

    return page(
        "تنظيم الأسرة",
        content
    )


# ============================================================
# الاستشارات النسائية
# ============================================================

@router.get(
    "/consultations",
    response_class=HTMLResponse
)
def consultations():

    db = get_db()

    try:

        visits = db.execute(
            text("\n                SELECT\n                    v.*,\n                    p.full_name,\n                    p.file_number\n                FROM (SELECT * FROM visits WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS v\n                LEFT JOIN (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS p\n                    ON p.id = v.patient_id\n                WHERE\n                    LOWER(TRIM(COALESCE(p.gender, ''))) IN ('أنثى', 'انثى', 'female', 'f', 'female انثى', 'female أنثى')\n                    AND (\n                        LOWER(COALESCE(v.chief_complaint, '')) LIKE '%نس%'\n                        OR LOWER(COALESCE(v.notes, '')) LIKE '%نس%'\n                        OR LOWER(COALESCE(v.diagnosis, '')) LIKE '%نس%'\n                    )\n                ORDER BY v.id DESC\n            ")
        ).mappings().all()

    finally:
        db.close()

    rows = ""

    for v in visits:

        rows += f"""
        <tr>
            <td>{esc(v["visit_date"] or "-")}</td>
            <td>
                <a href="/gynecology/patient/{v["patient_id"]}">
                    {esc(v["full_name"] or "-")}
                </a>
            </td>
            <td>{esc(v["doctor_name"] or "-")}</td>
            <td>{esc(v["chief_complaint"] or "-")}</td>
            <td>{esc(v["diagnosis"] or "-")}</td>
            <td>{esc(v["treatment"] or "-")}</td>
        </tr>
        """

    if not rows:
        rows = """
        <tr>
            <td colspan="6" class="empty">
                لا توجد استشارات نسائية مسجلة.
            </td>
        </tr>
        """

    content = f"""

    <div class="header">
        <h1>🩺 الاستشارات النسائية</h1>
        <p>متابعة الزيارات والاستشارات</p>
    </div>

    <div class="table-wrap">

        <table>

            <thead>
                <tr>
                    <th>التاريخ</th>
                    <th>المريضة</th>
                    <th>الطبيب</th>
                    <th>الشكوى</th>
                    <th>التشخيص</th>
                    <th>العلاج</th>
                </tr>
            </thead>

            <tbody>
                {rows}
            </tbody>

        </table>

    </div>

    """

    return page(
        "الاستشارات النسائية",
        content
    )


# ============================================================
# استشارة لمريضة
# ============================================================

@router.get(
    "/consultations/{patient_id}",
    response_class=HTMLResponse
)
def consultation_form(patient_id: int):

    db = get_db()

    try:
        patient = get_patient(db, patient_id)
    finally:
        db.close()

    if not patient:
        return page(
            "المريضة غير موجودة",
            "<div class='alert'>المريضة غير موجودة.</div>"
        )

    content = f"""

    <div class="header">
        <h1>🩺 استشارة نسائية</h1>
        <p>{esc(patient["full_name"])}</p>
    </div>

    <div class="form-card">

        <form method="post"
              action="/gynecology/consultations/{patient_id}">

            <div class="form-grid">

                <div class="form-group">
                    <label>الطبيب</label>
                    <input name="doctor_name">
                </div>

                <div class="form-group">
                    <label>التاريخ</label>
                    <input type="date"
                           name="visit_date"
                           value="{today_string()}">
                </div>

                <div class="form-group full">
                    <label>الشكوى الرئيسية</label>
                    <textarea name="chief_complaint"></textarea>
                </div>

                <div class="form-group full">
                    <label>الفحص</label>
                    <textarea name="examination"></textarea>
                </div>

                <div class="form-group full">
                    <label>التشخيص</label>
                    <textarea name="diagnosis"></textarea>
                </div>

                <div class="form-group full">
                    <label>العلاج</label>
                    <textarea name="treatment"></textarea>
                </div>

                <div class="form-group full">
                    <label>الوصفة</label>
                    <textarea name="prescription"></textarea>
                </div>

                <div class="form-group full">
                    <label>التحاليل المطلوبة</label>
                    <textarea name="lab_requests"></textarea>
                </div>

                <div class="form-group full">
                    <label>طلبات التصوير</label>
                    <textarea name="radiology_requests"></textarea>
                </div>

                <div class="form-group full">
                    <label>ملاحظات</label>
                    <textarea name="notes">
استشارة نسائية
                    </textarea>
                </div>

            </div>

            <br>

            <button class="btn green">
                💾 حفظ الاستشارة
            </button>

        </form>

    </div>

    """

    return page(
        "استشارة نسائية",
        content
    )


@router.post(
    "/consultations/{patient_id}"
)
def save_consultation(
    patient_id: int,
    doctor_name: str = Form(""),
    visit_date: str = Form(""),
    chief_complaint: str = Form(""),
    examination: str = Form(""),
    diagnosis: str = Form(""),
    treatment: str = Form(""),
    prescription: str = Form(""),
    lab_requests: str = Form(""),
    radiology_requests: str = Form(""),
    notes: str = Form("")
):

    visit_date = calendar_date(visit_date, "تاريخ الزيارة")

    db = get_db()

    try:

        patient = get_patient(db, patient_id)

        if not patient:
            return RedirectResponse(
                "/gynecology/consultations",
                status_code=303
            )

        db.execute(
            text('\n                INSERT INTO visits (clinic_id, \n                    patient_id,\n                    visit_date,\n                    doctor_name,\n                    chief_complaint,\n                    examination,\n                    diagnosis,\n                    treatment,\n                    prescription,\n                    lab_requests,\n                    radiology_requests,\n                    notes,\n                    created_at\n                )\n                VALUES (:active_clinic_id, \n                    :patient_id,\n                    :visit_date,\n                    :doctor_name,\n                    :chief_complaint,\n                    :examination,\n                    :diagnosis,\n                    :treatment,\n                    :prescription,\n                    :lab_requests,\n                    :radiology_requests,\n                    :notes,\n                    :created_at\n                )\n            '),
            {
                "patient_id": patient_id,
                "visit_date": (
                    visit_date
                    if visit_date
                    else datetime.datetime.now().strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                ),
                "doctor_name": doctor_name,
                "chief_complaint": chief_complaint,
                "examination": examination,
                "diagnosis": diagnosis,
                "treatment": treatment,
                "prescription": prescription,
                "lab_requests": lab_requests,
                "radiology_requests": radiology_requests,
                "notes": (
                    "استشارة نسائية\n" + notes
                ),
                "created_at": datetime.datetime.now()
            }
        )

        db.commit()

    finally:
        db.close()

    return RedirectResponse(
        f"/gynecology/patient/{patient_id}",
        status_code=303
    )


# ============================================================
# الزيارات الروتينية
# ============================================================

@router.get(
    "/routine-visits",
    response_class=HTMLResponse
)
def routine_visits():

    db = get_db()

    try:

        visits = db.execute(
            text("\n                SELECT\n                    v.*,\n                    p.full_name,\n                    p.file_number\n                FROM (SELECT * FROM visits WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS v\n                LEFT JOIN (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS p\n                    ON p.id = v.patient_id\n                WHERE\n                    LOWER(TRIM(COALESCE(p.gender, ''))) IN ('أنثى', 'انثى', 'female', 'f', 'female انثى', 'female أنثى')\n                    AND (\n                        v.notes LIKE '%روتينية%'\n                        OR v.notes LIKE '%متابعة نسائية%'\n                    )\n                ORDER BY v.id DESC\n            ")
        ).mappings().all()

    finally:
        db.close()

    rows = ""

    for v in visits:

        rows += f"""
        <tr>
            <td>{esc(v["visit_date"] or "-")}</td>
            <td>
                <a href="/gynecology/patient/{v["patient_id"]}">
                    {esc(v["full_name"] or "-")}
                </a>
            </td>
            <td>{esc(v["doctor_name"] or "-")}</td>
            <td>{esc(v["diagnosis"] or "-")}</td>
            <td>{esc(v["notes"] or "-")}</td>
        </tr>
        """

    if not rows:
        rows = """
        <tr>
            <td colspan="5" class="empty">
                لا توجد زيارات روتينية.
            </td>
        </tr>
        """

    content = f"""

    <div class="header">
        <h1>📅 الزيارات الروتينية</h1>
        <p>المتابعات النسائية الدورية</p>
    </div>

    <div class="table-wrap">

        <table>

            <thead>
                <tr>
                    <th>التاريخ</th>
                    <th>المريضة</th>
                    <th>الطبيب</th>
                    <th>التشخيص</th>
                    <th>الملاحظات</th>
                </tr>
            </thead>

            <tbody>
                {rows}
            </tbody>

        </table>

    </div>
    """

    return page(
        "الزيارات الروتينية",
        content
    )


# ============================================================
# زيارة روتينية لمريضة
# ============================================================

@router.get(
    "/routine-visits/{patient_id}",
    response_class=HTMLResponse
)
def routine_visit_form(patient_id: int):

    db = get_db()

    try:
        patient = get_patient(db, patient_id)
    finally:
        db.close()

    if not patient:
        return page(
            "المريضة غير موجودة",
            "<div class='alert'>المريضة غير موجودة.</div>"
        )

    content = f"""

    <div class="header">
        <h1>📅 زيارة نسائية روتينية</h1>
        <p>{esc(patient["full_name"])}</p>
    </div>

    <div class="form-card">

        <form method="post"
              action="/gynecology/routine-visits/{patient_id}">

            <div class="form-grid">

                <div class="form-group">
                    <label>الطبيب</label>
                    <input name="doctor_name">
                </div>

                <div class="form-group">
                    <label>التاريخ</label>
                    <input
                        type="date"
                        name="visit_date"
                        value="{today_string()}"
                    >
                </div>

                <div class="form-group full">
                    <label>سبب الزيارة</label>
                    <textarea name="chief_complaint"></textarea>
                </div>

                <div class="form-group full">
                    <label>الفحص</label>
                    <textarea name="examination"></textarea>
                </div>

                <div class="form-group full">
                    <label>التشخيص</label>
                    <textarea name="diagnosis"></textarea>
                </div>

                <div class="form-group full">
                    <label>العلاج</label>
                    <textarea name="treatment"></textarea>
                </div>

                <div class="form-group full">
                    <label>الملاحظات</label>
                    <textarea name="notes"></textarea>
                </div>

            </div>

            <br>

            <button class="btn green">
                💾 حفظ الزيارة
            </button>

        </form>

    </div>
    """

    return page(
        "زيارة روتينية",
        content
    )


@router.post(
    "/routine-visits/{patient_id}"
)
def save_routine_visit(
    patient_id: int,
    doctor_name: str = Form(""),
    visit_date: str = Form(""),
    chief_complaint: str = Form(""),
    examination: str = Form(""),
    diagnosis: str = Form(""),
    treatment: str = Form(""),
    notes: str = Form("")
):

    visit_date = calendar_date(visit_date, "تاريخ الزيارة")

    db = get_db()

    try:

        patient = get_patient(db, patient_id)

        if not patient:
            return RedirectResponse(
                "/gynecology/routine-visits",
                status_code=303
            )

        db.execute(
            text('\n                INSERT INTO visits (clinic_id, \n                    patient_id,\n                    visit_date,\n                    doctor_name,\n                    chief_complaint,\n                    examination,\n                    diagnosis,\n                    treatment,\n                    notes,\n                    created_at\n                )\n                VALUES (:active_clinic_id, \n                    :patient_id,\n                    :visit_date,\n                    :doctor_name,\n                    :chief_complaint,\n                    :examination,\n                    :diagnosis,\n                    :treatment,\n                    :notes,\n                    :created_at\n                )\n            '),
            {
                "patient_id": patient_id,
                "visit_date": (
                    visit_date
                    if visit_date
                    else datetime.datetime.now().strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                ),
                "doctor_name": doctor_name,
                "chief_complaint": chief_complaint,
                "examination": examination,
                "diagnosis": diagnosis,
                "treatment": treatment,
                "notes": (
                    "زيارة نسائية روتينية\n" + notes
                ),
                "created_at": datetime.datetime.now()
            }
        )

        db.commit()

    finally:
        db.close()

    return RedirectResponse(
        f"/gynecology/patient/{patient_id}",
        status_code=303
    )


# ============================================================
# السجل التاريخي
# ============================================================

@router.get(
    "/history",
    response_class=HTMLResponse
)
def gynecology_history():

    db = get_db()

    try:

        pregnancies = db.execute(
            text("\n                SELECT\n                    p.id,\n                    p.patient_id,\n                    p.created_at,\n                    p.pregnancy_status,\n                    p.risk_level,\n                    pt.full_name\n                FROM (SELECT * FROM pregnancies WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS p\n                LEFT JOIN (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS pt\n                    ON pt.id = p.patient_id\n                WHERE LOWER(TRIM(COALESCE(pt.gender, ''))) IN ('أنثى', 'انثى', 'female', 'f', 'female انثى', 'female أنثى')\n                ORDER BY p.id DESC\n                LIMIT 100\n            ")
        ).mappings().all()

        family = db.execute(
            text("\n                SELECT\n                    fp.id,\n                    fp.patient_id,\n                    fp.created_at,\n                    fp.method,\n                    pt.full_name\n                FROM (SELECT * FROM family_planning WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS fp\n                LEFT JOIN (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS pt\n                    ON pt.id = fp.patient_id\n                WHERE LOWER(TRIM(COALESCE(pt.gender, ''))) IN ('أنثى', 'انثى', 'female', 'f', 'female انثى', 'female أنثى')\n                ORDER BY fp.id DESC\n                LIMIT 100\n            ")
        ).mappings().all()

        visits = db.execute(
            text("\n                SELECT\n                    v.id,\n                    v.patient_id,\n                    v.visit_date,\n                    v.diagnosis,\n                    v.notes,\n                    pt.full_name\n                FROM (SELECT * FROM visits WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS v\n                LEFT JOIN (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS pt\n                    ON pt.id = v.patient_id\n                WHERE\n                    LOWER(TRIM(COALESCE(pt.gender, ''))) IN ('أنثى', 'انثى', 'female', 'f', 'female انثى', 'female أنثى')\n                    AND (\n                        v.notes LIKE '%نسائية%'\n                        OR v.notes LIKE '%نسائي%'\n                    )\n                ORDER BY v.id DESC\n                LIMIT 100\n            ")
        ).mappings().all()

    finally:
        db.close()

    pregnancy_rows = ""

    for p in pregnancies:

        pregnancy_rows += f"""
        <tr>
            <td>🤰 حمل</td>
            <td>{esc(p["full_name"] or "-")}</td>
            <td>{esc(p["pregnancy_status"] or "-")}</td>
            <td>{esc(p["risk_level"] or "-")}</td>
            <td>{esc(p["created_at"] or "-")}</td>
        </tr>
        """

    for f in family:

        pregnancy_rows += f"""
        <tr>
            <td>💗 تنظيم أسرة</td>
            <td>{esc(f["full_name"] or "-")}</td>
            <td>{esc(f["method"] or "-")}</td>
            <td>-</td>
            <td>{esc(f["created_at"] or "-")}</td>
        </tr>
        """

    for v in visits:

        pregnancy_rows += f"""
        <tr>
            <td>🩺 زيارة</td>
            <td>{esc(v["full_name"] or "-")}</td>
            <td>{esc(v["diagnosis"] or "-")}</td>
            <td>-</td>
            <td>{esc(v["visit_date"] or "-")}</td>
        </tr>
        """

    if not pregnancy_rows:
        pregnancy_rows = """
        <tr>
            <td colspan="5" class="empty">
                لا يوجد سجل تاريخي.
            </td>
        </tr>
        """

    content = f"""

    <div class="header">
        <h1>📜 السجل النسائي</h1>
        <p>جميع النشاطات والملفات المرتبطة بقسم النسائية</p>
    </div>

    <div class="table-wrap">

        <table>

            <thead>
                <tr>
                    <th>النوع</th>
                    <th>المريضة</th>
                    <th>البيان</th>
                    <th>التفاصيل</th>
                    <th>التاريخ</th>
                </tr>
            </thead>

            <tbody>
                {pregnancy_rows}
            </tbody>

        </table>

    </div>
    """

    return page(
        "السجل النسائي",
        content
    )
