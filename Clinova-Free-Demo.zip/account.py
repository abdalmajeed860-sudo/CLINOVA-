# ============================================================
# CLINOVA
# نظام إدارة العيادات الذكي والمتكامل
# account.py
#
# صفحة حساب المستخدم
# Multi-Tenant / User Isolation
# ============================================================

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from database import get_db
from models import User
from auth import (
    get_current_user,
    hash_password,
    verify_password,
    refresh_session,
)


router = APIRouter()


# ============================================================
# Helpers
# ============================================================

def esc(value):
    """حماية النصوص المعروضة داخل HTML."""
    if value is None:
        return ""

    return (
        str(value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


def get_role_name(role):
    roles = {
        "admin": "مدير النظام",
        "doctor": "طبيب",
        "reception": "استقبال",
        "laboratory": "مختبر",
        "radiology": "أشعة",
        "pharmacist": "صيدلي",
        "accounting": "محاسبة",
        "user": "مستخدم",
    }

    return roles.get(role or "", role or "مستخدم")


def redirect_message(message):
    """إظهار رسالة ثم العودة إلى صفحة الحساب."""
    safe_message = esc(message)

    return HTMLResponse(
        f"""
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>CLINOVA</title>

            <style>
                body {{
                    margin: 0;
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: #f1f5f9;
                    font-family: Tahoma, Arial, sans-serif;
                }}

                .box {{
                    width: min(500px, calc(100% - 40px));
                    background: white;
                    border-radius: 18px;
                    padding: 35px;
                    text-align: center;
                    box-shadow: 0 10px 40px rgba(0,0,0,.08);
                }}

                .icon {{
                    font-size: 45px;
                    margin-bottom: 15px;
                }}

                h2 {{
                    margin: 0 0 10px;
                    color: #0f172a;
                }}

                p {{
                    color: #64748b;
                    margin-bottom: 25px;
                }}

                a {{
                    display: inline-block;
                    padding: 12px 22px;
                    background: #2563eb;
                    color: white;
                    text-decoration: none;
                    border-radius: 10px;
                    font-weight: bold;
                }}
            </style>
        </head>

        <body>

            <div class="box">

                <div class="icon">
                    ✓
                </div>

                <h2>
                    CLINOVA
                </h2>

                <p>
                    {safe_message}
                </p>

                <a href="/account">
                    العودة إلى حسابي
                </a>

            </div>

        </body>
        </html>
        """
    )


# ============================================================
# HTML
# ============================================================

def render_account_page(request, user):

    full_name = esc(
        user.full_name or "بدون اسم"
    )

    username = esc(
        user.username or "-"
    )

    role = esc(
        get_role_name(user.role)
    )

    clinic_name = "-"

    if user.clinic:
        clinic_name = esc(
            user.clinic.name
        )

    status = (
        '<span class="status active">● نشط</span>'
        if user.is_active
        else
        '<span class="status inactive">● غير نشط</span>'
    )

    avatar_source = (
        user.full_name
        or user.username
        or "م"
    )

    avatar_letter = esc(
        avatar_source[0]
    )

    return f"""
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>حسابي - CLINOVA</title>

    <style>

        * {{
            box-sizing: border-box;
        }}

        body {{
            margin: 0;

            font-family:
                Tahoma,
                Arial,
                "Segoe UI",
                sans-serif;

            background:
                linear-gradient(
                    135deg,
                    #f8fafc,
                    #eef2f7
                );

            color: #1e293b;
        }}

        .navbar {{
            height: 72px;

            background:
                linear-gradient(
                    135deg,
                    #0f172a,
                    #1e3a5f
                );

            color: white;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding:
                0 30px;

            box-shadow:
                0 5px 25px rgba(0,0,0,.12);
        }}

        .logo {{
            display: flex;
            align-items: center;
            gap: 12px;
        }}

        .logo-icon {{
            width: 43px;
            height: 43px;

            border-radius: 12px;

            background:
                rgba(255,255,255,.12);

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 22px;
        }}

        .logo-title {{
            font-size: 20px;
            font-weight: 800;
        }}

        .logo-subtitle {{
            font-size: 10px;
            opacity: .7;
            margin-top: 3px;
        }}

        .top-user {{
            display: flex;
            align-items: center;
            gap: 10px;
        }}

        .top-user-name {{
            font-size: 13px;
            font-weight: bold;
        }}

        .top-avatar {{
            width: 40px;
            height: 40px;

            border-radius: 50%;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #06b6d4
                );

            display: flex;

            align-items: center;

            justify-content: center;

            font-weight: bold;
        }}

        .container {{
            width:
                min(
                    1100px,
                    calc(100% - 30px)
                );

            margin:
                35px auto;
        }}

        .header {{
            margin-bottom: 25px;
        }}

        .header h1 {{
            margin: 0 0 8px;

            font-size: 30px;

            color: #0f172a;
        }}

        .header p {{
            margin: 0;

            color: #64748b;

            font-size: 14px;
        }}

        .grid {{
            display: grid;

            grid-template-columns:
                1fr 1fr;

            gap: 22px;
        }}

        .card {{
            background: white;

            border-radius: 20px;

            padding: 25px;

            border:
                1px solid #e2e8f0;

            box-shadow:
                0 8px 30px
                rgba(15,23,42,.06);
        }}

        .card h2 {{
            margin:
                0 0 7px;

            font-size: 19px;

            color: #0f172a;
        }}

        .card-description {{
            margin:
                0 0 22px;

            color: #64748b;

            font-size: 13px;

            line-height: 1.7;
        }}

        .profile {{
            display: flex;

            align-items: center;

            gap: 18px;

            padding-bottom: 22px;

            margin-bottom: 22px;

            border-bottom:
                1px solid #e5e7eb;
        }}

        .profile-avatar {{
            width: 75px;
            height: 75px;

            min-width: 75px;

            border-radius: 22px;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #06b6d4
                );

            color: white;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 30px;

            font-weight: 800;
        }}

        .profile-name {{
            font-size: 21px;

            font-weight: 800;

            color: #0f172a;
        }}

        .profile-username {{
            color: #64748b;

            font-size: 13px;

            margin-top: 5px;
        }}

        .info {{
            display: flex;

            flex-direction: column;

            gap: 12px;
        }}

        .info-row {{
            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 15px;

            padding:
                13px 15px;

            border-radius: 12px;

            background: #f8fafc;

            border:
                1px solid #edf2f7;
        }}

        .label {{
            color: #64748b;

            font-size: 13px;
        }}

        .value {{
            color: #0f172a;

            font-size: 13px;

            font-weight: 700;

            text-align: left;
        }}

        .status {{
            display: inline-block;

            padding:
                6px 11px;

            border-radius: 999px;

            font-size: 11px;

            font-weight: bold;
        }}

        .status.active {{
            background: #ecfdf5;

            color: #059669;
        }}

        .status.inactive {{
            background: #fef2f2;

            color: #dc2626;
        }}

        .role {{
            display: inline-block;

            background: #eff6ff;

            color: #2563eb;

            padding:
                6px 11px;

            border-radius: 999px;

            font-size: 11px;

            font-weight: bold;
        }}

        .form-group {{
            margin-bottom: 17px;
        }}

        label {{
            display: block;

            margin-bottom: 7px;

            font-size: 13px;

            font-weight: bold;

            color: #334155;
        }}

        input {{
            width: 100%;

            padding:
                13px 14px;

            border:
                1px solid #dbe1e8;

            border-radius: 11px;

            font-size: 14px;

            outline: none;

            background: white;

            transition: .2s;
        }}

        input:focus {{
            border-color: #2563eb;

            box-shadow:
                0 0 0 3px
                rgba(37,99,235,.10);
        }}

        input[readonly] {{
            background: #f8fafc;
            color: #64748b;
        }}

        .hint {{
            margin-top: 6px;

            font-size: 11px;

            color: #94a3b8;
        }}

        .btn {{
            width: 100%;

            border: 0;

            border-radius: 11px;

            padding:
                13px 20px;

            cursor: pointer;

            font-size: 14px;

            font-weight: bold;

            color: white;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #1d4ed8
                );

            transition: .2s;
        }}

        .btn:hover {{
            transform:
                translateY(-1px);

            box-shadow:
                0 8px 18px
                rgba(37,99,235,.20);
        }}

        .security {{
            margin-top: 20px;

            padding: 14px;

            border-radius: 12px;

            background: #f8fafc;

            border:
                1px solid #e5e7eb;

            color: #64748b;

            font-size: 12px;

            line-height: 1.8;
        }}

        .back {{
            display: inline-block;

            margin-top: 20px;

            color: #2563eb;

            text-decoration: none;

            font-size: 13px;

            font-weight: bold;
        }}

        .footer {{
            text-align: center;

            color: #94a3b8;

            font-size: 11px;

            margin:
                35px 0;
        }}

        @media(max-width: 800px) {{

            .grid {{
                grid-template-columns: 1fr;
            }}

            .navbar {{
                padding:
                    0 15px;
            }}

            .top-user-name {{
                display: none;
            }}

            .container {{
                width:
                    calc(100% - 20px);

                margin-top: 20px;
            }}

            .header h1 {{
                font-size: 24px;
            }}

        }}

    </style>

</head>


<body>


<header class="navbar">

    <div class="logo">

        <div class="logo-icon">
            🏥
        </div>

        <div>

            <div class="logo-title">
                CLINOVA
            </div>

            <div class="logo-subtitle">
                نظام إدارة العيادات الذكي والمتكامل
            </div>

        </div>

    </div>


    <div class="top-user">

        <div class="top-user-name">
            {full_name}
        </div>

        <div class="top-avatar">
            {avatar_letter}
        </div>

    </div>

</header>


<main class="container">


    <div class="header">

        <h1>
            حسابي
        </h1>

        <p>
            إدارة بيانات حسابك الشخصية وأمان الحساب.
            هذه الصفحة تعرض حسابك الحالي فقط.
        </p>

    </div>


    <div class="grid">


        <!-- ==================================================
             ACCOUNT INFORMATION
             ================================================== -->

        <section class="card">

            <h2>
                معلومات الحساب
            </h2>

            <p class="card-description">
                البيانات المرتبطة بالمستخدم الحالي.
            </p>


            <div class="profile">

                <div class="profile-avatar">
                    {avatar_letter}
                </div>

                <div>

                    <div class="profile-name">
                        {full_name}
                    </div>

                    <div class="profile-username">
                        @{username}
                    </div>

                </div>

            </div>


            <div class="info">


                <div class="info-row">

                    <span class="label">
                        الاسم الكامل
                    </span>

                    <span class="value">
                        {full_name}
                    </span>

                </div>


                <div class="info-row">

                    <span class="label">
                        اسم المستخدم
                    </span>

                    <span class="value">
                        {username}
                    </span>

                </div>


                <div class="info-row">

                    <span class="label">
                        الصلاحية
                    </span>

                    <span class="value">

                        <span class="role">
                            {role}
                        </span>

                    </span>

                </div>


                <div class="info-row">

                    <span class="label">
                        العيادة
                    </span>

                    <span class="value">
                        {clinic_name}
                    </span>

                </div>


                <div class="info-row">

                    <span class="label">
                        حالة الحساب
                    </span>

                    <span class="value">
                        {status}
                    </span>

                </div>


            </div>


            <div class="security">

                🔒
                <strong>الخصوصية:</strong>
                هذه الصفحة تعتمد على المستخدم الموجود في
                جلسة الدخول الحالية، ولا تسمح بتمرير
                رقم مستخدم للوصول إلى حساب مستخدم آخر.

            </div>

        </section>


        <!-- ==================================================
             PROFILE EDIT
             ================================================== -->

        <section class="card">

            <h2>
                تعديل بياناتي
            </h2>

            <p class="card-description">
                يمكنك تعديل الاسم الكامل.
                اسم المستخدم والصلاحية والعيادة
                تتم إدارتها وفق صلاحيات النظام.
            </p>


            <form
                method="post"
                action="/account/profile"
            >

                <div class="form-group">

                    <label>
                        اسم المستخدم
                    </label>

                    <input
                        type="text"
                        value="{username}"
                        readonly
                    >

                    <div class="hint">
                        لا يمكن تغييره من صفحة الحساب.
                    </div>

                </div>


                <div class="form-group">

                    <label for="full_name">
                        الاسم الكامل
                    </label>

                    <input
                        id="full_name"
                        name="full_name"
                        type="text"
                        value="{full_name}"
                        maxlength="200"
                        required
                    >

                </div>


                <button
                    type="submit"
                    class="btn"
                >
                    حفظ البيانات
                </button>

            </form>

        </section>


        <!-- ==================================================
             PASSWORD
             ================================================== -->

        <section class="card">

            <h2>
                تغيير كلمة المرور
            </h2>

            <p class="card-description">
                يمكنك تغيير كلمة المرور الخاصة بحسابك.
            </p>


            <form
                method="post"
                action="/account/password"
            >


                <div class="form-group">

                    <label for="current_password">
                        كلمة المرور الحالية
                    </label>

                    <input
                        id="current_password"
                        name="current_password"
                        type="password"
                        autocomplete="current-password"
                        required
                    >

                </div>


                <div class="form-group">

                    <label for="new_password">
                        كلمة المرور الجديدة
                    </label>

                    <input
                        id="new_password"
                        name="new_password"
                        type="password"
                        minlength="6"
                        autocomplete="new-password"
                        required
                    >

                    <div class="hint">
                        الحد الأدنى 6 أحرف أو أرقام.
                    </div>

                </div>


                <div class="form-group">

                    <label for="confirm_password">
                        تأكيد كلمة المرور الجديدة
                    </label>

                    <input
                        id="confirm_password"
                        name="confirm_password"
                        type="password"
                        minlength="6"
                        autocomplete="new-password"
                        required
                    >

                </div>


                <button
                    type="submit"
                    class="btn"
                >
                    تغيير كلمة المرور
                </button>


            </form>


            <div class="security">

                🛡️
                يتم تخزين كلمة المرور الجديدة باستخدام
                نظام التشفير PBKDF2 الموجود في CLINOVA،
                ولا يتم عرض كلمة المرور أو الـ hash
                داخل صفحة الحساب.

            </div>

        </section>


    </div>


    <a
        href="/"
        class="back"
    >
        ← العودة إلى الصفحة الرئيسية
    </a>


</main>


<div class="footer">

    CLINOVA © 2026

    <br>

    إدارة أسهل • تنظيم أفضل • قرارات أسرع

</div>


</body>

</html>
"""


# ============================================================
# GET /account
# ============================================================

@router.get(
    "/account",
    response_class=HTMLResponse
)
def account_page(
    request: Request,
    db: Session = Depends(get_db),
):

    # ========================================================
    # IMPORTANT:
    # لا نأخذ user_id من الرابط.
    # المستخدم يؤخذ من Session فقط.
    # ========================================================

    user = get_current_user(
        request,
        db
    )

    if not user:

        return RedirectResponse(
            "/login",
            status_code=303
        )

    if not user.is_active:

        request.session.clear()

        return RedirectResponse(
            "/login",
            status_code=303
        )

    return HTMLResponse(
        render_account_page(
            request,
            user
        )
    )


# ============================================================
# POST /account/profile
# ============================================================

@router.post(
    "/account/profile",
    response_class=HTMLResponse
)
def update_profile(
    request: Request,
    full_name: str = Form(...),
    db: Session = Depends(get_db),
):

    # المستخدم الحالي فقط
    user = get_current_user(
        request,
        db
    )

    if not user:

        return RedirectResponse(
            "/login",
            status_code=303
        )

    if not user.is_active:

        request.session.clear()

        return RedirectResponse(
            "/login",
            status_code=303
        )

    full_name = full_name.strip()

    if not full_name:

        return redirect_message(
            "يرجى إدخال الاسم الكامل."
        )

    if len(full_name) > 200:

        return redirect_message(
            "الاسم الكامل طويل جدًا."
        )

    # تحديث المستخدم الموجود في الجلسة فقط
    user.full_name = full_name

    db.commit()

    # تحديث بيانات الجلسة
    refresh_session(
        request,
        user,
        db
    )

    return redirect_message(
        "تم تحديث بيانات حسابك بنجاح."
    )


# ============================================================
# POST /account/password
# ============================================================

@router.post(
    "/account/password",
    response_class=HTMLResponse
)
def change_password(
    request: Request,
    current_password: str = Form(...),
    new_password: str = Form(...),
    confirm_password: str = Form(...),
    db: Session = Depends(get_db),
):

    # المستخدم الحالي فقط
    user = get_current_user(
        request,
        db
    )

    if not user:

        return RedirectResponse(
            "/login",
            status_code=303
        )

    if not user.is_active:

        request.session.clear()

        return RedirectResponse(
            "/login",
            status_code=303
        )

    # --------------------------------------------------------
    # التحقق من كلمة المرور الحالية
    # --------------------------------------------------------

    password_valid = False

    if user.password_hash:

        try:

            password_valid = verify_password(
                current_password,
                user.password_hash
            )

        except Exception:

            password_valid = False

    elif user.password:

        # دعم الحسابات القديمة
        password_valid = (
            current_password == user.password
        )

    if not password_valid:

        return redirect_message(
            "كلمة المرور الحالية غير صحيحة."
        )

    # --------------------------------------------------------
    # التحقق من كلمة المرور الجديدة
    # --------------------------------------------------------

    if len(new_password) < 6:

        return redirect_message(
            "كلمة المرور الجديدة يجب أن تكون 6 أحرف أو أرقام على الأقل."
        )

    if new_password != confirm_password:

        return redirect_message(
            "كلمة المرور الجديدة وتأكيدها غير متطابقين."
        )

    if new_password == current_password:

        return redirect_message(
            "يجب أن تختلف كلمة المرور الجديدة عن القديمة."
        )

    # --------------------------------------------------------
    # إنشاء Password Hash جديد
    # --------------------------------------------------------

    user.password_hash = hash_password(
        new_password
    )

    # إزالة كلمة المرور القديمة
    # Older databases define password NOT NULL; an empty compatibility value
    # clears plaintext without violating that constraint.
    user.password = ""

    db.commit()

    # إبقاء الجلسة فعالة
    refresh_session(
        request,
        user,
        db
    )

    return redirect_message(
        "تم تغيير كلمة المرور بنجاح."
    )
