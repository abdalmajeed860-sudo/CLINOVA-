# =========================================================
# CLINOVA
# reports.py
# التقارير المالية وتقارير المرضى
# =========================================================

from datetime import datetime
from collections import defaultdict

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from database import get_db
from models import Patient
from billing_models import Invoice
from billing_access import invoice_query
from auth import get_current_user, has_permission


router = APIRouter()


@router.get("/reports/integrity", response_class=HTMLResponse)
def integrity_report(request: Request, db: Session = Depends(get_db)):
    from data_integrity import integrity_issues
    user = get_current_user(request, db)
    if not user or user.role != "admin" or not user.clinic_id:
        raise HTTPException(403, "تقرير سلامة السجلات متاح لمدير المنشأة فقط")
    issues = integrity_issues(db, user.clinic_id)
    rows = "".join(f'<tr><td>{safe(item["section"])}</td><td>{item["id"]}</td><td>{item["missing_id"]}</td><td>يحتاج مراجعة الربط</td></tr>' for item in issues)
    if not rows:
        rows = '<tr><td colspan="4" class="empty">لم تُكتشف مراجع مفقودة ضمن المنشأة الحالية.</td></tr>'
    content = f'''<div class="header"><h1>سلامة السجلات والروابط</h1><p>السجلات القديمة التي تحتاج إلى مراجعة ارتباطها.</p></div>
        <div class="card"><p>السجلات المحتاجة للمراجعة: <strong>{len(issues)}</strong></p>
        <p>احتُفظ بهذه السجلات. تحديد المريض أو السجل الصحيح يحتاج مراجعة أصل البيانات.</p>
        <table><thead><tr><th>القسم</th><th>رقم السجل</th><th>رقم المرجع المفقود</th><th>الحالة</th></tr></thead><tbody>{rows}</tbody></table>
        <p><a href="/reports">العودة إلى التقارير</a></p></div>'''
    return HTMLResponse(html_page("سلامة السجلات", content))


# =========================================================
# أدوات مساعدة
# =========================================================

def money(value):
    try:
        return f"{float(value or 0):,.2f}"
    except Exception:
        return "0.00"


def safe(value):
    if value is None:
        return ""

    text = str(value)

    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#039;")
    )


def parse_date(value):
    """
    تحويل تاريخ الفاتورة إلى تاريخ Python.
    يدعم:
    YYYY-MM-DD
    YYYY-MM-DD HH:MM:SS
    """

    if not value:
        return None

    if isinstance(value, datetime):
        return value

    text = str(value)

    formats = [
        "%Y-%m-%d",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
    ]

    for fmt in formats:

        try:
            return datetime.strptime(
                text,
                fmt
            )

        except Exception:
            pass

    return None


# =========================================================
# CSS
# =========================================================

def report_style():

    return """

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;

    font-family:
        Tahoma,
        Arial,
        "Segoe UI",
        sans-serif;

    background:
        linear-gradient(
            135deg,
            #f4f8fc,
            #eef4f9
        );

    color: #1e293b;
}

a {
    text-decoration: none;
}

.layout {
    min-height: 100vh;
}


/* =====================================================
   القائمة الجانبية
===================================================== */

.sidebar {

    position: fixed;

    right: 0;
    top: 0;
    bottom: 0;

    width: 250px;

    background:
        linear-gradient(
            180deg,
            #0f172a,
            #111827
        );

    color: white;

    padding: 22px 15px;

    overflow-y: auto;
}

.logo {

    text-align: center;

    font-size: 22px;

    font-weight: bold;

    padding-bottom: 22px;

    border-bottom:
        1px solid #374151;

    margin-bottom: 20px;
}

.logo-icon {

    display: block;

    font-size: 40px;

    margin-bottom: 8px;
}

.menu-title {

    color: #94a3b8;

    font-size: 11px;

    margin:
        20px
        10px
        8px;
}

.menu a {

    display: block;

    color: #cbd5e1;

    padding: 12px 14px;

    border-radius: 10px;

    margin-bottom: 5px;

    transition: .2s;
}

.menu a:hover {

    background: #1e293b;

    color: white;

    transform:
        translateX(-3px);
}

.menu .active {

    background:
        linear-gradient(
            135deg,
            #0284c7,
            #0369a1
        );

    color: white;

    box-shadow:
        0 7px 18px
        rgba(2,132,199,.25);
}


/* =====================================================
   المحتوى
===================================================== */

.content {

    margin-right: 250px;

    padding: 30px;
}


/* =====================================================
   الرأس
===================================================== */

.header {

    background: white;

    padding: 25px;

    border-radius: 18px;

    margin-bottom: 22px;

    box-shadow:
        0 5px 20px
        rgba(15,23,42,.06);

    border:
        1px solid #e5edf5;
}

.header h1 {

    margin: 0 0 8px;

    font-size: 28px;

    color: #0f172a;
}

.header p {

    margin: 0;

    color: #64748b;

    line-height: 1.8;
}


/* =====================================================
   بطاقات الإحصائيات
===================================================== */

.stats {

    display: grid;

    grid-template-columns:
        repeat(
            4,
            minmax(0, 1fr)
        );

    gap: 18px;

    margin-bottom: 22px;
}

.stat-card {

    background: white;

    border-radius: 18px;

    padding: 22px;

    border:
        1px solid #e5edf5;

    box-shadow:
        0 5px 20px
        rgba(15,23,42,.05);

    position: relative;

    overflow: hidden;

    transition: .2s;
}

.stat-card:hover {

    transform:
        translateY(-3px);

    box-shadow:
        0 12px 28px
        rgba(15,23,42,.09);
}

.stat-card::after {

    content: "";

    position: absolute;

    width: 90px;
    height: 90px;

    border-radius: 50%;

    left: -35px;
    bottom: -40px;

    background: #f1f5f9;
}

.stat-icon {

    width: 52px;
    height: 52px;

    border-radius: 15px;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 25px;

    margin-bottom: 15px;
}

.stat-title {

    color: #64748b;

    font-size: 13px;

    font-weight: bold;
}

.stat-number {

    font-size: 27px;

    font-weight: 800;

    margin-top: 8px;

    color: #0f172a;
}

.stat-note {

    margin-top: 6px;

    font-size: 11px;

    color: #94a3b8;
}

.blue .stat-icon {
    background: #e0f2fe;
}

.green .stat-icon {
    background: #dcfce7;
}

.orange .stat-icon {
    background: #fef3c7;
}

.purple .stat-icon {
    background: #f3e8ff;
}


/* =====================================================
   البطاقات العامة
===================================================== */

.card {

    background: white;

    border-radius: 18px;

    padding: 24px;

    margin-bottom: 22px;

    border:
        1px solid #e5edf5;

    box-shadow:
        0 5px 20px
        rgba(15,23,42,.05);
}

.card-title {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 20px;
}

.card-title h2 {

    margin: 0;

    font-size: 19px;

    color: #0f172a;
}

.card-title span {

    font-size: 12px;

    color: #94a3b8;
}


/* =====================================================
   التقارير المالية
===================================================== */

.finance-grid {

    display: grid;

    grid-template-columns:
        repeat(
            3,
            minmax(0, 1fr)
        );

    gap: 15px;
}

.finance-box {

    border-radius: 15px;

    padding: 20px;

    background: #f8fafc;

    border:
        1px solid #e8eef4;
}

.finance-label {

    color: #64748b;

    font-size: 13px;
}

.finance-value {

    font-size: 24px;

    font-weight: 800;

    margin-top: 8px;

    color: #0f172a;
}


/* =====================================================
   الجدول
===================================================== */

.table-container {

    overflow-x: auto;
}

table {

    width: 100%;

    border-collapse: collapse;
}

th {

    background: #f8fafc;

    color: #475569;

    font-size: 13px;

    font-weight: bold;
}

th,
td {

    padding: 13px 11px;

    border-bottom:
        1px solid #e8eef4;

    text-align: right;

    vertical-align: middle;
}

td {

    font-size: 13px;

    color: #475569;
}

tr:hover td {

    background: #fafcff;
}


/* =====================================================
   حالات الدفع
===================================================== */

.status {

    display: inline-block;

    padding: 5px 10px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: bold;
}

.status-paid {

    background: #dcfce7;

    color: #166534;
}

.status-partial {

    background: #fef3c7;

    color: #92400e;
}

.status-unpaid {

    background: #fee2e2;

    color: #991b1b;
}


/* =====================================================
   جدول الأشهر
===================================================== */

.month-grid {

    display: grid;

    grid-template-columns:
        repeat(
            2,
            minmax(0, 1fr)
        );

    gap: 15px;
}

.month-card {

    border:
        1px solid #e5edf5;

    border-radius: 15px;

    padding: 18px;

    background:
        linear-gradient(
            135deg,
            #ffffff,
            #f8fbfd
        );
}

.month-name {

    font-weight: bold;

    color: #0f172a;

    margin-bottom: 12px;
}

.month-row {

    display: flex;

    justify-content: space-between;

    padding: 6px 0;

    font-size: 12px;

    color: #64748b;
}

.month-row strong {

    color: #334155;
}


/* =====================================================
   الأزرار
===================================================== */

.actions {

    display: flex;

    gap: 10px;

    flex-wrap: wrap;
}

.btn {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 7px;

    padding: 11px 17px;

    border-radius: 10px;

    border: none;

    font-family: inherit;

    font-size: 13px;

    font-weight: bold;

    cursor: pointer;

    color: white;

    background: #0284c7;

    transition: .2s;
}

.btn:hover {

    transform:
        translateY(-1px);

    opacity: .92;
}

.btn-secondary {

    background: #64748b;
}


/* =====================================================
   ملاحظة
===================================================== */

.info {

    background: #eff6ff;

    color: #1e40af;

    border:
        1px solid #bfdbfe;

    border-radius: 12px;

    padding: 14px 16px;

    margin-bottom: 20px;

    font-size: 13px;

    line-height: 1.8;
}


/* =====================================================
   فارغ
===================================================== */

.empty {

    text-align: center;

    padding: 35px;

    color: #94a3b8;
}


/* =====================================================
   تجاوب
===================================================== */

@media (max-width: 1100px) {

    .stats {

        grid-template-columns:
            repeat(
                2,
                minmax(0, 1fr)
            );
    }

    .finance-grid {

        grid-template-columns:
            1fr;
    }
}


@media (max-width: 800px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;
    }

    .content {

        margin-right: 0;

        padding: 15px;
    }

    .month-grid {

        grid-template-columns: 1fr;
    }
}


@media (max-width: 550px) {

    .stats {

        grid-template-columns: 1fr;
    }

    .header h1 {

        font-size: 23px;
    }

}

</style>

"""


# =========================================================
# القائمة الجانبية
# =========================================================

def sidebar():

    return """

<aside class="sidebar">

    <div class="logo">

        <span class="logo-icon">
            🏥
        </span>

        CLINOVA

    </div>


    <div class="menu">

        <div class="menu-title">
            الرئيسية
        </div>

        <a href="/">
            🏠 لوحة التحكم
        </a>


        <div class="menu-title">
            إدارة المرضى
        </div>

        <a href="/patients">
            👥 المرضى
        </a>


        <div class="menu-title">
            المواعيد
        </div>

        <a href="/appointments">
            📅 المواعيد
        </a>


        <div class="menu-title">
            العيادات
        </div>

        <a href="/gynecology">
            👩‍⚕️ العيادة النسائية
        </a>


        <div class="menu-title">
            المختبر
        </div>

        <a href="/laboratory">
            🧪 المختبر
        </a>


        <div class="menu-title">
            الإدارة المالية
        </div>

        <a href="/reports/integrity">سلامة السجلات</a>
        <a href="/pharmacy">الصيدلية والمخزون</a>
        <a href="/billing">
            💰 الفواتير
        </a>

        <a href="/billing/new">
            🧾 فاتورة جديدة
        </a>


        <div class="menu-title">
            التقارير
        </div>

        <a
            href="/reports"
            class="active"
        >
            📊 التقارير
        </a>

    </div>

</aside>

"""


# =========================================================
# الصفحة العامة
# =========================================================

def html_page(title, content):

    return f"""

<!DOCTYPE html>

<html lang="ar" dir="rtl">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
{safe(title)}
</title>

{report_style()}

</head>


<body>

<div class="layout">

    {sidebar()}

    <main class="content">

        {content}

    </main>

</div>

</body>

</html>

"""


# =========================================================
# التقرير الرئيسي
# =========================================================

@router.get(
    "/reports",
    response_class=HTMLResponse
)
def reports_home(
    request: Request,
    db: Session = Depends(get_db)
):

    user = get_current_user(request, db)
    if not user or not user.clinic_id or not has_permission(request, db, "reports", "view") or not has_permission(request, db, "billing", "view"):
        raise HTTPException(403, "ليس لديك صلاحية لعرض التقارير المالية")

    # =====================================================
    # المرضى
    # =====================================================

    total_patients = (
        db.query(Patient).filter(Patient.clinic_id == user.clinic_id).count()
    )


    # =====================================================
    # الفواتير
    # =====================================================

    invoices = (
        invoice_query(db, user.clinic_id)
        .order_by(
            Invoice.id.desc()
        )
        .all()
    )


    total_invoices = len(
        invoices
    )


    total_amount = sum(
        float(invoice.total or 0)
        for invoice in invoices
    )


    total_paid = sum(
        float(invoice.paid or 0)
        for invoice in invoices
    )


    total_remaining = sum(
        float(invoice.remaining or 0)
        for invoice in invoices
    )


    # =====================================================
    # الفواتير الشهرية
    # =====================================================

    monthly = defaultdict(
        lambda: {
            "invoices": 0,
            "total": 0.0,
            "paid": 0.0,
            "remaining": 0.0
        }
    )


    for invoice in invoices:

        date_value = parse_date(
            invoice.invoice_date
        )


        if not date_value:
            continue


        month_key = (
            date_value.year,
            date_value.month
        )


        monthly[month_key]["invoices"] += 1

        monthly[month_key]["total"] += float(
            invoice.total or 0
        )

        monthly[month_key]["paid"] += float(
            invoice.paid or 0
        )

        monthly[month_key]["remaining"] += float(
            invoice.remaining or 0
        )


    # =====================================================
    # ترتيب الأشهر
    # =====================================================

    months = sorted(
        monthly.keys(),
        reverse=True
    )


    # نعرض آخر 12 شهرًا فقط
    months = months[:12]


    month_names = {

        1: "كانون الثاني",

        2: "شباط",

        3: "آذار",

        4: "نيسان",

        5: "أيار",

        6: "حزيران",

        7: "تموز",

        8: "آب",

        9: "أيلول",

        10: "تشرين الأول",

        11: "تشرين الثاني",

        12: "كانون الأول"

    }


    monthly_html = ""


    for year, month in months:

        data = monthly[
            (year, month)
        ]


        monthly_html += f"""

<div class="month-card">

    <div class="month-name">

        📅

        {month_names.get(
            month,
            month
        )}

        {year}

    </div>


    <div class="month-row">

        <span>
            عدد الفواتير
        </span>

        <strong>
            {data["invoices"]}
        </strong>

    </div>


    <div class="month-row">

        <span>
            إجمالي الفواتير
        </span>

        <strong>
            {money(data["total"])}
        </strong>

    </div>


    <div class="month-row">

        <span>
            المدفوع
        </span>

        <strong>
            {money(data["paid"])}
        </strong>

    </div>


    <div class="month-row">

        <span>
            المتبقي
        </span>

        <strong>
            {money(data["remaining"])}
        </strong>

    </div>

</div>

"""


    if not monthly_html:

        monthly_html = """

<div class="empty">

    لا توجد بيانات مالية شهرية حتى الآن.

</div>

"""


    # =====================================================
    # آخر الفواتير
    # =====================================================

    latest_invoices = invoices[:10]


    invoice_rows = ""


    for invoice in latest_invoices:

        patient_name = "بدون مريض"


        if invoice.patient:

            patient_name = (
                invoice.patient.full_name
            )


        status = (
            invoice.payment_status
            or "غير مدفوعة"
        )


        if status == "مدفوعة":

            status_class = "status-paid"

        elif status == "مدفوعة جزئياً":

            status_class = "status-partial"

        else:

            status_class = "status-unpaid"


        invoice_rows += f"""

<tr>

<td>

<a
href="/billing/invoice/{invoice.id}"
style="color:#0284c7;font-weight:bold;"
>

{safe(invoice.invoice_number)}

</a>

</td>


<td>

{safe(patient_name)}

</td>


<td>

{safe(invoice.invoice_date)}

</td>


<td>

{money(invoice.total)}

</td>


<td>

{money(invoice.paid)}

</td>


<td>

{money(invoice.remaining)}

</td>


<td>

<span
class="status {status_class}"
>

{safe(status)}

</span>

</td>

</tr>

"""


    if not invoice_rows:

        invoice_rows = """

<tr>

<td
colspan="7"
class="empty"
>

لا توجد فواتير حتى الآن.

</td>

</tr>

"""


    # =====================================================
    # HTML
    # =====================================================

    content = f"""

<div class="header">

    <h1>
        📊 التقارير والإحصائيات
    </h1>

    <p>
        لوحة متابعة المرضى والوضع المالي في CLINOVA.
        البيانات المعروضة مأخوذة مباشرة من قاعدة البيانات.
    </p>

</div>


<div class="info">

    🔄

    يتم تحديث الأرقام تلقائيًا عند فتح صفحة التقارير،
    لذلك ستظهر فيها آخر البيانات المسجلة في النظام.

</div>


<!-- ===================================================
     الإحصائيات الرئيسية
=================================================== -->

<div class="stats">


    <div class="stat-card blue">

        <div class="stat-icon">
            👥
        </div>

        <div class="stat-title">
            إجمالي المرضى
        </div>

        <div class="stat-number">
            {total_patients}
        </div>

        <div class="stat-note">
            جميع المرضى المسجلين
        </div>

    </div>


    <div class="stat-card purple">

        <div class="stat-icon">
            🧾
        </div>

        <div class="stat-title">
            إجمالي الفواتير
        </div>

        <div class="stat-number">
            {total_invoices}
        </div>

        <div class="stat-note">
            جميع الفواتير المسجلة
        </div>

    </div>


    <div class="stat-card green">

        <div class="stat-icon">
            💰
        </div>

        <div class="stat-title">
            إجمالي المدفوع
        </div>

        <div class="stat-number">
            {money(total_paid)}
        </div>

        <div class="stat-note">
            المبالغ المحصلة
        </div>

    </div>


    <div class="stat-card orange">

        <div class="stat-icon">
            ⏳
        </div>

        <div class="stat-title">
            المبالغ المتبقية
        </div>

        <div class="stat-number">
            {money(total_remaining)}
        </div>

        <div class="stat-note">
            مبالغ لم يتم تحصيلها
        </div>

    </div>


</div>


<!-- ===================================================
     التقرير المالي
=================================================== -->

<div class="card">

    <div class="card-title">

        <h2>
            💵 الملخص المالي
        </h2>

        <span>
            جميع الفواتير
        </span>

    </div>


    <div class="finance-grid">


        <div class="finance-box">

            <div class="finance-label">
                إجمالي قيمة الفواتير
            </div>

            <div class="finance-value">
                {money(total_amount)}
            </div>

        </div>


        <div class="finance-box">

            <div class="finance-label">
                إجمالي المدفوع
            </div>

            <div
                class="finance-value"
                style="color:#16a34a;"
            >
                {money(total_paid)}
            </div>

        </div>


        <div class="finance-box">

            <div class="finance-label">
                إجمالي المتبقي
            </div>

            <div
                class="finance-value"
                style="color:#d97706;"
            >
                {money(total_remaining)}
            </div>

        </div>


    </div>

</div>


<!-- ===================================================
     التقرير الشهري
=================================================== -->

<div class="card">

    <div class="card-title">

        <h2>
            📅 التقرير المالي الشهري
        </h2>

        <span>
            آخر 12 شهرًا
        </span>

    </div>


    <div class="month-grid">

        {monthly_html}

    </div>

</div>


<!-- ===================================================
     آخر الفواتير
=================================================== -->

<div class="card">

    <div class="card-title">

        <h2>
            🧾 آخر الفواتير
        </h2>

        <span>
            آخر 10 فواتير
        </span>

    </div>


    <div class="table-container">

        <table>

            <thead>

                <tr>

                    <th>
                        رقم الفاتورة
                    </th>

                    <th>
                        المريض
                    </th>

                    <th>
                        التاريخ
                    </th>

                    <th>
                        الإجمالي
                    </th>

                    <th>
                        المدفوع
                    </th>

                    <th>
                        المتبقي
                    </th>

                    <th>
                        الحالة
                    </th>

                </tr>

            </thead>


            <tbody>

                {invoice_rows}

            </tbody>

        </table>

    </div>

</div>


<!-- ===================================================
     أزرار
=================================================== -->

<div class="card">

    <div class="actions">

        <a
            href="/"
            class="btn btn-secondary"
        >
            🏠 الرئيسية
        </a>


        <a
            href="/billing"
            class="btn"
        >
            💰 إدارة الفواتير
        </a>


        <button
            class="btn"
            onclick="window.location.reload()"
        >
            🔄 تحديث التقرير
        </button>


        <button
            class="btn"
            onclick="window.print()"
        >
            🖨️ طباعة التقرير
        </button>

    </div>

</div>

"""


    return html_page(
        "التقارير - CLINOVA",
        content
    )
