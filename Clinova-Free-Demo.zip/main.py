# ============================================================
# CLINOVA
# نظام إدارة العيادات الذكي والمتكامل
# main.py
# ============================================================

from pathlib import Path
from html import escape
import traceback

import uvicorn

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from starlette.middleware.sessions import SessionMiddleware


# ============================================================
# DATABASE
# ============================================================

from database import create_tables, SessionLocal


# ============================================================
# MODELS
# ============================================================

import models
import pharmacy_models
import appointments_models
from clinic_security import active_clinic, install_orm_scope
install_orm_scope()

try:
    import laboratory_models
except Exception:
    laboratory_models = None
    print("ℹ laboratory_models.py غير متاح أو يحتوي على خطأ")

try:
    import billing_models
except Exception:
    billing_models = None
    print("ℹ billing_models.py غير متاح أو يحتوي على خطأ")

try:
    import radiology_models
except Exception:
    radiology_models = None
    print("ℹ radiology_models.py غير متاح أو يحتوي على خطأ")


# ============================================================
# APPLICATION
# ============================================================

app = FastAPI(
    title="CLINOVA",
    description="نظام إدارة العيادات الذكي والمتكامل",
    version="1.0.0",
)


# ============================================================
# SETTINGS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

from settings import session_secret, session_cookie_name
SECRET_KEY = session_secret()


# ============================================================
# SESSION
# ============================================================



# ============================================================
# STATIC FILES
# ============================================================

STATIC_DIR = BASE_DIR / "static"

if STATIC_DIR.exists():
    app.mount(
        "/static",
        StaticFiles(directory=str(STATIC_DIR)),
        name="static",
    )


# ============================================================
# DATABASE INITIALIZATION
# ============================================================

try:
    create_tables()
    from database import engine
    from pharmacy_migration import migrate_pharmacy
    migrate_pharmacy(engine)
    print("✓ Database initialized successfully")

except Exception as e:
    print(
        "✗ Database initialization error:",
        type(e).__name__,
        ":",
        e,
    )
    traceback.print_exc()


# ============================================================
# HELPERS
# ============================================================

def get_db():
    """
    فتح جلسة قاعدة البيانات.
    """
    db = SessionLocal()

    try:
        yield db

    finally:
        db.close()


# ============================================================
# AUTHENTICATION MIDDLEWARE
# ============================================================

PUBLIC_PATHS = {
    "/login",
    "/logout",
    "/health",
    "/favicon.ico",
}


@app.middleware("http")
async def authentication_middleware(
    request: Request,
    call_next,
):
    path = request.url.path

    # --------------------------------------------------------
    # Public paths
    # --------------------------------------------------------

    if path in PUBLIC_PATHS:
        return await call_next(request)

    # --------------------------------------------------------
    # Static files
    # --------------------------------------------------------

    if path.startswith("/static"):
        return await call_next(request)

    # --------------------------------------------------------
    # Debug route
    # السماح بها مؤقتًا لفحص المسارات
    # --------------------------------------------------------

    # --------------------------------------------------------
    # Check session
    # --------------------------------------------------------

    logged_in = request.session.get(
        "logged_in",
        False,
    )

    if not logged_in:
        return RedirectResponse(
            url="/login",
            status_code=302,
        )

    # --------------------------------------------------------
    # Verify username
    # --------------------------------------------------------

    username = request.session.get("username")

    if not username:
        request.session.clear()

        return RedirectResponse(
            url="/login",
            status_code=302,
        )

    # --------------------------------------------------------
    # Refresh user information
    # --------------------------------------------------------

    db = SessionLocal()

    try:
        user = None

        if hasattr(models, "User"):
            try:
                user = (
                    db.query(models.User)
                    .filter(
                        models.User.username == username
                    )
                    .first()
                )

            except Exception as e:
                print(
                    "User lookup error:",
                    type(e).__name__,
                    ":",
                    e,
                )

                user = None

        # ----------------------------------------------------
        # User exists
        # ----------------------------------------------------

        if user is not None:

            # Active status
            if hasattr(user, "is_active"):

                if not user.is_active:
                    request.session.clear()

                    return RedirectResponse(
                        url="/login",
                        status_code=302,
                    )

            # ------------------------------------------------
            # Session information
            # ------------------------------------------------

            request.session["user_id"] = getattr(
                user,
                "id",
                request.session.get("user_id"),
            )

            request.session["username"] = getattr(
                user,
                "username",
                username,
            )

            request.session["full_name"] = getattr(
                user,
                "full_name",
                username,
            )

            request.session["role"] = getattr(
                user,
                "role",
                "reception",
            )

            request.session["clinic_id"] = getattr(
                user,
                "clinic_id",
                request.session.get("clinic_id"),
            )

    except Exception as e:

        print(
            "Authentication middleware error:",
            type(e).__name__,
            ":",
            e,
        )

        traceback.print_exc()

    finally:
        db.close()

    if user is not None and user.clinic_id:
        with SessionLocal() as clinic_db:
            if not clinic_db.query(models.Clinic.id).filter_by(id=user.clinic_id, is_active=True).first():
                user = None
    if user is None:
        request.session.clear()
        return RedirectResponse(url="/login", status_code=302)
    token = active_clinic.set(user.clinic_id)
    try:
        return await call_next(request)
    finally:
        active_clinic.reset(token)


# Session cookies must be decoded before the authentication middleware.
app.add_middleware(
    SessionMiddleware,
    secret_key=SECRET_KEY,
    session_cookie=session_cookie_name(),
    max_age=60 * 60 * 24 * 7,
)



# ============================================================
# HEALTH CHECK
# ============================================================

@app.get(
    "/health",
    response_class=HTMLResponse,
)
async def health():

    return """
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">

    <head>
        <meta charset="UTF-8">
        <title>CLINOVA Health</title>
    </head>

    <body>

        <h1>CLINOVA</h1>

        <p>
            النظام يعمل بشكل صحيح.
        </p>

    </body>
    </html>
    """


# ============================================================
# AUTHENTICATION ROUTER
# ============================================================

try:

    from auth import router as auth_router
    from auth import ensure_default_admin
    ensure_default_admin()

    app.include_router(auth_router)

    print("✓ Authentication router loaded")

except Exception as e:

    print(
        "✗ Authentication router error:",
        type(e).__name__,
        ":",
        e,
    )

    traceback.print_exc()


# ============================================================
# USERS
# ============================================================

try:

    from users import router as users_router

    app.include_router(users_router)

    print("✓ Users router loaded")

except Exception as e:

    print(
        "ℹ Users router not loaded:",
        type(e).__name__,
        ":",
        e,
    )


# ============================================================
# ACCOUNT
# ============================================================

try:

    from account import router as account_router

    app.include_router(account_router)

    print("✓ Account router loaded")

except Exception as e:

    print(
        "ℹ Account router not loaded:",
        type(e).__name__,
        ":",
        e,
    )


# ============================================================
# PATIENTS
# ============================================================

try:

    from patients import router as patients_router

    app.include_router(patients_router)

    print("✓ Patients router loaded")

    # Clinical history/detail routes complement the patient management forms.
    from visits import router as visit_history_router
    from clinic_security import section_guard
    visit_history_router.routes[:] = [route for route in visit_history_router.routes
        if route.path in {"/patients/{patient_id}/visits", "/visits/patient/{patient_id}", "/visits/{visit_id}", "/visits/new/{patient_id}"}]
    app.include_router(visit_history_router, dependencies=[section_guard("visits")])

except Exception as e:

    print(
        "✗ Patients router error:",
        type(e).__name__,
        ":",
        e,
    )

    traceback.print_exc()


# ============================================================
# GYNECOLOGY
# ============================================================

try:

    from gynecology import router as gynecology_router

    app.include_router(gynecology_router)

    print("✓ Gynecology router loaded")

except Exception as e:

    print(
        "✗ Gynecology router error:",
        type(e).__name__,
        ":",
        e,
    )

    traceback.print_exc()


# ============================================================
# LABORATORY
# ============================================================

try:

    from laboratory import router as laboratory_router

    app.include_router(laboratory_router)

    print("✓ Laboratory router loaded")

except Exception as e:

    print(
        "✗ Laboratory router error:",
        type(e).__name__,
        ":",
        e,
    )

    traceback.print_exc()


# ============================================================
# APPOINTMENTS
# ============================================================

try:

    from appointments import router as appointments_router

    app.include_router(appointments_router)

    print("✓ Appointments router loaded")

except Exception as e:

    print(
        "✗ Appointments router error:",
        type(e).__name__,
        ":",
        e,
    )

    traceback.print_exc()


# ============================================================
# DOCTORS
# ============================================================

try:

    from doctors import router as doctors_router

    app.include_router(doctors_router)

    print("✓ Doctors router loaded")

except Exception as e:

    print(
        "✗ Doctors router error:",
        type(e).__name__,
        ":",
        e,
    )

    traceback.print_exc()


# ============================================================
# BILLING
# ============================================================

try:

    from billing import router as billing_router

    app.include_router(billing_router)

    print("✓ Billing router loaded")

except Exception as e:

    print(
        "✗ Billing router error:",
        type(e).__name__,
        ":",
        e,
    )

    traceback.print_exc()


# ============================================================
# REPORTS
# ============================================================

from pharmacy import router as pharmacy_router
app.include_router(pharmacy_router)

try:

    from reports import router as reports_router

    app.include_router(reports_router)

    print("✓ Reports router loaded")

except Exception as e:

    print(
        "✗ Reports router error:",
        type(e).__name__,
        ":",
        e,
    )

    traceback.print_exc()


# ============================================================
# RADIOLOGY
# التصوير الشعاعي
# ============================================================

RADIOLOGY_LOADED = False
RADIOLOGY_ERROR = None

try:

    from radiology import router as radiology_router

    if radiology_router is None:
        raise RuntimeError(
            "radiology.py يحتوي router = None"
        )

    app.include_router(radiology_router)

    RADIOLOGY_LOADED = True

    print("✓ Radiology router loaded")

except Exception as e:

    RADIOLOGY_LOADED = False
    RADIOLOGY_ERROR = (
        f"{type(e).__name__}: {e}"
    )

    print(
        "✗ Radiology router error:",
        RADIOLOGY_ERROR,
    )

    traceback.print_exc()


# ============================================================
# RADIOLOGY ROUTES CHECK
# ============================================================

print("")
print("=" * 60)
print("CLINOVA - RADIOLOGY ROUTES CHECK")
print("=" * 60)

radiology_routes_found = []

for route in (radiology_router.routes if RADIOLOGY_LOADED else []):

    if not hasattr(route, "path"):
        continue

    if not route.path.startswith("/radiology"):
        continue

    radiology_routes_found.append(route)

    methods = getattr(
        route,
        "methods",
        set(),
    )

    print(
        f"✓ {sorted(methods)} {route.path}"
    )


if not radiology_routes_found:

    print(
        "✗ WARNING: No Radiology routes registered!"
    )

    if RADIOLOGY_ERROR:
        print(
            "✗ Radiology import error:"
        )
        print(
            RADIOLOGY_ERROR
        )

else:

    print(
        f"✓ Total Radiology routes: "
        f"{len(radiology_routes_found)}"
    )

print("=" * 60)
print("")


# ============================================================
# ROOT / DASHBOARD
# ============================================================

@app.get(
    "/",
    response_class=HTMLResponse,
)
async def dashboard(
    request: Request,
):

    username = request.session.get(
        "username",
        "admin",
    )

    full_name = request.session.get(
        "full_name",
        username,
    )

    role = request.session.get(
        "role",
        "reception",
    )

    clinic_id = request.session.get(
        "clinic_id",
        1,
    )

    is_admin = role == "admin"

    safe_username = escape(
        str(username)
    )

    safe_full_name = escape(
        str(full_name)
    )

    safe_role = escape(
        str(role)
    )

    # --------------------------------------------------------
    # Users module
    # --------------------------------------------------------

    users_module = ""

    if is_admin:

        users_module = """
        <a href="/users" class="module-card">

            <div class="module-icon">
                👥
            </div>

            <div class="module-title">
                المستخدمون
            </div>

            <div class="module-description">
                إدارة المستخدمين والصلاحيات
            </div>

        </a>
        """

    # --------------------------------------------------------
    # Radiology status
    # --------------------------------------------------------

    if RADIOLOGY_LOADED:

        radiology_status = """
        <div class="module-status success">
            ● متاح
        </div>
        """

    else:

        radiology_status = """
        <div class="module-status error">
            ● يحتاج إصلاح
        </div>
        """

    # --------------------------------------------------------
    # Dashboard HTML
    # --------------------------------------------------------

    html = f"""
<!DOCTYPE html>

<html lang="ar" dir="rtl">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        CLINOVA - نظام إدارة العيادات
    </title>

    <style>

        * {{
            box-sizing: border-box;
        }}

        body {{
            margin: 0;

            font-family:
                Tahoma,
                Arial,
                sans-serif;

            background:
                linear-gradient(
                    135deg,
                    #f5f7fb,
                    #eef2f7
                );

            color: #1f2937;
        }}

        .topbar {{
            background:
                linear-gradient(
                    135deg,
                    #0f172a,
                    #1e293b
                );

            color: white;

            padding: 18px 30px;

            display: flex;

            justify-content:
                space-between;

            align-items: center;

            box-shadow:
                0 5px 20px
                rgba(0,0,0,.12);
        }}

        .brand {{
            display: flex;

            align-items: center;

            gap: 14px;
        }}

        .brand-logo {{
            width: 52px;
            height: 52px;

            border-radius: 14px;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #06b6d4
                );

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 25px;

            font-weight: bold;
        }}

        .brand-text h1 {{
            margin: 0;
            font-size: 23px;
        }}

        .brand-text p {{
            margin: 5px 0 0;
            opacity: .8;
            font-size: 13px;
        }}

        .user-box {{
            display: flex;

            align-items: center;

            gap: 15px;
        }}

        .user-info {{
            text-align: left;
        }}

        .user-name {{
            font-weight: bold;
        }}

        .user-role {{
            font-size: 12px;
            opacity: .75;
        }}

        .logout {{
            color: white;

            text-decoration: none;

            background:
                rgba(255,255,255,.12);

            padding: 9px 15px;

            border-radius: 9px;
        }}

        .logout:hover {{
            background:
                rgba(255,255,255,.2);
        }}

        .container {{
            max-width: 1400px;

            margin: 35px auto;

            padding: 0 22px;
        }}

        .welcome {{
            background: white;

            border-radius: 18px;

            padding: 25px;

            margin-bottom: 25px;

            box-shadow:
                0 8px 25px
                rgba(15,23,42,.07);
        }}

        .welcome h2 {{
            margin-top: 0;
            margin-bottom: 8px;
        }}

        .welcome p {{
            margin: 0;

            color: #64748b;
        }}

        .modules {{
            display: grid;

            grid-template-columns:
                repeat(
                    auto-fit,
                    minmax(210px, 1fr)
                );

            gap: 18px;
        }}

        .module-card {{
            display: block;

            position: relative;

            text-decoration: none;

            background: white;

            border-radius: 17px;

            padding: 24px;

            color: #1f2937;

            box-shadow:
                0 7px 22px
                rgba(15,23,42,.06);

            border:
                1px solid
                #e5e7eb;

            transition:
                .2s ease;
        }}

        .module-card:hover {{
            transform:
                translateY(-4px);

            box-shadow:
                0 14px 30px
                rgba(15,23,42,.12);
        }}

        .module-icon {{
            font-size: 35px;

            margin-bottom: 14px;
        }}

        .module-title {{
            font-size: 18px;

            font-weight: bold;

            margin-bottom: 7px;
        }}

        .module-description {{
            font-size: 13px;

            color: #64748b;

            line-height: 1.7;
        }}

        .module-status {{
            position: absolute;

            top: 14px;

            left: 14px;

            font-size: 11px;

            padding:
                4px 8px;

            border-radius: 20px;
        }}

        .module-status.success {{
            background: #dcfce7;

            color: #166534;
        }}

        .module-status.error {{
            background: #fee2e2;

            color: #991b1b;
        }}

        .quick-title {{
            margin:
                35px 0 15px;

            font-size: 20px;
        }}

        .quick-actions {{
            display: flex;

            flex-wrap: wrap;

            gap: 12px;
        }}

        .quick-action {{
            display: inline-block;

            text-decoration: none;

            background: white;

            color: #1e293b;

            padding:
                12px 18px;

            border-radius: 10px;

            border:
                1px solid #e2e8f0;

            transition: .2s;
        }}

        .quick-action:hover {{
            background: #f8fafc;

            transform:
                translateY(-2px);
        }}

        .footer {{
            text-align: center;

            padding:
                30px 15px;

            color: #64748b;

            font-size: 13px;
        }}

        @media
        (max-width: 700px) {{

            .topbar {{
                flex-direction: column;

                gap: 15px;

                text-align: center;
            }}

            .user-box {{
                flex-direction: column;
            }}

            .user-info {{
                text-align: center;
            }}

        }}

    </style>

</head>


<body>


<header class="topbar">

    <div class="brand">

        <div class="brand-logo">
            C
        </div>

        <div class="brand-text">

            <h1>
                CLINOVA
            </h1>

            <p>
                نظام إدارة العيادات الذكي والمتكامل
            </p>

        </div>

    </div>


    <div class="user-box">

        <div class="user-info">

            <div class="user-name">
                {safe_full_name}
            </div>

            <div class="user-role">
                {safe_role}
            </div>

        </div>

        <a
            href="/logout"
            class="logout"
        >
            تسجيل الخروج
        </a>

    </div>

</header>


<main class="container">


    <section class="welcome">

        <h2>
            أهلاً بك، {safe_full_name} 👋
        </h2>

        <p>
            إدارة أسهل • تنظيم أفضل • قرارات أسرع
        </p>

    </section>


    <section class="modules">


        <a
            href="/patients"
            class="module-card"
        >

            <div class="module-icon">
                👨‍⚕️
            </div>

            <div class="module-title">
                المرضى
            </div>

            <div class="module-description">
                إدارة ملفات المرضى والسجل الطبي
            </div>

        </a>


        <a
            href="/doctors"
            class="module-card"
        >

            <div class="module-icon">
                🩺
            </div>

            <div class="module-title">
                الأطباء
            </div>

            <div class="module-description">
                إدارة الأطباء والتخصصات
            </div>

        </a>


        <a
            href="/appointments"
            class="module-card"
        >

            <div class="module-icon">
                📅
            </div>

            <div class="module-title">
                المواعيد
            </div>

            <div class="module-description">
                تنظيم مواعيد المرضى والزيارات
            </div>

        </a>


        <a
            href="/gynecology"
            class="module-card"
        >

            <div class="module-icon">
                👩
            </div>

            <div class="module-title">
                العيادة النسائية
            </div>

            <div class="module-description">
                متابعة الحالات النسائية والحمل والولادة
            </div>

        </a>


        <a
            href="/laboratory"
            class="module-card"
        >

            <div class="module-icon">
                🧪
            </div>

            <div class="module-title">
                المختبر
            </div>

            <div class="module-description">
                إدارة الفحوصات والطلبات والنتائج
            </div>

        </a>


        <a
            href="/radiology"
            class="module-card"
        >

            {radiology_status}

            <div class="module-icon">
                🩻
            </div>

            <div class="module-title">
                التصوير الشعاعي
            </div>

            <div class="module-description">
                إدارة طلبات التصوير الشعاعي والتقارير
            </div>

        </a>


        <a href="/pharmacy" class="module-card">
            <div class="module-icon">💊</div>
            <div class="module-title">الصيدلية</div>
            <div class="module-description">مخزون الأدوية والوصفات والصرف والصلاحية</div>
        </a>

        <a
            href="/billing"
            class="module-card"
        >

            <div class="module-icon">
                💳
            </div>

            <div class="module-title">
                الفوترة
            </div>

            <div class="module-description">
                الفواتير والخدمات والمدفوعات
            </div>

        </a>


        <a
            href="/reports"
            class="module-card"
        >

            <div class="module-icon">
                📊
            </div>

            <div class="module-title">
                التقارير
            </div>

            <div class="module-description">
                التقارير الإدارية والمالية والطبية
            </div>

        </a>


        {users_module}


    </section>


    <h3 class="quick-title">
        الوصول السريع
    </h3>


    <div class="quick-actions">

        <a
            href="/patients"
            class="quick-action"
        >
            👥 المرضى
        </a>

        <a
            href="/appointments"
            class="quick-action"
        >
            📅 المواعيد
        </a>

        <a
            href="/laboratory"
            class="quick-action"
        >
            🧪 المختبر
        </a>

        <a
            href="/radiology"
            class="quick-action"
        >
            🩻 التصوير الشعاعي
        </a>

        <a
            href="/billing"
            class="quick-action"
        >
            💳 الفوترة
        </a>

        <a
            href="/reports"
            class="quick-action"
        >
            📊 التقارير
        </a>

    </div>


</main>


<footer class="footer">

    CLINOVA © 2026

    <br>

    نظام إدارة العيادات الذكي والمتكامل

</footer>


</body>

</html>
"""

    return HTMLResponse(
        content=html
    )


# ============================================================
# DEBUG ROUTES
# ============================================================

@app.get(
    "/__routes",
    response_class=HTMLResponse,
)
async def show_routes(request: Request):

    if request.session.get("role") != "admin":
        raise HTTPException(403, "هذه الصفحة متاحة للمدير فقط")

    rows = []

    for path, operations in app.openapi()["paths"].items():
        methods_text = ", ".join(method.upper() for method in operations if method in {"get", "post", "put", "patch", "delete"})
        rows.append(f"<tr><td>{escape(methods_text)}</td><td>{escape(path)}</td></tr>")

    html = f"""
    <!DOCTYPE html>

    <html lang="ar" dir="rtl">

    <head>

        <meta charset="UTF-8">

        <title>
            CLINOVA Routes
        </title>

        <style>

            body {{
                font-family:
                    Tahoma,
                    Arial;

                background:
                    #f5f7fb;

                padding: 30px;
            }}

            table {{
                width: 100%;

                border-collapse:
                    collapse;

                background:
                    white;
            }}

            th,
            td {{
                padding: 12px;

                border:
                    1px solid #ddd;

                text-align:
                    right;
            }}

            th {{
                background:
                    #1e293b;

                color:
                    white;
            }}

            tr:nth-child(even) {{
                background:
                    #f8fafc;
            }}

        </style>

    </head>

    <body>

        <h1>
            CLINOVA - Routes
        </h1>

        <p>
            Radiology loaded:
            <strong>
                {str(RADIOLOGY_LOADED)}
            </strong>
        </p>

        <p>
            Radiology error:
            <strong>
                {escape(str(RADIOLOGY_ERROR or "لا يوجد"))}
            </strong>
        </p>

        <table>

            <thead>

                <tr>

                    <th>
                        Methods
                    </th>

                    <th>
                        Path
                    </th>

                </tr>

            </thead>

            <tbody>

                {"".join(rows)}

            </tbody>

        </table>

    </body>

    </html>
    """

    return HTMLResponse(
        content=html
    )


# ============================================================
# START APPLICATION
# ============================================================

if __name__ == "__main__":

    print("")
    print("=" * 60)

    print(
        "CLINOVA"
    )

    print(
        "نظام إدارة العيادات الذكي والمتكامل"
    )

    print("=" * 60)

    print(
        "✓ Server:"
    )

    print(
        "http://127.0.0.1:8000"
    )

    print("")

    print(
        "✓ Routes:"
    )

    print(
        "http://127.0.0.1:8000/__routes"
    )

    print("")

    print(
        "✓ Radiology:"
    )

    print(
        "http://127.0.0.1:8000/radiology"
    )

    print("")

    print(
        "✓ Radiology New:"
    )

    print(
        "http://127.0.0.1:8000/radiology/new"
    )

    print("=" * 60)

    print("")

    uvicorn.run(
        app,
        host="127.0.0.1",
        port=8000,
        reload=False,
    )
