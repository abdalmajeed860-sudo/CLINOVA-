
# =========================================================
# CLINOVA
# نظام إدارة العيادات الذكي والمتكامل
# billing_models.py
# =========================================================

from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    Text,
    ForeignKey,
)

from sqlalchemy.orm import relationship

from database import Base

from laboratory_models import Service


# =========================================================
# الفواتير
# =========================================================

class Invoice(Base):

    __tablename__ = "invoices"

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )

    invoice_number = Column(
        String,
        unique=True,
        nullable=False,
    )

    barcode = Column(
        String(64),
        unique=True,
        index=True,
        nullable=True,
    )

    patient_id = Column(
        Integer,
        ForeignKey("patients.id"),
        nullable=False,
    )

    doctor_id = Column(
        Integer,
        nullable=True,
    )

    invoice_date = Column(
        String,
        nullable=False,
    )

    subtotal = Column(
        Float,
        default=0,
    )

    discount = Column(
        Float,
        default=0,
    )

    total = Column(
        Float,
        default=0,
    )

    paid = Column(
        Float,
        default=0,
    )

    remaining = Column(
        Float,
        default=0,
    )

    payment_method = Column(
        String,
        default="نقدي",
    )

    payment_status = Column(
        String,
        default="غير مدفوعة",
    )

    notes = Column(
        Text,
        nullable=True,
    )

    created_at = Column(
        String,
        nullable=True,
    )

    # =====================================================
    # العلاقات
    # =====================================================

    patient = relationship(
        "Patient",
        foreign_keys=[patient_id],
    )

    # ملاحظة:
    # لا نضع relationship("Doctor") حاليًا حتى لا يتوقف
    # SQLAlchemy بسبب عدم وجود موديل Doctor.
    #
    # doctor_id يبقى موجودًا ويمكن استخدامه لاحقًا بعد
    # إضافة موديل الأطباء بشكل صحيح.

    items = relationship(
        "InvoiceItem",
        back_populates="invoice",
        cascade="all, delete-orphan",
    )

    payments = relationship(
        "Payment",
        back_populates="invoice",
        cascade="all, delete-orphan",
    )


# =========================================================
# بنود الفاتورة
# =========================================================

class InvoiceItem(Base):

    __tablename__ = "invoice_items"

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )

    invoice_id = Column(
        Integer,
        ForeignKey("invoices.id"),
        nullable=False,
    )

    service_id = Column(
        Integer,
        ForeignKey("services.id"),
        nullable=True,
    )

    service_name = Column(
        String,
        nullable=True,
    )

    description = Column(
        Text,
        nullable=True,
    )

    quantity = Column(
        Integer,
        default=1,
    )

    unit_price = Column(
        Float,
        default=0,
    )

    total = Column(
        Float,
        default=0,
    )

    created_at = Column(
        String,
        nullable=True,
    )

    # =====================================================
    # العلاقات
    # =====================================================

    invoice = relationship(
        "Invoice",
        back_populates="items",
    )

    service = relationship(
        "Service",
        foreign_keys=[service_id],
    )


# =========================================================
# الدفعات
# =========================================================

class Payment(Base):

    __tablename__ = "payments"

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )

    invoice_id = Column(
        Integer,
        ForeignKey("invoices.id"),
        nullable=False,
    )

    payment_date = Column(
        String,
        nullable=False,
    )

    amount = Column(
        Float,
        default=0,
    )

    payment_method = Column(
        String,
        default="نقدي",
    )

    reference_number = Column(
        String,
        nullable=True,
    )

    notes = Column(
        Text,
        nullable=True,
    )

    created_at = Column(
        String,
        nullable=True,
    )

    # =====================================================
    # العلاقة مع الفاتورة
    # =====================================================

    invoice = relationship(
        "Invoice",
        back_populates="payments",
    )
