# visits.py
# ============================================================
# CLINOVA - نظام إدارة الزيارات
# ============================================================

from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from database import engine
from clinic_security import tenant_text as text
from datetime import datetime


router = APIRouter()


@router.get("/visits/new/{patient_id}")
def legacy_new_visit(patient_id: int):
    return RedirectResponse(f"/patients/{patient_id}/visits/new", status_code=303)


# ============================================================
# أدوات مساعدة
# ============================================================

def get_patient(patient_id):
    """
    جلب بيانات المريض مباشرة من قاعدة البيانات
    لتجنب مشاكل SQLAlchemy مع التواريخ القديمة.
    """
    with engine.connect() as conn:
        result = conn.execute(
            text("""
                SELECT
                    id,
                    medical_number,
                    file_number,
                    full_name,
                    gender,
                    birth_date,
                    phone,
                    address,
                    blood_type,
                    allergies,
                    chronic_diseases,
                    notes
                FROM patients
                WHERE id = :patient_id
            """),
            {"patient_id": patient_id}
        )

        row = result.fetchone()

        if not row:
            return None

        return dict(row._mapping)


def get_visits(patient_id):
    """
    جلب جميع زيارات المريض.
    """
    with engine.connect() as conn:
        result = conn.execute(
            text("""
                SELECT
                    id,
                    patient_id,
                    visit_date,
                    doctor_name,
                    chief_complaint,
                    examination,
                    diagnosis,
                    treatment,
                    prescription,
                    lab_requests,
                    radiology_requests,
                    notes,
                    created_at
                FROM visits
                WHERE patient_id = :patient_id
                ORDER BY visit_date DESC, id DESC
            """),
            {"patient_id": patient_id}
        )

        return [dict(row._mapping) for row in result.fetchall()]


def get_visit(visit_id):
    """
    جلب زيارة واحدة.
    """
    with engine.connect() as conn:
        result = conn.execute(
            text("""
                SELECT
                    id,
                    patient_id,
                    visit_date,
                    doctor_name,
                    chief_complaint,
                    examination,
                    diagnosis,
                    treatment,
                    prescription,
                    lab_requests,
                    radiology_requests,
                    notes,
                    created_at
                FROM visits
                WHERE id = :visit_id
            """),
            {"visit_id": visit_id}
        )

        row = result.fetchone()

        if not row:
            return None

        return dict(row._mapping)


def safe(value):
    """
    حماية النصوص التي ستظهر في HTML.
    """
    if value is None:
        return ""

    value = str(value)

    return (
        value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#039;")
    )


def format_date(value):
    """
    تنسيق التاريخ للعرض.
    """
    if not value:
        return "-"

    try:
        if isinstance(value, datetime):
            return value.strftime("%Y-%m-%d %H:%M")

        value = str(value)

        if len(value) >= 16:
            return value[:16]

        return value

    except Exception:
        return str(value)


def page(title, content):
    """
    قالب HTML موحد.
    """

    return f"""
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>{safe(title)} - CLINOVA</title>

<style>

* {{
    box-sizing: border-box;
}}

body {{
    margin: 0;
    font-family: Tahoma, Arial, sans-serif;
    background: #f4f7fb;
    color: #1f2937;
}}

.header {{
    background: linear-gradient(135deg, #0f766e, #0e7490);
    color: white;
    padding: 20px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}}

.logo {{
    font-size: 25px;
    font-weight: bold;
}}

.subtitle {{
    font-size: 13px;
    opacity: .9;
    margin-top: 5px;
}}

.container {{
    width: min(1200px, 94%);
    margin: 25px auto;
}}

.card {{
    background: white;
    border-radius: 18px;
    padding: 24px;
    margin-bottom: 20px;
    box-shadow: 0 8px 25px rgba(15, 23, 42, .07);
}}

.patient-header {{
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}}

.patient-name {{
    font-size: 25px;
    font-weight: bold;
    color: #0f766e;
}}

.patient-info {{
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 12px;
}}

.info {{
    background: #f0fdfa;
    border: 1px solid #ccfbf1;
    padding: 8px 13px;
    border-radius: 10px;
    font-size: 14px;
}}

.actions {{
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}}

.btn {{
    display: inline-block;
    padding: 11px 17px;
    border-radius: 10px;
    text-decoration: none;
    border: none;
    cursor: pointer;
    font-size: 14px;
    font-weight: bold;
}}

.btn-primary {{
    background: #0f766e;
    color: white;
}}

.btn-secondary {{
    background: #e0f2fe;
    color: #075985;
}}

.btn-dark {{
    background: #334155;
    color: white;
}}

.btn-danger {{
    background: #dc2626;
    color: white;
}}

.btn:hover {{
    opacity: .9;
}}

.visit {{
    border: 1px solid #e5e7eb;
    border-radius: 15px;
    padding: 20px;
    margin-bottom: 15px;
    background: #fff;
}}

.visit-top {{
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}}

.visit-number {{
    background: #0f766e;
    color: white;
    border-radius: 20px;
    padding: 6px 12px;
    font-size: 13px;
}}

.visit-date {{
    color: #64748b;
    font-size: 14px;
}}

.doctor {{
    margin-top: 10px;
    color: #475569;
}}

.grid {{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 18px;
}}

.field {{
    margin-bottom: 18px;
}}

.field.full {{
    grid-column: 1 / -1;
}}

label {{
    display: block;
    font-weight: bold;
    margin-bottom: 7px;
    color: #334155;
}}

input,
textarea,
select {{
    width: 100%;
    border: 1px solid #cbd5e1;
    border-radius: 10px;
    padding: 12px;
    font-family: inherit;
    font-size: 14px;
    outline: none;
    background: white;
}}

input:focus,
textarea:focus,
select:focus {{
    border-color: #0f766e;
    box-shadow: 0 0 0 3px rgba(15,118,110,.1);
}}

textarea {{
    min-height: 110px;
    resize: vertical;
}}

.section-title {{
    font-size: 19px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #0f766e;
}}

.empty {{
    text-align: center;
    padding: 45px 20px;
    color: #64748b;
}}

.empty-icon {{
    font-size: 45px;
    margin-bottom: 10px;
}}

.detail-grid {{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 18px;
}}

.detail {{
    background: #f8fafc;
    border-radius: 12px;
    padding: 15px;
}}

.detail-title {{
    color: #64748b;
    font-size: 13px;
    margin-bottom: 7px;
}}

.detail-value {{
    font-weight: bold;
    white-space: pre-wrap;
    line-height: 1.8;
}}

.alert {{
    background: #fef2f2;
    color: #991b1b;
    border: 1px solid #fecaca;
    padding: 15px;
    border-radius: 10px;
}}

@media(max-width: 700px) {{

    .grid,
    .detail-grid {{
        grid-template-columns: 1fr;
    }}

    .header {{
        padding: 17px;
    }}

    .container {{
        width: 95%;
    }}

    .card {{
        padding: 17px;
    }}

}}

</style>

</head>

<body>

<header class="header">

    <div>
        <div class="logo">CLINOVA</div>
        <div class="subtitle">
            نظام إدارة العيادات الذكي والمتكامل
        </div>
    </div>

    <div>
        <a href="/" class="btn btn-secondary">
            🏠 الرئيسية
        </a>
    </div>

</header>

<div class="container">

{content}

</div>

</body>

</html>
"""


# ============================================================
# صفحة جميع زيارات المريض
# ============================================================

@router.get(
    "/visits/patient/{patient_id}",
    response_class=HTMLResponse
)
@router.get("/patients/{patient_id}/visits", response_class=HTMLResponse)
def patient_visits(patient_id: int):

    patient = get_patient(patient_id)

    if not patient:

        return HTMLResponse(
            page(
                "المريض غير موجود",
                """
                <div class="card">
                    <div class="alert">
                        المريض المطلوب غير موجود في قاعدة البيانات.
                    </div>

                    <br>

                    <a href="/patients"
                       class="btn btn-primary">
                        العودة إلى المرضى
                    </a>
                </div>
                """
            ),
            status_code=404
        )

    visits = get_visits(patient_id)

    visits_html = ""

    if visits:

        for index, visit in enumerate(visits, 1):

            visits_html += f"""
            <div class="visit">

                <div class="visit-top">

                    <div>
                        <span class="visit-number">
                            زيارة #{len(visits) - index + 1}
                        </span>

                        <span class="visit-date">
                            {safe(format_date(visit["visit_date"]))}
                        </span>
                    </div>

                    <a href="/visits/{visit["id"]}"
                       class="btn btn-secondary">
                        عرض التفاصيل
                    </a>

                </div>

                <div class="doctor">
                    👨‍⚕️ الطبيب:
                    <strong>
                        {safe(visit["doctor_name"]) or "غير محدد"}
                    </strong>
                </div>

                <div style="margin-top:12px">

                    <strong>الشكوى الرئيسية:</strong>

                    {safe(visit["chief_complaint"]) or "لا توجد"}

                </div>

                <div style="margin-top:8px">

                    <strong>التشخيص:</strong>

                    {safe(visit["diagnosis"]) or "لم يتم تسجيل تشخيص"}

                </div>

            </div>
            """

    else:

        visits_html = """
        <div class="empty">

            <div class="empty-icon">
                🩺
            </div>

            <h3>
                لا توجد زيارات مسجلة
            </h3>

            <p>
                يمكنك تسجيل أول زيارة لهذا المريض.
            </p>

        </div>
        """

    content = f"""

    <div class="card">

        <div class="patient-header">

            <div>

                <div class="patient-name">
                    {safe(patient["full_name"])}
                </div>

                <div class="patient-info">

                    <div class="info">
                        رقم الملف:
                        {safe(patient["file_number"]) or "-"}
                    </div>

                    <div class="info">
                        الرقم الطبي:
                        {safe(patient["medical_number"]) or "-"}
                    </div>

                    <div class="info">
                        الهاتف:
                        {safe(patient["phone"]) or "-"}
                    </div>

                </div>

            </div>

            <div class="actions">

                <a href="/visits/new/{patient_id}"
                   class="btn btn-primary">

                    ➕ زيارة جديدة

                </a>

                <a href="/patients/{patient_id}"
                   class="btn btn-dark">

                    📁 ملف المريض

                </a>

            </div>

        </div>

    </div>


    <div class="card">

        <div class="section-title">

            🩺 سجل الزيارات

            <span style="
                font-size:13px;
                color:#64748b;
                margin-right:10px;
            ">

                ({len(visits)} زيارة)

            </span>

        </div>

        {visits_html}

    </div>

    """

    return HTMLResponse(page("زيارات المريض", content))


# ============================================================
# صفحة إضافة زيارة جديدة
# ============================================================

@router.get(
    "/visits/new/{patient_id}",
    response_class=HTMLResponse
)
def new_visit_page(patient_id: int):

    patient = get_patient(patient_id)

    if not patient:

        return HTMLResponse(
            page(
                "المريض غير موجود",
                """
                <div class="card">
                    <div class="alert">
                        المريض غير موجود.
                    </div>
                </div>
                """
            ),
            status_code=404
        )

    content = f"""

    <div class="card">

        <div class="patient-header">

            <div>

                <div class="patient-name">
                    إضافة زيارة جديدة
                </div>

                <div style="
                    margin-top:8px;
                    color:#64748b;
                ">

                    المريض:
                    <strong>
                        {safe(patient["full_name"])}
                    </strong>

                </div>

            </div>

            <div class="actions">

                <a href="/visits/patient/{patient_id}"
                   class="btn btn-secondary">

                    🩺 سجل الزيارات

                </a>

                <a href="/patients/{patient_id}"
                   class="btn btn-dark">

                    📁 ملف المريض

                </a>

            </div>

        </div>

    </div>


    <form method="post"
          action="/visits/new/{patient_id}">

        <div class="card">

            <div class="section-title">
                معلومات الزيارة
            </div>

            <div class="grid">

                <div class="field">

                    <label>
                        تاريخ ووقت الزيارة
                    </label>

                    <input
                        type="datetime-local"
                        name="visit_date"
                        value="{datetime.now().strftime("%Y-%m-%dT%H:%M")}"
                    >

                </div>


                <div class="field">

                    <label>
                        الطبيب
                    </label>

                    <input
                        type="text"
                        name="doctor_name"
                        placeholder="اسم الطبيب"
                    >

                </div>


                <div class="field full">

                    <label>
                        الشكوى الرئيسية
                    </label>

                    <textarea
                        name="chief_complaint"
                        placeholder="ما هي الشكوى الرئيسية للمريض؟"
                    ></textarea>

                </div>


                <div class="field full">

                    <label>
                        الفحص السريري
                    </label>

                    <textarea
                        name="examination"
                        placeholder="نتائج الفحص السريري..."
                    ></textarea>

                </div>


                <div class="field full">

                    <label>
                        التشخيص
                    </label>

                    <textarea
                        name="diagnosis"
                        placeholder="التشخيص الطبي..."
                    ></textarea>

                </div>


                <div class="field full">

                    <label>
                        العلاج
                    </label>

                    <textarea
                        name="treatment"
                        placeholder="الخطة العلاجية..."
                    ></textarea>

                </div>


                <div class="field full">

                    <label>
                        الوصفة الطبية
                    </label>

                    <textarea
                        name="prescription"
                        placeholder="الأدوية والجرعات والتعليمات..."
                    ></textarea>

                </div>


                <div class="field">

                    <label>
                        طلبات التحاليل
                    </label>

                    <textarea
                        name="lab_requests"
                        placeholder="التحاليل المطلوبة..."
                    ></textarea>

                </div>


                <div class="field">

                    <label>
                        طلبات التصوير الشعاعي
                    </label>

                    <textarea
                        name="radiology_requests"
                        placeholder="X-Ray / CT / MRI / Ultrasound..."
                    ></textarea>

                </div>


                <div class="field full">

                    <label>
                        ملاحظات الطبيب
                    </label>

                    <textarea
                        name="notes"
                        placeholder="أي ملاحظات إضافية..."
                    ></textarea>

                </div>

            </div>

        </div>


        <div class="card">

            <div class="actions">

                <button
                    type="submit"
                    class="btn btn-primary">

                    💾 حفظ الزيارة

                </button>

                <a
                    href="/visits/patient/{patient_id}"
                    class="btn btn-dark">

                    إلغاء

                </a>

            </div>

        </div>

    </form>

    """

    return HTMLResponse(page("زيارة جديدة", content))


# ============================================================
# حفظ الزيارة
# ============================================================

@router.post(
    "/visits/new/{patient_id}"
)
def create_visit(

    patient_id: int,

    visit_date: str = Form(""),

    doctor_name: str = Form(""),

    chief_complaint: str = Form(""),

    examination: str = Form(""),

    diagnosis: str = Form(""),

    treatment: str = Form(""),

    prescription: str = Form(""),

    lab_requests: str = Form(""),

    radiology_requests: str = Form(""),

    notes: str = Form("")

):

    patient = get_patient(patient_id)

    if not patient:

        return HTMLResponse(
            page(
                "خطأ",
                """
                <div class="card">

                    <div class="alert">
                        المريض غير موجود.
                    </div>

                </div>
                """
            ),
            status_code=404
        )

    # إذا لم يرسل المستخدم تاريخاً
    if not visit_date:

        visit_date = datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

    else:

        # تحويل datetime-local
        visit_date = visit_date.replace("T", " ")

        if len(visit_date) == 16:
            visit_date += ":00"

    created_at = datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )

    with engine.begin() as conn:

        conn.execute(
            text("""
                INSERT INTO visits (
                    patient_id,
                    visit_date,
                    doctor_name,
                    chief_complaint,
                    examination,
                    diagnosis,
                    treatment,
                    prescription,
                    lab_requests,
                    radiology_requests,
                    notes,
                    created_at
                )
                VALUES (
                    :patient_id,
                    :visit_date,
                    :doctor_name,
                    :chief_complaint,
                    :examination,
                    :diagnosis,
                    :treatment,
                    :prescription,
                    :lab_requests,
                    :radiology_requests,
                    :notes,
                    :created_at
                )
            """),
            {
                "patient_id": patient_id,
                "visit_date": visit_date,
                "doctor_name": doctor_name.strip(),
                "chief_complaint": chief_complaint.strip(),
                "examination": examination.strip(),
                "diagnosis": diagnosis.strip(),
                "treatment": treatment.strip(),
                "prescription": prescription.strip(),
                "lab_requests": lab_requests.strip(),
                "radiology_requests": radiology_requests.strip(),
                "notes": notes.strip(),
                "created_at": created_at
            }
        )

    return RedirectResponse(
        url=f"/visits/patient/{patient_id}",
        status_code=303
    )


# ============================================================
# تفاصيل زيارة واحدة
# ============================================================

@router.get(
    "/visits/{visit_id}",
    response_class=HTMLResponse
)
def visit_details(visit_id: int):

    visit = get_visit(visit_id)

    if not visit:

        return HTMLResponse(
            page(
                "الزيارة غير موجودة",
                """
                <div class="card">

                    <div class="alert">
                        الزيارة المطلوبة غير موجودة.
                    </div>

                    <br>

                    <a href="/patients"
                       class="btn btn-primary">

                        العودة إلى المرضى

                    </a>

                </div>
                """
            ),
            status_code=404
        )

    patient = get_patient(visit["patient_id"])

    patient_name = (
        patient["full_name"]
        if patient
        else "مريض غير معروف"
    )

    content = f"""

    <div class="card">

        <div class="patient-header">

            <div>

                <div class="patient-name">

                    تفاصيل الزيارة

                </div>

                <div style="
                    margin-top:8px;
                    color:#64748b;
                ">

                    المريض:
                    <strong>
                        {safe(patient_name)}
                    </strong>

                </div>

            </div>

            <div class="actions">

                <a
                    href="/visits/patient/{visit["patient_id"]}"
                    class="btn btn-secondary">

                    🩺 كل الزيارات

                </a>

                <a
                    href="/visits/new/{visit["patient_id"]}"
                    class="btn btn-primary">

                    ➕ زيارة جديدة

                </a>

            </div>

        </div>

    </div>


    <div class="card">

        <div class="section-title">
            معلومات الزيارة
        </div>

        <div class="detail-grid">

            <div class="detail">

                <div class="detail-title">
                    تاريخ الزيارة
                </div>

                <div class="detail-value">
                    {safe(format_date(visit["visit_date"]))}
                </div>

            </div>


            <div class="detail">

                <div class="detail-title">
                    الطبيب
                </div>

                <div class="detail-value">
                    {safe(visit["doctor_name"]) or "-"}
                </div>

            </div>


            <div class="detail">

                <div class="detail-title">
                    الشكوى الرئيسية
                </div>

                <div class="detail-value">
                    {safe(visit["chief_complaint"]) or "-"}
                </div>

            </div>


            <div class="detail">

                <div class="detail-title">
                    التشخيص
                </div>

                <div class="detail-value">
                    {safe(visit["diagnosis"]) or "-"}
                </div>

            </div>


            <div class="detail">

                <div class="detail-title">
                    الفحص السريري
                </div>

                <div class="detail-value">
                    {safe(visit["examination"]) or "-"}
                </div>

            </div>


            <div class="detail">

                <div class="detail-title">
                    العلاج
                </div>

                <div class="detail-value">
                    {safe(visit["treatment"]) or "-"}
                </div>

            </div>


            <div class="detail">

                <div class="detail-title">
                    الوصفة الطبية
                </div>

                <div class="detail-value">
                    {safe(visit["prescription"]) or "-"}
                </div>

            </div>


            <div class="detail">

                <div class="detail-title">
                    طلبات التحاليل
                </div>

                <div class="detail-value">
                    {safe(visit["lab_requests"]) or "-"}
                </div>

            </div>


            <div class="detail">

                <div class="detail-title">
                    طلبات التصوير الشعاعي
                </div>

                <div class="detail-value">
                    {safe(visit["radiology_requests"]) or "-"}
                </div>

            </div>


            <div class="detail">

                <div class="detail-title">
                    ملاحظات الطبيب
                </div>

                <div class="detail-value">
                    {safe(visit["notes"]) or "-"}
                </div>

            </div>

        </div>

    </div>

    """

    return HTMLResponse(
        page("تفاصيل الزيارة", content)
    )
