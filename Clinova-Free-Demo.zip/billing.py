from datetime import datetime
from html import escape

from fastapi import APIRouter, Depends, Form, HTTPException, Request
import math
from uuid import uuid4
from sqlalchemy import update
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from sqlalchemy.orm import Session

from barcode import Code128
from barcode.writer import SVGWriter

from database import get_db
from models import Patient
from billing_models import Invoice, InvoiceItem, Payment
from billing_access import require_billing, invoice_query
from invoice_design import render_invoice


router = APIRouter(dependencies=[Depends(require_billing)])


# =========================================================
# أدوات مساعدة
# =========================================================

def safe(value):
    if value is None:
        return ""

    return escape(str(value))


def today():
    return datetime.now().strftime("%Y-%m-%d")


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def money(value):
    try:
        return f"{float(value or 0):.2f}"
    except Exception:
        return "0.00"


# =========================================================
# إنشاء رقم الفاتورة
# =========================================================

def generate_invoice_number(db: Session):

    last_invoice = (
        db.query(Invoice)
        .order_by(Invoice.id.desc())
        .first()
    )

    if not last_invoice:
        return "INV-000001"

    try:

        old_number = str(
            last_invoice.invoice_number or ""
        )

        if old_number.startswith("INV-"):

            number = int(
                old_number.replace("INV-", "")
            )

            return f"INV-{number + 1:06d}"

    except Exception:
        pass

    return f"INV-{int(last_invoice.id) + 1:06d}"


# =========================================================
# إنشاء باركود دائم
# =========================================================
#
# الباركود يعتمد على ID الفاتورة:
#
# ID = 1
# barcode = INV000001
#
# ID = 25
# barcode = INV000025
#
# ID = 150
# barcode = INV000150
#
# وهذا يجعله ثابتًا وفريدًا.
# =========================================================

def generate_barcode(invoice_id):

    return f"INV{int(invoice_id):06d}"


# =========================================================
# CSS
# =========================================================

def page_style():

    return """

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Tahoma, Arial, sans-serif;
    background: #f4f7fb;
    color: #1f2937;
}

a {
    text-decoration: none;
}

.layout {
    min-height: 100vh;
}

.sidebar {
    position: fixed;
    right: 0;
    top: 0;
    bottom: 0;
    width: 250px;
    background: #111827;
    color: white;
    padding: 22px 15px;
    overflow-y: auto;
}

.logo {
    text-align: center;
    font-size: 21px;
    font-weight: bold;
    padding-bottom: 22px;
    border-bottom: 1px solid #374151;
    margin-bottom: 20px;
}

.logo-icon {
    display: block;
    font-size: 38px;
    margin-bottom: 8px;
}

.menu-title {
    color: #9ca3af;
    font-size: 12px;
    margin: 18px 10px 7px;
}

.menu a {
    display: block;
    color: #d1d5db;
    padding: 12px 14px;
    border-radius: 9px;
    margin-bottom: 4px;
}

.menu a:hover {
    background: #1f2937;
    color: white;
}

.content {
    margin-right: 250px;
    padding: 30px;
}

.header {
    background: white;
    padding: 22px 25px;
    border-radius: 15px;
    margin-bottom: 22px;
    box-shadow: 0 3px 15px rgba(0,0,0,.05);
}

.header h1 {
    margin: 0 0 8px;
    font-size: 27px;
}

.header p {
    margin: 0;
    color: #6b7280;
}

.card {
    background: white;
    border-radius: 15px;
    padding: 24px;
    margin-bottom: 22px;
    box-shadow: 0 3px 15px rgba(0,0,0,.05);
}

.card h2 {
    margin-top: 0;
}

.grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 18px;
}

.grid-3 {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 18px;
}

.field {
    margin-bottom: 15px;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 7px;
}

input,
select,
textarea {
    width: 100%;
    border: 1px solid #d1d5db;
    border-radius: 9px;
    padding: 11px 13px;
    font-family: inherit;
    font-size: 14px;
    background: white;
}

textarea {
    min-height: 90px;
    resize: vertical;
}

input:focus,
select:focus,
textarea:focus {
    outline: none;
    border-color: #2563eb;
}

.btn {
    display: inline-block;
    border: none;
    border-radius: 9px;
    padding: 11px 18px;
    cursor: pointer;
    font-family: inherit;
    font-size: 14px;
    font-weight: bold;
    background: #2563eb;
    color: white;
}

.btn:hover {
    opacity: .9;
}

.btn-success {
    background: #16a34a;
}

.btn-danger {
    background: #dc2626;
}

.btn-secondary {
    background: #6b7280;
}

.btn-warning {
    background: #d97706;
}

.actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #f3f4f6;
    font-weight: bold;
}

th,
td {
    padding: 12px 10px;
    border-bottom: 1px solid #e5e7eb;
    text-align: right;
    vertical-align: middle;
}

tr:hover td {
    background: #fafafa;
}

.status {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.status-paid {
    background: #dcfce7;
    color: #166534;
}

.status-partial {
    background: #fef3c7;
    color: #92400e;
}

.status-unpaid {
    background: #fee2e2;
    color: #991b1b;
}

.total-box {
    background: #f8fafc;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 18px;
    margin-top: 20px;
}

.total-row {
    display: flex;
    justify-content: space-between;
    padding: 7px 0;
}

.total-final {
    font-size: 21px;
    font-weight: bold;
    border-top: 2px solid #d1d5db;
    margin-top: 8px;
    padding-top: 12px;
}

.empty {
    text-align: center;
    padding: 40px;
    color: #6b7280;
}

.patient-info {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 20px;
}

.item-row {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 2fr auto;
    gap: 8px;
    margin-bottom: 8px;
    align-items: center;
}

.item-row input {
    margin: 0;
}

.small-btn {
    padding: 9px 12px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-family: inherit;
}

.remove-btn {
    background: #fee2e2;
    color: #991b1b;
}

.add-btn {
    background: #dcfce7;
    color: #166534;
    margin-top: 8px;
}

.invoice-number {
    font-size: 22px;
    font-weight: bold;
    color: #2563eb;
}

.stat-number {
    font-size: 28px;
    font-weight: bold;
    margin-top: 10px;
}

.alert {
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 20px;
    background: #eff6ff;
    color: #1e40af;
    border: 1px solid #bfdbfe;
}


/* ===================================================== */
/* الباركود */
/* ===================================================== */

.barcode-box {
    text-align: center;
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 20px;
    margin-top: 20px;
}

.barcode-box img {
    display: block;
    max-width: 100%;
    height: auto;
    margin: 0 auto;
}

.barcode-value {
    margin-top: 10px;
    font-family: Arial, sans-serif;
    font-size: 14px;
    font-weight: bold;
    letter-spacing: 2px;
}


/* ===================================================== */
/* الطباعة */
/* ===================================================== */

.print-barcode {
    text-align: center;
    margin: 30px 0;
}

.print-barcode img {
    max-width: 420px;
    width: 100%;
    height: auto;
}


@media (max-width: 900px) {

    .sidebar {
        width: 210px;
    }

    .content {
        margin-right: 210px;
    }

    .grid,
    .grid-3,
    .item-row {
        grid-template-columns: 1fr;
    }
}


@media (max-width: 600px) {

    .sidebar {
        position: relative;
        width: 100%;
    }

    .content {
        margin-right: 0;
        padding: 15px;
    }
}


@media print {

    .sidebar,
    .actions,
    button {
        display: none !important;
    }

    .content {
        margin: 0;
        padding: 0;
    }

    body {
        background: white;
    }

    .card,
    .header {
        box-shadow: none;
    }

    .barcode-box {
        border: none;
    }

    .print-barcode {
        display: block !important;
    }

}

</style>

"""


# =========================================================
# القائمة الجانبية
# =========================================================

def sidebar():

    return """

<aside class="sidebar">

    <div class="logo">

        <span class="logo-icon">
            🏥
        </span>

        CLINOVA

    </div>


    <div class="menu">

        <div class="menu-title">
            الرئيسية
        </div>

        <a href="/">
            🏠 لوحة التحكم
        </a>


        <div class="menu-title">
            المرضى
        </div>

        <a href="/patients">
            👤 المرضى
        </a>


        <div class="menu-title">
            المواعيد
        </div>

        <a href="/appointments">
            📅 المواعيد
        </a>


        <div class="menu-title">
            العيادات
        </div>

        <a href="/gynecology">
            👩‍⚕️ العيادة النسائية
        </a>


        <div class="menu-title">
            المختبر
        </div>

        <a href="/laboratory">
            🧪 المختبر
        </a>


        <div class="menu-title">
            الفواتير
        </div>

        <a href="/pharmacy">الصيدلية والمخزون</a>
        <a href="/billing">
            💰 الفواتير
        </a>

        <a href="/billing/new">
            🧾 فاتورة جديدة
        </a>

    </div>

</aside>

"""


# =========================================================
# الصفحة العامة
# =========================================================

def html_page(title, content):

    return f"""

<!DOCTYPE html>

<html lang="ar" dir="rtl">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>{safe(title)}</title>

{page_style()}
<link rel="stylesheet" href="/static/billing-refresh.css">

</head>


<body>

<div class="layout">

    {sidebar()}

    <main class="content">

        {content}

    </main>

</div>

</body>

</html>

"""


# =========================================================
# باركود الفاتورة - صورة SVG حقيقية
# =========================================================

@router.get(
    "/billing/invoice/{invoice_id}/barcode"
)
def invoice_barcode(

    invoice_id: int,

    db: Session = Depends(get_db)

):

    invoice = (
        db.query(Invoice)
        .filter(
            Invoice.id == invoice_id
        )
        .first()
    )


    if not invoice:

        raise HTTPException(
            status_code=404,
            detail="الفاتورة غير موجودة"
        )


    # -----------------------------------------------------
    # إذا كانت الفاتورة قديمة ولا يوجد لها باركود
    # يتم توليده وحفظه تلقائيًا.
    # -----------------------------------------------------

    if not invoice.barcode:

        invoice.barcode = generate_barcode(
            invoice.id
        )

        db.commit()

        db.refresh(invoice)


    # -----------------------------------------------------
    # إنشاء Code 128
    # -----------------------------------------------------

    code = Code128(
        str(invoice.barcode),
        writer=SVGWriter()
    )


    svg = code.render(
        writer_options={

            "module_width": 0.35,

            "module_height": 18,

            "quiet_zone": 6,

            "font_size": 10,

            "text_distance": 4,

            "write_text": True

        }
    )


    if isinstance(svg, str):

        svg_data = svg.encode(
            "utf-8"
        )

    else:

        svg_data = svg


    return Response(

        content=svg_data,

        media_type="image/svg+xml"

    )


# =========================================================
# الصفحة الرئيسية للفواتير
# =========================================================

@router.get(
    "/billing",
    response_class=HTMLResponse
)
def billing_home(
    request: Request,
    patient_id: int | None = None,
    db: Session = Depends(get_db)
):

    scoped = invoice_query(db, request.state.billing_clinic_id)
    if patient_id:
        scoped = scoped.filter(Invoice.patient_id == patient_id)

    invoices = (
        scoped
        .order_by(Invoice.id.desc())
        .limit(100)
        .all()
    )

    total_invoices = (
        scoped.count()
    )

    total_amount = sum(
        float(invoice.total or 0)
        for invoice in invoices
    )

    total_paid = sum(
        float(invoice.paid or 0)
        for invoice in invoices
    )

    total_remaining = sum(
        float(invoice.remaining or 0)
        for invoice in invoices
    )

    rows = ""

    for invoice in invoices:

        patient_name = ""

        if invoice.patient:

            patient_name = (
                invoice.patient.full_name
            )

        status = (
            invoice.payment_status
            or "غير مدفوعة"
        )

        if status == "مدفوعة":

            status_class = "status-paid"

        elif status == "مدفوعة جزئياً":

            status_class = "status-partial"

        else:

            status_class = "status-unpaid"


        rows += f"""

<tr>

<td>

<a href="/billing/invoice/{invoice.id}">

<strong>
{safe(invoice.invoice_number)}
</strong>

</a>

</td>


<td>

{safe(patient_name)
 if patient_name
 else "بدون مريض"}

</td>


<td>

{safe(invoice.invoice_date)}

</td>


<td>

{money(invoice.total)}

</td>


<td>

{money(invoice.paid)}

</td>


<td>

{money(invoice.remaining)}

</td>


<td>

<span class="status {status_class}">

{safe(status)}

</span>

</td>


<td>

<a class="btn"
   href="/billing/invoice/{invoice.id}">

عرض

</a>

</td>

</tr>

"""


    if not rows:

        rows = """

<tr>

<td colspan="8"
    class="empty">

لا توجد فواتير حتى الآن

</td>

</tr>

"""


    content = f"""

<div class="header">

<h1>
💰 إدارة الفواتير
</h1>

<p>
إنشاء وإدارة الفواتير والمدفوعات
</p>

</div>


<div class="grid-3">


<div class="card">

<h2>📄</h2>

<strong>
عدد الفواتير
</strong>

<div class="stat-number">
{total_invoices}
</div>

</div>


<div class="card">

<h2>💵</h2>

<strong>
إجمالي الفواتير
</strong>

<div class="stat-number">
{money(total_amount)}
</div>

</div>


<div class="card">

<h2>💳</h2>

<strong>
إجمالي المدفوع
</strong>

<div class="stat-number">
{money(total_paid)}
</div>

</div>

</div>


<div class="card">

<div class="actions">

<a class="btn btn-success"
   href="/billing/new">

➕ إنشاء فاتورة جديدة

</a>


<a class="btn btn-secondary"
   href="/">

🏠 الرئيسية

</a>

</div>

</div>


<div class="card">

<h2>
📋 الفواتير
</h2>


<div style="overflow-x:auto;">

<table>

<thead>

<tr>

<th>
رقم الفاتورة
</th>

<th>
المريض
</th>

<th>
التاريخ
</th>

<th>
الإجمالي
</th>

<th>
المدفوع
</th>

<th>
المتبقي
</th>

<th>
الحالة
</th>

<th>
إجراء
</th>

</tr>

</thead>


<tbody>

{rows}

</tbody>

</table>

</div>

</div>

"""

    return html_page(
        "الفواتير",
        content
    )


# =========================================================
# فاتورة جديدة
# =========================================================

@router.get(
    "/billing/new",
    response_class=HTMLResponse
)
def new_invoice(
    request: Request,
    db: Session = Depends(get_db)
):

    patients = (
        db.query(Patient)
        .filter(Patient.clinic_id == request.state.billing_clinic_id)
        .order_by(
            Patient.full_name.asc()
        )
        .all()
    )


    options = """

<option value="">
-- اختر المريض --
</option>

"""


    for patient in patients:

        options += f"""

<option value="{patient.id}">

{safe(patient.full_name)}

-

{safe(patient.medical_number)}

</option>

"""


    invoice_number = (
        generate_invoice_number(db)
    )


    content = f"""

<div class="header">

<h1>
🧾 إنشاء فاتورة جديدة
</h1>

<p>

رقم الفاتورة:

<strong class="invoice-number">

{safe(invoice_number)}

</strong>

</p>

</div>


<form method="post"
      action="/billing/create">


<div class="card">

<h2>
👤 بيانات المريض
</h2>


<div class="grid">


<div class="field">

<label>
المريض
</label>

<select
    name="patient_id"
    required>

{options}

</select>

</div>


<div class="field">

<label>
تاريخ الفاتورة
</label>

<input
    type="date"
    name="invoice_date"
    value="{today()}"
    required>

</div>


</div>

</div>


<div class="card">

<h2>
🛒 الخدمات
</h2>


<div id="items">


<div class="item-row">


<input
    type="text"
    name="service_name"
    placeholder="اسم الخدمة"
    required>


<input
    type="number"
    name="quantity"
    value="1"
    min="0.01"
    step="0.01"
    required>


<input
    type="number"
    name="unit_price"
    value="0"
    min="0"
    step="0.01"
    required>


<input
    type="text"
    name="description"
    placeholder="الوصف">


<button
    type="button"
    class="small-btn remove-btn"
    onclick="removeItem(this)">

حذف

</button>


</div>


</div>


<button
    type="button"
    class="small-btn add-btn"
    onclick="addItem()">

➕ إضافة خدمة

</button>

</div>


<div class="card">

<h2>
💵 الحساب
</h2>


<div class="grid">


<div class="field">

<label>
الخصم
</label>

<input
    type="number"
    name="discount"
    value="0"
    min="0"
    step="0.01">

</div>


<div class="field">

<label>
المبلغ المدفوع
</label>

<input
    type="number"
    name="paid"
    value="0"
    min="0"
    step="0.01">

</div>


<div class="field">

<label>
طريقة الدفع
</label>

<select name="payment_method">

<option value="نقدي">
نقدي
</option>

<option value="بطاقة">
بطاقة
</option>

<option value="تحويل">
تحويل
</option>

<option value="شام كاش">
شام كاش
</option>

</select>

</div>


<div class="field">

<label>
ملاحظات
</label>

<textarea
    name="notes"
    placeholder="ملاحظات الفاتورة">
</textarea>

</div>


</div>


<div class="actions">

<button
    type="submit"
    class="btn btn-success">

💾 حفظ الفاتورة

</button>


<a
    href="/billing"
    class="btn btn-secondary">

إلغاء

</a>

</div>


</div>


</form>


<script>

function addItem() {{

    const container =
        document.getElementById("items");


    const row =
        document.createElement("div");


    row.className =
        "item-row";


    row.innerHTML = `

<input
    type="text"
    name="service_name"
    placeholder="اسم الخدمة"
    required>


<input
    type="number"
    name="quantity"
    value="1"
    min="0.01"
    step="0.01"
    required>


<input
    type="number"
    name="unit_price"
    value="0"
    min="0"
    step="0.01"
    required>


<input
    type="text"
    name="description"
    placeholder="الوصف">


<button
    type="button"
    class="small-btn remove-btn"
    onclick="removeItem(this)">

حذف

</button>

`;


    container.appendChild(row);

}}


function removeItem(button) {{

    const rows =
        document.querySelectorAll(
            ".item-row"
        );


    if (rows.length <= 1) {{

        alert(
            "يجب أن تبقى خدمة واحدة على الأقل"
        );

        return;
    }}


    button.parentElement.remove();

}}

</script>

"""


    return html_page(
        "فاتورة جديدة",
        content
    )


# =========================================================
# حفظ الفاتورة
# =========================================================

@router.post("/billing/create")
def create_invoice(

    patient_id: int = Form(...),

    invoice_date: str = Form(...),

    service_name: list[str] = Form(...),

    quantity: list[float] = Form(...),

    unit_price: list[float] = Form(...),

    description: list[str] = Form([]),

    discount: float = Form(0),

    paid: float = Form(0),

    payment_method: str = Form("نقدي"),

    notes: str = Form(""),

    db: Session = Depends(get_db)

):

    try:

        # =====================================================
        # المريض
        # =====================================================

        patient = (
            db.query(Patient)
            .filter(
                Patient.id == patient_id
            )
            .first()
        )


        if not patient:

            raise HTTPException(
                status_code=404,
                detail="المريض غير موجود"
            )


        # =====================================================
        # التحقق من الخدمات
        # =====================================================

        if not service_name:

            raise HTTPException(
                status_code=400,
                detail="أضف خدمة واحدة على الأقل"
            )


        if len(service_name) != len(quantity):

            raise HTTPException(
                status_code=400,
                detail="عدد الخدمات والكميات غير متطابق"
            )


        if len(service_name) != len(unit_price):

            raise HTTPException(
                status_code=400,
                detail="عدد الخدمات والأسعار غير متطابق"
            )


        # =====================================================
        # رقم الفاتورة
        # =====================================================

        invoice_number = (
            generate_invoice_number(db)
        )


        # =====================================================
        # حساب البنود
        # =====================================================

        subtotal = 0.0

        items_data = []


        for index in range(
            len(service_name)
        ):

            name = str(
                service_name[index] or ""
            ).strip()


            if not name:
                continue


            qty = float(
                quantity[index]
            )


            price = float(
                unit_price[index]
            )

            if not math.isfinite(qty) or not math.isfinite(price):
                raise HTTPException(400, "الكمية والسعر يجب أن يكونا رقمين صالحين")


            if qty <= 0:

                raise HTTPException(
                    status_code=400,
                    detail=
                    f"الكمية غير صحيحة للخدمة: {name}"
                )


            if price < 0:

                raise HTTPException(
                    status_code=400,
                    detail=
                    f"السعر غير صحيح للخدمة: {name}"
                )


            item_total = (
                round(qty * price, 2)
            )


            subtotal += item_total


            item_description = ""


            if index < len(description):

                item_description = str(
                    description[index] or ""
                ).strip()


            items_data.append({

                "service_name": name,

                "description":
                    item_description,

                "quantity": qty,

                "unit_price": price,

                "total": item_total

            })


        # =====================================================
        # لا يوجد خدمات
        # =====================================================

        if not items_data:

            raise HTTPException(
                status_code=400,
                detail="يجب إدخال اسم خدمة"
            )


        # =====================================================
        # الخصم
        # =====================================================

        discount = float(
            discount or 0
        )

        if not math.isfinite(discount):
            raise HTTPException(400, "الخصم غير صالح")


        if discount < 0:

            discount = 0


        if discount > subtotal:

            discount = subtotal


        # =====================================================
        # الإجمالي
        # =====================================================

        total = (
            round(subtotal - discount, 2)
        )


        if total < 0:

            total = 0


        # =====================================================
        # المدفوع
        # =====================================================

        paid = float(
            paid or 0
        )

        if not math.isfinite(paid):
            raise HTTPException(400, "مبلغ الدفع غير صالح")


        if paid < 0:

            paid = 0


        if paid > total:

            paid = total


        # =====================================================
        # المتبقي
        # =====================================================

        remaining = (
            round(total - paid, 2)
        )


        if remaining < 0:

            remaining = 0


        # =====================================================
        # حالة الدفع
        # =====================================================

        if total <= 0:

            payment_status = "مدفوعة"

        elif paid <= 0:

            payment_status = "غير مدفوعة"

        elif paid >= total:

            payment_status = "مدفوعة"

        else:

            payment_status = "مدفوعة جزئياً"


        # =====================================================
        # إنشاء الفاتورة بدون باركود مؤقتًا
        # =====================================================

        invoice = Invoice(

            invoice_number=
                "TMP-" + uuid4().hex,

            barcode=
                None,

            patient_id=
                patient_id,

            invoice_date=
                invoice_date,

            subtotal=
                subtotal,

            discount=
                discount,

            total=
                total,

            paid=
                paid,

            remaining=
                remaining,

            payment_status=
                payment_status,

            payment_method=
                payment_method,

            notes=
                notes,

            created_at=
                now()

        )


        db.add(invoice)


        # =====================================================
        # تنفيذ INSERT والحصول على ID
        # =====================================================

        db.flush()

        # The allocated database ID makes concurrent invoice creation unique.
        invoice.invoice_number = f"INV-{invoice.id:08d}"


        # =====================================================
        # إنشاء الباركود اعتمادًا على ID الحقيقي
        # =====================================================

        invoice.barcode = generate_barcode(
            invoice.id
        )


        print(
            "✓ Invoice created:",
            invoice.invoice_number,
            "ID:",
            invoice.id,
            "BARCODE:",
            invoice.barcode
        )


        # =====================================================
        # حفظ البنود
        # =====================================================

        for item_data in items_data:

            item = InvoiceItem(

                invoice_id=
                    invoice.id,

                service_name=
                    item_data[
                        "service_name"
                    ],

                description=
                    item_data[
                        "description"
                    ],

                quantity=
                    item_data[
                        "quantity"
                    ],

                unit_price=
                    item_data[
                        "unit_price"
                    ],

                total=
                    item_data[
                        "total"
                    ]

            )


            db.add(item)


        # =====================================================
        # الدفعة الأولى
        # =====================================================

        if paid > 0:

            payment = Payment(

                invoice_id=
                    invoice.id,

                payment_date=
                    invoice_date,

                amount=
                    paid,

                payment_method=
                    payment_method,

                reference_number="",

                notes=
                    "دفعة عند إنشاء الفاتورة",

                created_at=
                    now()

            )


            db.add(payment)


        # =====================================================
        # الحفظ النهائي
        # =====================================================

        db.commit()


        print(
            "✓ Invoice saved successfully:",
            invoice.invoice_number,
            "BARCODE:",
            invoice.barcode
        )


        # =====================================================
        # الانتقال للفواتير
        # =====================================================

        return RedirectResponse(

            url=
                f"/billing/invoice/{invoice.id}",

            status_code=303

        )


    except HTTPException:

        db.rollback()

        raise


    except Exception as e:

        db.rollback()


        print("")
        print("=" * 70)
        print("❌ BILLING SAVE ERROR")
        print("=" * 70)
        print(str(e))
        print("=" * 70)
        print("")


        raise HTTPException(

            status_code=500,

            detail=
                "حدث خطأ أثناء حفظ الفاتورة"

        )


# =========================================================
# عرض الفاتورة
# =========================================================

@router.get(
    "/billing/invoice/{invoice_id}",
    response_class=HTMLResponse
)
def view_invoice(invoice_id: int, request: Request, db: Session = Depends(get_db)):
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not invoice:
        raise HTTPException(404, "الفاتورة غير موجودة")
    if not invoice.barcode:
        invoice.barcode = generate_barcode(invoice.id)
        db.commit()
        db.refresh(invoice)
    return render_invoice(request, db, invoice, print_mode=False)


# =========================================================
# جدول الدفعات
# =========================================================

def payment_table(invoice):

    if not invoice.payments:

        return """

<div class="empty">

لا توجد دفعات

</div>

"""


    rows = ""


    for payment in invoice.payments:

        rows += f"""

<tr>

<td>
{safe(payment.payment_date)}
</td>

<td>
{money(payment.amount)}
</td>

<td>
{safe(payment.payment_method)}
</td>

<td>
{safe(payment.reference_number)}
</td>

<td>
{safe(payment.notes)}
</td>

</tr>

"""


    return f"""

<div style="overflow-x:auto;">

<table>

<thead>

<tr>

<th>
التاريخ
</th>

<th>
المبلغ
</th>

<th>
طريقة الدفع
</th>

<th>
المرجع
</th>

<th>
ملاحظات
</th>

</tr>

</thead>


<tbody>

{rows}

</tbody>

</table>

</div>

"""


# =========================================================
# زر الدفعة
# =========================================================

def payment_button(invoice):

    if float(
        invoice.remaining or 0
    ) <= 0:

        return ""


    return f"""

<a href="/billing/invoice/{invoice.id}/payment"
   class="btn btn-success">

💳 تسجيل دفعة

</a>

"""


# =========================================================
# نموذج دفعة
# =========================================================

@router.get(
    "/billing/invoice/{invoice_id}/payment",
    response_class=HTMLResponse
)
def payment_form(

    invoice_id: int,

    db: Session = Depends(get_db)

):

    invoice = (
        db.query(Invoice)
        .filter(
            Invoice.id == invoice_id
        )
        .first()
    )


    if not invoice:

        raise HTTPException(
            status_code=404,
            detail="الفاتورة غير موجودة"
        )


    patient_name = ""

    if invoice.patient:

        patient_name = (
            invoice.patient.full_name
        )


    content = f"""

<div class="header">

<h1>
💳 تسجيل دفعة
</h1>

<p>

الفاتورة:

<strong>
{safe(invoice.invoice_number)}
</strong>

</p>

</div>


<div class="card">


<div class="patient-info">

<strong>
المريض:
</strong>

{safe(patient_name)}

<br><br>

<strong>
الإجمالي:
</strong>

{money(invoice.total)}

<br><br>

<strong>
المدفوع:
</strong>

{money(invoice.paid)}

<br><br>

<strong>
المتبقي:
</strong>

{money(invoice.remaining)}

</div>


<form
method="post"
action="/billing/invoice/{invoice.id}/payment">


<div class="grid">


<div class="field">

<label>
مبلغ الدفعة
</label>

<input
type="number"
name="amount"
min="0.01"
max="{money(invoice.remaining)}"
step="0.01"
required>

</div>


<div class="field">

<label>
طريقة الدفع
</label>

<select name="payment_method">

<option value="نقدي">
نقدي
</option>

<option value="بطاقة">
بطاقة
</option>

<option value="تحويل">
تحويل
</option>

<option value="شام كاش">
شام كاش
</option>

</select>

</div>


<div class="field">

<label>
رقم المرجع
</label>

<input
type="text"
name="reference_number">

</div>


<div class="field">

<label>
ملاحظات
</label>

<textarea
name="notes">
</textarea>

</div>


</div>


<div class="actions">

<button
type="submit"
class="btn btn-success">

💾 حفظ الدفعة

</button>


<a
href="/billing/invoice/{invoice.id}"
class="btn btn-secondary">

إلغاء

</a>

</div>


</form>

</div>

"""


    return html_page(
        "تسجيل دفعة",
        content
    )


# =========================================================
# حفظ الدفعة
# =========================================================

@router.post(
    "/billing/invoice/{invoice_id}/payment"
)
def add_payment(invoice_id: int, amount: float = Form(...), payment_method: str = Form("نقدي"),
                reference_number: str = Form(""), notes: str = Form(""), db: Session = Depends(get_db)):
    try:
        invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
        if not invoice:
            raise HTTPException(404, "الفاتورة غير موجودة")
        if not math.isfinite(amount):
            raise HTTPException(400, "مبلغ الدفعة غير صالح")
        amount = round(amount, 2)
        if amount <= 0:
            raise HTTPException(400, "مبلغ الدفعة يجب أن يكون أكبر من صفر")
        old_paid = float(invoice.paid or 0)
        old_remaining = float(invoice.remaining or 0)
        if old_remaining <= 0:
            raise HTTPException(400, "الفاتورة مدفوعة بالكامل")
        amount = min(amount, old_remaining)
        new_paid = round(old_paid + amount, 2)
        new_remaining = round(max(0, float(invoice.total or 0) - new_paid), 2)
        # Compare-and-update prevents simultaneous payments from overwriting
        # each other's balance. A rejected attempt saves neither payment nor totals.
        changed = db.execute(update(Invoice).where(
            Invoice.id == invoice_id, Invoice.paid == old_paid, Invoice.remaining == old_remaining
        ).values(paid=new_paid, remaining=new_remaining,
                 payment_status="مدفوعة" if new_remaining == 0 else "مدفوعة جزئياً"),
                 execution_options={"synchronize_session": False})
        if changed.rowcount != 1:
            raise HTTPException(409, "تغير رصيد الفاتورة أثناء تسجيل الدفعة؛ حدّث الصفحة وحاول مجددًا")
        db.add(Payment(invoice_id=invoice_id, payment_date=today(), amount=amount,
                       payment_method=payment_method, reference_number=reference_number,
                       notes=notes, created_at=now()))
        db.commit()
        return RedirectResponse(f"/billing/invoice/{invoice_id}", status_code=303)
    except Exception:
        db.rollback()
        raise


# =========================================================
# الطباعة
# =========================================================

@router.get(
    "/billing/invoice/{invoice_id}/print",
    response_class=HTMLResponse
)
def print_invoice(invoice_id: int, request: Request, db: Session = Depends(get_db)):
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not invoice:
        raise HTTPException(404, "الفاتورة غير موجودة")
    if not invoice.barcode:
        invoice.barcode = generate_barcode(invoice.id)
        db.commit()
        db.refresh(invoice)
    return render_invoice(request, db, invoice, print_mode=True)
