from clinic_security import protect_referenced_record
from input_validation import calendar_date, appointment_clock, required_name
from datetime import datetime, date
from html import escape

from fastapi import APIRouter, Depends, Form, HTTPException, Query
from fastapi.responses import HTMLResponse, RedirectResponse
from clinic_security import tenant_text as text, section_guard, booking_text
from sqlalchemy.orm import Session

from database import get_db


router = APIRouter(dependencies=[section_guard("appointments")])


# =========================================================
# أدوات مساعدة
# =========================================================

def safe(value):
    if value is None:
        return ""

    return escape(str(value))


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def today():
    return date.today().strftime("%Y-%m-%d")


# =========================================================
# التصميم العام
# =========================================================

def page_template(title, content):

    return f"""
<!DOCTYPE html>

<html lang="ar" dir="rtl">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>{safe(title)} | CLINOVA</title>

<style>

* {{
    box-sizing: border-box;
}}

body {{
    margin: 0;
    font-family: Tahoma, Arial, sans-serif;
    background: #f4f7fb;
    color: #1e293b;
}}

.container {{
    max-width: 1450px;
    margin: auto;
    padding: 30px;
}}

.header {{
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 16px;
    padding: 22px 25px;
    margin-bottom: 20px;

    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 15px;
    flex-wrap: wrap;
}}

.header-title {{
    display: flex;
    align-items: center;
    gap: 14px;
}}

.header-icon {{
    width: 50px;
    height: 50px;
    border-radius: 13px;

    background: #eff6ff;
    color: #2563eb;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 25px;
}}

.header h1 {{
    margin: 0;
    font-size: 23px;
}}

.header p {{
    margin: 5px 0 0;
    color: #64748b;
    font-size: 13px;
}}

.card {{
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 20px;
}}

.btn {{
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 7px;

    border: none;
    border-radius: 9px;

    padding: 11px 17px;

    cursor: pointer;
    text-decoration: none;

    font-family: inherit;
    font-size: 13px;
    font-weight: bold;
}}

.btn-primary {{
    background: #2563eb;
    color: white;
}}

.btn-primary:hover {{
    background: #1d4ed8;
}}

.btn-secondary {{
    background: #f1f5f9;
    color: #334155;
    border: 1px solid #e2e8f0;
}}

.btn-warning {{
    background: #f59e0b;
    color: white;
}}

.btn-danger {{
    background: #dc2626;
    color: white;
}}

.btn-success {{
    background: #16a34a;
    color: white;
}}

.filters {{
    display: grid;
    grid-template-columns: 2fr 1fr 1fr auto auto;
    gap: 10px;
    margin-bottom: 20px;
}}

input,
select,
textarea {{
    width: 100%;

    border: 1px solid #cbd5e1;
    border-radius: 9px;

    padding: 12px;

    font-family: inherit;
    font-size: 14px;

    background: white;
    outline: none;
}}

input:focus,
select:focus,
textarea:focus {{
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37,99,235,.10);
}}

.form-grid {{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}}

.form-group.full {{
    grid-column: 1 / -1;
}}

label {{
    display: block;
    margin-bottom: 7px;
    font-size: 13px;
    font-weight: bold;
    color: #334155;
}}

textarea {{
    min-height: 110px;
    resize: vertical;
}}

.actions {{
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 25px;
}}

.table-wrapper {{
    overflow-x: auto;
}}

table {{
    width: 100%;
    border-collapse: collapse;
    min-width: 1050px;
}}

th {{
    background: #f8fafc;
    color: #64748b;

    padding: 14px;
    text-align: right;

    font-size: 12px;
}}

td {{
    padding: 14px;
    border-top: 1px solid #f1f5f9;

    font-size: 13px;
}}

tr:hover td {{
    background: #f8fafc;
}}

.today-row td {{
    background: #eff6ff;
}}

.patient {{
    font-weight: bold;
}}

.patient small {{
    display: block;
    margin-top: 4px;
    color: #94a3b8;
    font-size: 10px;
}}

.doctor {{
    color: #475569;
}}

.time {{
    font-weight: bold;
    color: #2563eb;
}}

.badge {{
    display: inline-flex;
    padding: 6px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
}}

.status-scheduled {{
    background: #dbeafe;
    color: #1d4ed8;
}}

.status-waiting {{
    background: #fef3c7;
    color: #92400e;
}}

.status-completed {{
    background: #dcfce7;
    color: #166534;
}}

.status-cancelled {{
    background: #fee2e2;
    color: #991b1b;
}}

.status-default {{
    background: #f1f5f9;
    color: #475569;
}}

.action-buttons {{
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
}}

.action {{
    display: inline-flex;
    align-items: center;
    justify-content: center;

    padding: 7px 10px;

    border-radius: 7px;

    text-decoration: none;
    font-size: 11px;
    font-weight: bold;
}}

.action-edit {{
    background: #fef3c7;
    color: #92400e;
}}

.action-delete {{
    background: #fee2e2;
    color: #991b1b;
}}

.empty {{
    text-align: center;
    padding: 60px 20px;
    color: #64748b;
}}

.empty-icon {{
    font-size: 50px;
    margin-bottom: 10px;
}}

.stats {{
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
    margin-bottom: 20px;
}}

.stat {{
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 14px;
    padding: 18px;
}}

.stat-title {{
    color: #64748b;
    font-size: 12px;
}}

.stat-value {{
    font-size: 25px;
    font-weight: bold;
    margin-top: 7px;
}}

.required {{
    color: #dc2626;
}}

@media(max-width:1000px) {{

    .filters {{
        grid-template-columns: 1fr 1fr;
    }}

    .stats {{
        grid-template-columns: repeat(2, 1fr);
    }}

}}

@media(max-width:700px) {{

    .container {{
        padding: 15px;
    }}

    .form-grid {{
        grid-template-columns: 1fr;
    }}

    .form-group.full {{
        grid-column: auto;
    }}

    .filters {{
        grid-template-columns: 1fr;
    }}

    .stats {{
        grid-template-columns: 1fr;
    }}

}}

</style>

</head>

<body>

<div class="container">

{content}

</div>

</body>

</html>
"""


# =========================================================
# جلب المرضى
# =========================================================

def get_patients(db: Session):

    result = db.execute(
        text('\n            SELECT\n                id,\n                full_name,\n                medical_number,\n                file_number,\n                phone\n            FROM (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS patients\n            ORDER BY full_name ASC\n        ')
    )

    return result.mappings().all()


# =========================================================
# جلب الأطباء
# =========================================================

def get_doctors(db: Session):

    result = db.execute(
        text('\n            SELECT\n                id,\n                full_name,\n                specialization\n            FROM (SELECT * FROM doctors WHERE clinic_id=:active_clinic_id) AS doctors\n            ORDER BY full_name ASC\n        ')
    )

    return result.mappings().all()


# =========================================================
# تحديد شكل حالة الموعد
# =========================================================

def status_badge(status):

    status = status or "مجدول"

    classes = {
        "مجدول": "status-scheduled",
        "بانتظار المريض": "status-waiting",
        "مكتمل": "status-completed",
        "ملغى": "status-cancelled",
    }

    css_class = classes.get(
        status,
        "status-default"
    )

    return f"""
    <span class="badge {css_class}">
        {safe(status)}
    </span>
    """


# =========================================================
# قائمة المواعيد
# =========================================================

@router.get(
    "/appointments",
    response_class=HTMLResponse
)
def appointments_list(
    search: str = Query("", max_length=100),
    appointment_date: str = Query(""),
    status: str = Query(""),
    db: Session = Depends(get_db)
):

    search = search.strip()
    appointment_date = appointment_date.strip()
    status = status.strip()

    conditions = []
    params = {}

    # -----------------------------------------------------
    # البحث
    # -----------------------------------------------------

    if search:

        conditions.append("""
            (
                p.full_name LIKE :search
                OR p.medical_number LIKE :search
                OR p.phone LIKE :search
                OR d.full_name LIKE :search
            )
        """)

        params["search"] = f"%{search}%"

    # -----------------------------------------------------
    # التاريخ
    # -----------------------------------------------------

    if appointment_date:

        conditions.append(
            "a.appointment_date = :appointment_date"
        )

        params["appointment_date"] = appointment_date

    # -----------------------------------------------------
    # الحالة
    # -----------------------------------------------------

    if status:

        conditions.append(
            "a.status = :status"
        )

        params["status"] = status

    where_sql = ""

    if conditions:

        where_sql = "WHERE " + " AND ".join(conditions)

    # -----------------------------------------------------
    # جلب المواعيد
    # -----------------------------------------------------

    result = db.execute(
        text(f'\n            SELECT\n                a.id,\n                a.patient_id,\n                a.doctor_id,\n                a.appointment_date,\n                a.appointment_time,\n                a.status,\n                a.reason,\n                a.notes,\n\n                p.full_name AS patient_name,\n                p.medical_number,\n                p.file_number,\n                p.phone AS patient_phone,\n\n                d.full_name AS doctor_name,\n                d.specialization\n\n            FROM (SELECT * FROM appointments WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS a\n\n            INNER JOIN (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS p\n                ON p.id = a.patient_id\n\n            LEFT JOIN (SELECT * FROM doctors WHERE clinic_id=:active_clinic_id) AS d\n                ON d.id = a.doctor_id\n\n            {where_sql}\n\n            ORDER BY\n                a.appointment_date DESC,\n                a.appointment_time ASC,\n                a.id DESC\n        '),
        params
    )

    appointments = result.mappings().all()

    # =====================================================
    # إحصائيات
    # =====================================================

    stats_result = db.execute(
        text("\n            SELECT\n                COUNT(*) AS total,\n\n                SUM(\n                    CASE\n                        WHEN appointment_date = :today\n                        THEN 1\n                        ELSE 0\n                    END\n                ) AS today_count,\n\n                SUM(\n                    CASE\n                        WHEN status = 'مكتمل'\n                        THEN 1\n                        ELSE 0\n                    END\n                ) AS completed_count,\n\n                SUM(\n                    CASE\n                        WHEN status = 'ملغى'\n                        THEN 1\n                        ELSE 0\n                    END\n                ) AS cancelled_count\n\n            FROM (SELECT * FROM appointments WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS appointments\n        "),
        {
            "today": today()
        }
    ).mappings().first()

    total_count = stats_result["total"] or 0
    today_count = stats_result["today_count"] or 0
    completed_count = stats_result["completed_count"] or 0
    cancelled_count = stats_result["cancelled_count"] or 0

    # =====================================================
    # بناء الصفوف
    # =====================================================

    rows = ""

    for appointment in appointments:

        is_today = (
            appointment["appointment_date"]
            == today()
        )

        row_class = "today-row" if is_today else ""

        doctor_text = (
            safe(appointment["doctor_name"])
            if appointment["doctor_name"]
            else "لم يتم تحديد الطبيب"
        )

        specialization = (
            appointment["specialization"]
            or ""
        )

        rows += f"""

        <tr class="{row_class}">

            <td>
                <strong>
                    #{appointment["id"]}
                </strong>
            </td>

            <td>

                <div class="patient">

                    {safe(appointment["patient_name"])}

                    <small>
                        {safe(appointment["medical_number"] or "-")}
                        |
                        ملف #{safe(appointment["file_number"] or "-")}
                    </small>

                </div>

            </td>

            <td>

                <div class="doctor">

                    👨‍⚕️ {doctor_text}

                    <small>
                        {safe(specialization)}
                    </small>

                </div>

            </td>

            <td>
                {safe(appointment["appointment_date"])}
            </td>

            <td>

                <span class="time">

                    🕐
                    {safe(
                        appointment["appointment_time"]
                        or "-"
                    )}

                </span>

            </td>

            <td>
                {status_badge(appointment["status"])}
            </td>

            <td>
                {safe(appointment["reason"] or "-")}
            </td>

            <td>

                <div class="action-buttons">

                    <a
                        href="/appointments/edit/{appointment['id']}"
                        class="action action-edit"
                    >
                        ✏️ تعديل
                    </a>

                    <form method="post" action="/appointments/delete/{appointment['id']}" style="display:inline" onsubmit="return confirm('هل تريد تأكيد هذا الإجراء؟')"><button type="submit" class="action action-delete">
                        🗑️ حذف
                    </button></form>

                </div>

            </td>

        </tr>
        """

    if not rows:

        rows = """

        <tr>

            <td
                colspan="8"
                class="empty"
            >

                <div class="empty-icon">
                    📅
                </div>

                <h3>
                    لا توجد مواعيد
                </h3>

                <p>
                    لم يتم العثور على مواعيد مطابقة للبحث.
                </p>

            </td>

        </tr>

        """

    # =====================================================
    # المحتوى
    # =====================================================

    content = f"""

    <div class="header">

        <div class="header-title">

            <div class="header-icon">
                📅
            </div>

            <div>

                <h1>
                    إدارة المواعيد
                </h1>

                <p>
                    تنظيم ومتابعة مواعيد المرضى والأطباء
                </p>

            </div>

        </div>


        <div>

            <a
                href="/"
                class="btn btn-secondary"
            >
                🏠 الرئيسية
            </a>

            <a
                href="/appointments/new"
                class="btn btn-primary"
            >
                ➕ إضافة موعد
            </a>

        </div>

    </div>


    <div class="stats">

        <div class="stat">

            <div class="stat-title">
                إجمالي المواعيد
            </div>

            <div class="stat-value">
                {total_count}
            </div>

        </div>


        <div class="stat">

            <div class="stat-title">
                مواعيد اليوم
            </div>

            <div class="stat-value">
                {today_count}
            </div>

        </div>


        <div class="stat">

            <div class="stat-title">
                المواعيد المكتملة
            </div>

            <div class="stat-value">
                {completed_count}
            </div>

        </div>


        <div class="stat">

            <div class="stat-title">
                المواعيد الملغاة
            </div>

            <div class="stat-value">
                {cancelled_count}
            </div>

        </div>

    </div>


    <div class="card">

        <form
            method="get"
            action="/appointments"
        >

            <div class="filters">

                <input
                    type="text"
                    name="search"
                    value="{safe(search)}"
                    placeholder="🔍 ابحث باسم المريض أو الطبيب أو الرقم الطبي..."
                >


                <input
                    type="date"
                    name="appointment_date"
                    value="{safe(appointment_date)}"
                >


                <select name="status">

                    <option value="">
                        كل الحالات
                    </option>

                    <option
                        value="مجدول"
                        {"selected" if status == "مجدول" else ""}
                    >
                        🟢 مجدول
                    </option>

                    <option
                        value="بانتظار المريض"
                        {"selected" if status == "بانتظار المريض" else ""}
                    >
                        🟡 بانتظار المريض
                    </option>

                    <option
                        value="مكتمل"
                        {"selected" if status == "مكتمل" else ""}
                    >
                        🔵 مكتمل
                    </option>

                    <option
                        value="ملغى"
                        {"selected" if status == "ملغى" else ""}
                    >
                        🔴 ملغى
                    </option>

                </select>


                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    🔍 بحث
                </button>


                <a
                    href="/appointments"
                    class="btn btn-secondary"
                >
                    إعادة
                </a>

            </div>

        </form>


        <div class="table-wrapper">

            <table>

                <thead>

                    <tr>

                        <th>الرقم</th>

                        <th>المريض</th>

                        <th>الطبيب</th>

                        <th>التاريخ</th>

                        <th>الوقت</th>

                        <th>الحالة</th>

                        <th>سبب الزيارة</th>

                        <th>الإجراءات</th>

                    </tr>

                </thead>


                <tbody>

                    {rows}

                </tbody>

            </table>

        </div>

    </div>

    """

    return page_template(
        "إدارة المواعيد",
        content
    )


# =========================================================
# صفحة إضافة موعد
# =========================================================

@router.get(
    "/appointments/new",
    response_class=HTMLResponse
)
def new_appointment(
    db: Session = Depends(get_db)
):

    patients = get_patients(db)
    doctors = get_doctors(db)

    patient_options = ""

    for patient in patients:

        patient_options += f"""

        <option value="{patient['id']}">

            {safe(patient['full_name'])}
            —
            {safe(patient['medical_number'] or "")}

        </option>

        """

    doctor_options = """

    <option value="">
        -- بدون تحديد --
    </option>

    """

    for doctor in doctors:

        specialization = (
            f" - {safe(doctor['specialization'])}"
            if doctor["specialization"]
            else ""
        )

        doctor_options += f"""

        <option value="{doctor['id']}">

            {safe(doctor['full_name'])}
            {specialization}

        </option>

        """

    content = f"""

    <div class="header">

        <div class="header-title">

            <div class="header-icon">
                ➕
            </div>

            <div>

                <h1>
                    إضافة موعد جديد
                </h1>

                <p>
                    تسجيل موعد جديد للمريض
                </p>

            </div>

        </div>

        <a
            href="/appointments"
            class="btn btn-secondary"
        >
            ← المواعيد
        </a>

    </div>


    <div class="card">

        <form
            method="post"
            action="/appointments/create"
        >

            <div class="form-grid">


                <div class="form-group">

                    <label>
                        المريض
                        <span class="required">*</span>
                    </label>

                    <select
                        name="patient_id"
                        required
                    >

                        <option value="">
                            -- اختر المريض --
                        </option>

                        {patient_options}

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        الطبيب
                    </label>

                    <select
                        name="doctor_id"
                    >

                        {doctor_options}

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        تاريخ الموعد
                        <span class="required">*</span>
                    </label>

                    <input
                        type="date"
                        name="appointment_date"
                        value="{today()}"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        وقت الموعد
                        <span class="required">*</span>
                    </label>

                    <input
                        type="time"
                        name="appointment_time"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        حالة الموعد
                    </label>

                    <select name="status">

                        <option value="مجدول">
                            🟢 مجدول
                        </option>

                        <option value="بانتظار المريض">
                            🟡 بانتظار المريض
                        </option>

                        <option value="مكتمل">
                            🔵 مكتمل
                        </option>

                        <option value="ملغى">
                            🔴 ملغى
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        نوع الزيارة
                    </label>

                    <select name="visit_type">

                        <option value="كشف">
                            كشف
                        </option>

                        <option value="متابعة">
                            متابعة
                        </option>

                        <option value="استشارة">
                            استشارة
                        </option>

                        <option value="إجراء">
                            إجراء طبي
                        </option>

                        <option value="طوارئ">
                            طوارئ
                        </option>

                    </select>

                </div>


                <div class="form-group full">

                    <label>
                        سبب الزيارة
                    </label>

                    <input
                        type="text"
                        name="reason"
                        placeholder="مثال: مراجعة نتائج التحاليل..."
                    >

                </div>


                <div class="form-group full">

                    <label>
                        ملاحظات
                    </label>

                    <textarea
                        name="notes"
                        placeholder="أي ملاحظات إضافية عن الموعد..."
                    ></textarea>

                </div>

            </div>


            <div class="actions">

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    💾 حفظ الموعد
                </button>

                <a
                    href="/appointments"
                    class="btn btn-secondary"
                >
                    ↩ إلغاء
                </a>

            </div>

        </form>

    </div>

    """

    return page_template(
        "إضافة موعد",
        content
    )


# =========================================================
# حفظ الموعد
# =========================================================

@router.post("/appointments/create")
def create_appointment(
    patient_id: int = Form(...),
    doctor_id: str = Form(""),
    appointment_date: str = Form(...),
    appointment_time: str = Form(...),
    status: str = Form("مجدول"),
    visit_type: str = Form("كشف"),
    reason: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db)
):

    db.execute(text("BEGIN IMMEDIATE"))

    appointment_date = calendar_date(appointment_date, "تاريخ الموعد", required=True)
    appointment_time = appointment_clock(appointment_time)
    if status not in {"مجدول", "مؤكد", "مكتمل", "ملغى", "لم يحضر", "قيد الانتظار", "بانتظار المريض"}: raise HTTPException(400, "حالة الموعد غير صالحة")

    appointment_date = appointment_date.strip()
    appointment_time = appointment_time.strip()
    status = status.strip() or "مجدول"
    visit_type = visit_type.strip() or "كشف"
    reason = reason.strip()
    notes = notes.strip()

    # -----------------------------------------------------
    # التأكد من وجود المريض
    # -----------------------------------------------------

    patient = db.execute(
        text('\n            SELECT id\n            FROM (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS patients\n            WHERE id = :id\n        '),
        {
            "id": patient_id
        }
    ).first()

    if not patient:

        raise HTTPException(
            status_code=404,
            detail="المريض غير موجود"
        )

    # -----------------------------------------------------
    # الطبيب اختياري
    # -----------------------------------------------------

    doctor_value = None

    if doctor_id.strip():

        try:
            doctor_value = int(doctor_id)
        except ValueError:

            raise HTTPException(
                status_code=400,
                detail="رقم الطبيب غير صحيح"
            )

        doctor = db.execute(
            text('\n                SELECT id\n                FROM (SELECT * FROM doctors WHERE clinic_id=:active_clinic_id) AS doctors\n                WHERE id = :id\n            '),
            {
                "id": doctor_value
            }
        ).first()

        if not doctor:

            raise HTTPException(
                status_code=404,
                detail="الطبيب غير موجود"
            )

    # -----------------------------------------------------
    # التحقق من التاريخ والوقت
    # -----------------------------------------------------

    if not appointment_date:

        raise HTTPException(
            status_code=400,
            detail="تاريخ الموعد مطلوب"
        )

    if not appointment_time:

        raise HTTPException(
            status_code=400,
            detail="وقت الموعد مطلوب"
        )

    # -----------------------------------------------------
    # منع الحجز المكرر للطبيب بنفس الوقت
    # -----------------------------------------------------

    if doctor_value is not None:

        conflict = db.execute(
            booking_text("\n                SELECT id\n                FROM (SELECT * FROM appointments WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS appointments\n                WHERE\n                    doctor_id = :doctor_id\n                    AND appointment_date = :appointment_date\n                    AND appointment_time = :appointment_time\n                    AND status != 'ملغى'\n            "),
            {
                "doctor_id": doctor_value,
                "appointment_date": appointment_date,
                "appointment_time": appointment_time
            }
        ).first()

        if conflict:

            raise HTTPException(
                status_code=400,
                detail="يوجد موعد آخر لهذا الطبيب في نفس التاريخ والوقت"
            )

    # -----------------------------------------------------
    # إضافة الموعد
    # -----------------------------------------------------

    db.execute(
        text('\n            INSERT INTO appointments\n            (clinic_id, \n                patient_id,\n                doctor_id,\n                appointment_date,\n                appointment_time,\n                status,\n                reason,\n                notes,\n                created_at\n            )\n\n            VALUES\n            (:active_clinic_id, \n                :patient_id,\n                :doctor_id,\n                :appointment_date,\n                :appointment_time,\n                :status,\n                :reason,\n                :notes,\n                :created_at\n            )\n        '),
        {
            "patient_id": patient_id,
            "doctor_id": doctor_value,
            "appointment_date": appointment_date,
            "appointment_time": appointment_time,
            "status": status,
            "reason": (
                f"{visit_type}: {reason}"
                if reason
                else visit_type
            ),
            "notes": notes,
            "created_at": now()
        }
    )

    db.commit()

    return RedirectResponse(
        url="/appointments",
        status_code=303
    )


# =========================================================
# تعديل الموعد
# =========================================================

@router.get(
    "/appointments/edit/{appointment_id}",
    response_class=HTMLResponse
)
def edit_appointment(
    appointment_id: int,
    db: Session = Depends(get_db)
):

    result = db.execute(
        text('\n            SELECT\n                id,\n                patient_id,\n                doctor_id,\n                appointment_date,\n                appointment_time,\n                status,\n                reason,\n                notes\n            FROM (SELECT * FROM appointments WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS appointments\n            WHERE id = :id\n        '),
        {
            "id": appointment_id
        }
    )

    appointment = result.mappings().first()

    if not appointment:

        raise HTTPException(
            status_code=404,
            detail="الموعد غير موجود"
        )

    patients = get_patients(db)
    doctors = get_doctors(db)

    # =====================================================
    # المرضى
    # =====================================================

    patient_options = ""

    for patient in patients:

        selected = (
            "selected"
            if patient["id"] == appointment["patient_id"]
            else ""
        )

        patient_options += f"""

        <option
            value="{patient['id']}"
            {selected}
        >

            {safe(patient['full_name'])}
            —
            {safe(patient['medical_number'] or "")}

        </option>

        """

    # =====================================================
    # الأطباء
    # =====================================================

    doctor_options = """

    <option value="">
        -- بدون تحديد --
    </option>

    """

    for doctor in doctors:

        selected = (
            "selected"
            if doctor["id"] == appointment["doctor_id"]
            else ""
        )

        specialization = (
            f" - {safe(doctor['specialization'])}"
            if doctor["specialization"]
            else ""
        )

        doctor_options += f"""

        <option
            value="{doctor['id']}"
            {selected}
        >

            {safe(doctor['full_name'])}
            {specialization}

        </option>

        """

    # =====================================================
    # المحتوى
    # =====================================================

    content = f"""

    <div class="header">

        <div class="header-title">

            <div class="header-icon">
                ✏️
            </div>

            <div>

                <h1>
                    تعديل الموعد
                </h1>

                <p>
                    تعديل الموعد رقم #{appointment_id}
                </p>

            </div>

        </div>


        <a
            href="/appointments"
            class="btn btn-secondary"
        >
            ← المواعيد
        </a>

    </div>


    <div class="card">

        <form
            method="post"
            action="/appointments/update/{appointment_id}"
        >

            <div class="form-grid">


                <div class="form-group">

                    <label>
                        المريض
                        <span class="required">*</span>
                    </label>

                    <select
                        name="patient_id"
                        required
                    >

                        {patient_options}

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        الطبيب
                    </label>

                    <select name="doctor_id">

                        {doctor_options}

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        تاريخ الموعد
                        <span class="required">*</span>
                    </label>

                    <input
                        type="date"
                        name="appointment_date"
                        value="{safe(appointment['appointment_date'])}"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        وقت الموعد
                        <span class="required">*</span>
                    </label>

                    <input
                        type="time"
                        name="appointment_time"
                        value="{safe(appointment['appointment_time'] or '')}"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        الحالة
                    </label>

                    <select name="status">

                        <option
                            value="مجدول"
                            {"selected" if appointment["status"] == "مجدول" else ""}
                        >
                            🟢 مجدول
                        </option>

                        <option
                            value="بانتظار المريض"
                            {"selected" if appointment["status"] == "بانتظار المريض" else ""}
                        >
                            🟡 بانتظار المريض
                        </option>

                        <option
                            value="مكتمل"
                            {"selected" if appointment["status"] == "مكتمل" else ""}
                        >
                            🔵 مكتمل
                        </option>

                        <option
                            value="ملغى"
                            {"selected" if appointment["status"] == "ملغى" else ""}
                        >
                            🔴 ملغى
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        سبب الزيارة
                    </label>

                    <input
                        type="text"
                        name="reason"
                        value="{safe(appointment['reason'] or '')}"
                    >

                </div>


                <div class="form-group full">

                    <label>
                        الملاحظات
                    </label>

                    <textarea
                        name="notes"
                    >{safe(appointment['notes'] or '')}</textarea>

                </div>

            </div>


            <div class="actions">

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    💾 حفظ التعديلات
                </button>

                <a
                    href="/appointments"
                    class="btn btn-secondary"
                >
                    ↩ إلغاء
                </a>

            </div>

        </form>

    </div>

    """

    return page_template(
        "تعديل الموعد",
        content
    )


# =========================================================
# تحديث الموعد
# =========================================================

@router.post(
    "/appointments/update/{appointment_id}"
)
def update_appointment(
    appointment_id: int,
    patient_id: int = Form(...),
    doctor_id: str = Form(""),
    appointment_date: str = Form(...),
    appointment_time: str = Form(...),
    status: str = Form("مجدول"),
    reason: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db)
):

    # -----------------------------------------------------
    # التحقق من الموعد
    # -----------------------------------------------------

    db.execute(text("BEGIN IMMEDIATE"))

    appointment_date = calendar_date(appointment_date, "تاريخ الموعد", required=True)
    appointment_time = appointment_clock(appointment_time)
    if status not in {"مجدول", "مؤكد", "مكتمل", "ملغى", "لم يحضر", "قيد الانتظار", "بانتظار المريض"}: raise HTTPException(400, "حالة الموعد غير صالحة")

    appointment = db.execute(
        text('\n            SELECT id\n            FROM (SELECT * FROM appointments WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS appointments\n            WHERE id = :id\n        '),
        {
            "id": appointment_id
        }
    ).first()

    if not appointment:

        raise HTTPException(
            status_code=404,
            detail="الموعد غير موجود"
        )

    # -----------------------------------------------------
    # التحقق من المريض
    # -----------------------------------------------------

    patient = db.execute(
        text('\n            SELECT id\n            FROM (SELECT * FROM patients WHERE clinic_id=:active_clinic_id) AS patients\n            WHERE id = :id\n        '),
        {
            "id": patient_id
        }
    ).first()

    if not patient:

        raise HTTPException(
            status_code=404,
            detail="المريض غير موجود"
        )

    # -----------------------------------------------------
    # الطبيب
    # -----------------------------------------------------

    doctor_value = None

    if doctor_id.strip():

        try:
            doctor_value = int(doctor_id)
        except ValueError:

            raise HTTPException(
                status_code=400,
                detail="رقم الطبيب غير صحيح"
            )

        doctor = db.execute(
            text('\n                SELECT id\n                FROM (SELECT * FROM doctors WHERE clinic_id=:active_clinic_id) AS doctors\n                WHERE id = :id\n            '),
            {
                "id": doctor_value
            }
        ).first()

        if not doctor:

            raise HTTPException(
                status_code=404,
                detail="الطبيب غير موجود"
            )

    # -----------------------------------------------------
    # منع التعارض
    # -----------------------------------------------------

    if doctor_value is not None:

        conflict = db.execute(
            booking_text("\n                SELECT id\n                FROM (SELECT * FROM appointments WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS appointments\n                WHERE\n                    doctor_id = :doctor_id\n                    AND appointment_date = :appointment_date\n                    AND appointment_time = :appointment_time\n                    AND status != 'ملغى'\n                    AND id != :appointment_id\n            "),
            {
                "doctor_id": doctor_value,
                "appointment_date": appointment_date,
                "appointment_time": appointment_time,
                "appointment_id": appointment_id
            }
        ).first()

        if conflict:

            raise HTTPException(
                status_code=400,
                detail="يوجد موعد آخر لهذا الطبيب في نفس الوقت"
            )

    # -----------------------------------------------------
    # تحديث
    # -----------------------------------------------------

    db.execute(
        text('\n            UPDATE appointments\n\n            SET\n                patient_id = :patient_id,\n                doctor_id = :doctor_id,\n                appointment_date = :appointment_date,\n                appointment_time = :appointment_time,\n                status = :status,\n                reason = :reason,\n                notes = :notes\n\n            WHERE id = :id AND (patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id))\n'),
        {
            "id": appointment_id,
            "patient_id": patient_id,
            "doctor_id": doctor_value,
            "appointment_date": appointment_date.strip(),
            "appointment_time": appointment_time.strip(),
            "status": status.strip() or "مجدول",
            "reason": reason.strip(),
            "notes": notes.strip()
        }
    )

    db.commit()

    return RedirectResponse(
        url="/appointments",
        status_code=303
    )


# =========================================================
# حذف الموعد
# =========================================================

@router.post(
    "/appointments/delete/{appointment_id}"
)
def delete_appointment(
    appointment_id: int,
    db: Session = Depends(get_db)
):

    protect_referenced_record(db, [("radiology_requests", "appointment_id")], appointment_id)

    appointment = db.execute(
        text('\n            SELECT id\n            FROM (SELECT * FROM appointments WHERE patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id)) AS appointments\n            WHERE id = :id\n        '),
        {
            "id": appointment_id
        }
    ).first()

    if not appointment:

        raise HTTPException(
            status_code=404,
            detail="الموعد غير موجود"
        )

    db.execute(
        text('\n            DELETE FROM appointments\n            WHERE id = :id AND (patient_id IN (SELECT id FROM patients WHERE clinic_id=:active_clinic_id))\n'),
        {
            "id": appointment_id
        }
    )

    db.commit()

    return RedirectResponse(
        url="/appointments",
        status_code=303
    )
