"""Additive, repeatable compatibility migration; never rebuilds clinical tables."""
from sqlalchemy import inspect, text


def migrate_pharmacy(engine):
    inspector = inspect(engine)
    with engine.begin() as connection:
        for table, columns in {
            "prescriptions": {"visit_id": "INTEGER"},
            "prescription_items": {"medication_name": "VARCHAR(300)", "medication_id": "INTEGER"},
        }.items():
            if not inspector.has_table(table):
                continue
            existing = {column["name"] for column in inspector.get_columns(table)}
            for column, declaration in columns.items():
                if column not in existing:
                    connection.execute(text(f'ALTER TABLE "{table}" ADD COLUMN "{column}" {declaration}'))
        if inspector.has_table("medications") and inspector.has_table("prescription_items"):
            connection.execute(text("""
                UPDATE prescription_items SET medication_name = (
                    SELECT name FROM medications WHERE medications.id=prescription_items.medication_id
                ) WHERE medication_name IS NULL
            """))
