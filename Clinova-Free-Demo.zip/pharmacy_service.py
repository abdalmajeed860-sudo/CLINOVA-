"""Transactional stock operations. All callers must supply the authenticated clinic."""
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

from fastapi import HTTPException
from sqlalchemy import update
from sqlalchemy.exc import IntegrityError

from billing_models import Invoice, InvoiceItem
from models import Patient, Prescription, PrescriptionItem, Visit
from pharmacy_models import LegacyMedication, Medicine, MedicineBatch, PharmacyOrder, PharmacyOrderItem, StockMovement


def cash(value):
    try:
        result = Decimal(str(value))
        if not result.is_finite() or result < 0 or result > Decimal("9999999999.99"):
            raise ValueError()
        return result.quantize(Decimal("0.01"))
    except (InvalidOperation, ValueError):
        raise HTTPException(400, "السعر يجب أن يكون رقمًا موجبًا صالحًا")


def positive_quantity(value):
    try:
        result = Decimal(str(value))
        if not result.is_finite() or result != result.to_integral_value() or not 0 < result <= 100000000:
            raise ValueError()
        return int(result)
    except (InvalidOperation, ValueError):
        raise HTTPException(400, "أدخل كمية صحيحة أكبر من صفر بوحدة الصرف المحددة")


def patient_for_clinic(db, patient_id, clinic_id):
    patient = db.query(Patient).filter_by(id=patient_id, clinic_id=clinic_id).first()
    if patient is None:
        raise HTTPException(404, "المريض غير موجود في المنشأة الحالية")
    return patient


def receive_stock(db, clinic_id, user_id, medicine_id, batch_number, expiry_date,
                  quantity, purchase_price=0, supplier=""):
    """A receipt always creates a batch, so repeated batch keys are rejected."""
    quantity = positive_quantity(quantity)
    price = cash(purchase_price)
    medicine = db.query(Medicine).filter_by(id=medicine_id, clinic_id=clinic_id, active=True).first()
    if not medicine:
        raise HTTPException(404, "الدواء غير موجود")
    if not batch_number.strip() or len(batch_number.strip()) > 100:
        raise HTTPException(400, "أدخل رقم تشغيلة لا يتجاوز100 حرف")
    if expiry_date < date.today():
        raise HTTPException(400, "لا يمكن توريد دواء منتهي الصلاحية")
    try:
        batch = MedicineBatch(clinic_id=clinic_id, medicine_id=medicine_id,
                              batch_number=batch_number.strip(), expiry_date=expiry_date,
                              quantity=quantity, purchase_price=price, supplier=supplier[:250])
        db.add(batch)
        db.flush()
        db.add(StockMovement(clinic_id=clinic_id, medicine_id=medicine_id, batch_id=batch.id,
                             quantity=quantity, movement_type="receipt", user_id=user_id,
                             reason="توريد" + (f" — {supplier}" if supplier else "")))
        db.commit()
        return batch
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "هذه التشغيلة مسجلة مسبقًا بنفس تاريخ الصلاحية")
    except Exception:
        db.rollback()
        raise


def create_order(db, clinic_id, user_id, patient_id, visit_id, lines, diagnosis="", notes=""):
    patient_for_clinic(db, patient_id, clinic_id)
    visit = None
    if visit_id:
        # Ownership follows the patient even for legacy visits without clinic_id.
        visit = db.query(Visit).filter_by(id=visit_id, patient_id=patient_id).first()
        if not visit or visit.clinic_id not in (None, clinic_id):
            raise HTTPException(404, "الزيارة لا تتبع هذا المريض والمنشأة")
    if not lines or len(lines) > 30:
        raise HTTPException(400, "أضف من1 إلى30 صنفًا للوصفة")
    selected = set()
    prepared = []
    for line in lines:
        medicine_id = int(line["medicine_id"])
        if medicine_id in selected:
            raise HTTPException(400, "الدواء مكرر؛ اجمع الكمية في بند واحد")
        selected.add(medicine_id)
        medicine = db.query(Medicine).filter_by(id=medicine_id, clinic_id=clinic_id, active=True).first()
        if not medicine:
            raise HTTPException(404, "أحد الأدوية غير موجود في المنشأة الحالية")
        prepared.append((medicine, positive_quantity(line["quantity"]), line))
    try:
        prescription = Prescription(clinic_id=clinic_id, patient_id=patient_id,
                                    visit_id=visit_id, diagnosis=diagnosis or (visit.diagnosis if visit else ""),
                                    notes=notes)
        db.add(prescription)
        db.flush()
        order = PharmacyOrder(clinic_id=clinic_id, patient_id=patient_id, visit_id=visit_id,
                              prescription_id=prescription.id, created_by=user_id)
        db.add(order)
        db.flush()
        for medicine, quantity, line in prepared:
            if medicine.legacy_medication_id is None:
                legacy = LegacyMedication(name=medicine.name, quantity=0, selling_price=medicine.sale_price,
                                          notes="مرجع متوافق للوصفات؛ الرصيد المعتمد في الصيدلية")
                db.add(legacy)
                db.flush()
                medicine.legacy_medication_id = legacy.id
            details = {key: str(line.get(key, "")).strip()[:200] for key in ("dosage", "frequency", "duration")}
            instructions = str(line.get("instructions", "")).strip()[:2000]
            name = " ".join(part for part in (medicine.name, medicine.strength) if part)
            db.add(PrescriptionItem(clinic_id=clinic_id, prescription_id=prescription.id,
                                    medication_id=medicine.legacy_medication_id,
                                    medication_name=name, instructions=instructions, **details))
            db.add(PharmacyOrderItem(order_id=order.id, medicine_id=medicine.id,
                                    medicine_name=name, quantity=quantity, unit=medicine.unit,
                                    unit_price=medicine.sale_price, instructions=instructions, **details))
        db.commit()
        return order
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "للزيارة وصفة صيدلية مسجلة مسبقًا؛ افتحها من قائمة الوصفات")
    except Exception:
        db.rollback()
        raise


def dispense_order(db, order_id, clinic_id, user_id):
    """Claim the order before reading stock. One transaction covers stock and billing.

    A conditional stock decrement protects against parallel workers; repeating the
    operation returns the existing invoice instead of dispensing twice.
    """
    try:
        claimed = db.execute(update(PharmacyOrder).where(
            PharmacyOrder.id == order_id, PharmacyOrder.clinic_id == clinic_id,
            PharmacyOrder.status == "pending").values(status="processing"))
        db.expire_all()
        order = db.query(PharmacyOrder).filter_by(id=order_id, clinic_id=clinic_id).first()
        if not order:
            raise HTTPException(404, "الوصفة غير موجودة")
        if claimed.rowcount != 1:
            if order.status == "dispensed":
                db.rollback()
                return order
            raise HTTPException(409, "هذه الوصفة ملغاة أو قيد المعالجة")
        patient_for_clinic(db, order.patient_id, clinic_id)
        if not order.items:
            raise HTTPException(400, "الوصفة لا تحتوي أدوية")
        subtotal = Decimal("0.00")
        for item in order.items:
            medicine = db.query(Medicine).filter_by(id=item.medicine_id, clinic_id=clinic_id, active=True).first()
            if not medicine:
                raise HTTPException(409, "أحد أصناف الوصفة غير متاح للصرف")
            batches = db.query(MedicineBatch).filter(
                MedicineBatch.clinic_id == clinic_id, MedicineBatch.medicine_id == medicine.id,
                MedicineBatch.expiry_date >= date.today(), MedicineBatch.quantity > 0
            ).order_by(MedicineBatch.expiry_date, MedicineBatch.id).all()
            remaining = item.quantity
            for batch in batches:
                take = min(remaining, batch.quantity)
                if take:
                    changed = db.execute(update(MedicineBatch).where(
                        MedicineBatch.id == batch.id, MedicineBatch.clinic_id == clinic_id,
                        MedicineBatch.quantity >= take).values(quantity=MedicineBatch.quantity - take))
                    if changed.rowcount != 1:
                        raise HTTPException(409, "تغير المخزون أثناء الصرف؛ أعد المحاولة")
                    db.add(StockMovement(clinic_id=clinic_id, medicine_id=medicine.id,
                                         batch_id=batch.id, order_id=order.id, quantity=-take,
                                         movement_type="dispense", user_id=user_id, reason="صرف وصفة"))
                    remaining -= take
                if remaining == 0:
                    break
            if remaining:
                raise HTTPException(409, f"المخزون الصالح غير كافٍ للدواء: {item.medicine_name}. لم يتم صرف أي بند.")
            subtotal += item.quantity * item.unit_price
        invoice = Invoice(invoice_number=f"PH-{order.id:08d}", patient_id=order.patient_id,
                          invoice_date=date.today().isoformat(), subtotal=float(subtotal), discount=0,
                          total=float(subtotal), paid=0, remaining=float(subtotal),
                          payment_status="مدفوعة" if subtotal == 0 else "غير مدفوعة",
                          payment_method="نقدي", notes=f"صرف صيدلية — الوصفة RX-{order.id:06d}",
                          created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        db.add(invoice)
        db.flush()
        invoice.barcode = f"INV{invoice.id:06d}"
        for item in order.items:
            db.add(InvoiceItem(invoice_id=invoice.id, service_name=item.medicine_name,
                               description=f"صيدلية · {item.unit} · RX-{order.id:06d}",
                               quantity=item.quantity, unit_price=float(item.unit_price),
                               total=float(item.quantity * item.unit_price),
                               created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        order.status = "dispensed"
        order.invoice_id = invoice.id
        order.dispensed_by = user_id
        order.dispensed_at = datetime.now()
        db.commit()
        return order
    except Exception:
        db.rollback()
        raise


def remove_stock(db, clinic_id, user_id, batch_id, quantity, reason):
    quantity = positive_quantity(quantity)
    if not reason.strip():
        raise HTTPException(400, "اذكر سبب الإتلاف أو التسوية")
    try:
        changed = db.execute(update(MedicineBatch).where(
            MedicineBatch.id == batch_id, MedicineBatch.clinic_id == clinic_id,
            MedicineBatch.quantity >= quantity).values(quantity=MedicineBatch.quantity - quantity))
        if changed.rowcount != 1:
            raise HTTPException(409, "التشغيلة غير موجودة أو الكمية أكبر من رصيدها")
        batch = db.get(MedicineBatch, batch_id)
        db.add(StockMovement(clinic_id=clinic_id, user_id=user_id, medicine_id=batch.medicine_id,
                             batch_id=batch_id, quantity=-quantity, movement_type="adjustment",
                             reason=reason.strip()[:2000]))
        db.commit()
    except Exception:
        db.rollback()
        raise
