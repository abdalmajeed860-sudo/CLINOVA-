# ============================================================
# CLINOVA
# نظام إدارة العيادات الذكي والمتكامل
# laboratory_models.py
# ============================================================

from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    Text,
    ForeignKey,
)
from sqlalchemy.orm import relationship

from database import Base


# ============================================================
# التحاليل المخبرية
# ============================================================

class LaboratoryTest(Base):
    __tablename__ = "laboratory_tests"
    clinic_id = Column(Integer, ForeignKey("clinics.id"), nullable=True, index=True)

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    name = Column(
        String(200),
        nullable=False,
        index=True
    )

    category = Column(
        String(100),
        default="عام",
        index=True
    )

    unit = Column(
        String(100),
        default=""
    )

    normal_range = Column(
        String(300),
        default=""
    )

    price = Column(
        Float,
        default=0
    )

    description = Column(
        Text,
        default=""
    )

    is_active = Column(
        Integer,
        default=1,
        index=True
    )

    created_at = Column(
        String,
        nullable=True
    )

    # العلاقات
    order_items = relationship(
        "LaboratoryOrderItem",
        back_populates="test"
    )


# ============================================================
# طلب مخبري
# ============================================================

class LaboratoryOrder(Base):
    __tablename__ = "laboratory_orders"

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    order_number = Column(
        String(100),
        unique=True,
        nullable=False,
        index=True
    )

    patient_id = Column(
        Integer,
        ForeignKey("patients.id"),
        nullable=False,
        index=True
    )

    # ربط الطلب بزيارة المريض
    visit_id = Column(
        Integer,
        ForeignKey("visits.id"),
        nullable=True,
        index=True
    )

    doctor_name = Column(
        String(200),
        default=""
    )

    order_date = Column(
        String(100),
        nullable=False
    )

    clinical_notes = Column(
        Text,
        default=""
    )

    status = Column(
        String(100),
        default="جديد",
        index=True
    )

    laboratory_notes = Column(
        Text,
        default=""
    )

    created_at = Column(
        String,
        nullable=True
    )

    # العلاقات
    patient = relationship(
        "Patient",
        backref="laboratory_orders"
    )

    visit = relationship(
        "Visit",
        backref="laboratory_orders"
    )

    items = relationship(
        "LaboratoryOrderItem",
        back_populates="order",
        cascade="all, delete-orphan"
    )


# ============================================================
# عناصر الطلب المخبري
# ============================================================

class LaboratoryOrderItem(Base):
    __tablename__ = "laboratory_order_items"

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    order_id = Column(
        Integer,
        ForeignKey("laboratory_orders.id"),
        nullable=False,
        index=True
    )

    test_id = Column(
        Integer,
        ForeignKey("laboratory_tests.id"),
        nullable=False,
        index=True
    )

    result = Column(
        String(300),
        default=""
    )

    unit = Column(
        String(100),
        default=""
    )

    normal_range = Column(
        String(300),
        default=""
    )

    result_status = Column(
        String(100),
        default="لم تظهر"
    )

    notes = Column(
        Text,
        default=""
    )

    result_date = Column(
        String(100),
        default=""
    )

    # العلاقات
    order = relationship(
        "LaboratoryOrder",
        back_populates="items"
    )

    test = relationship(
        "LaboratoryTest",
        back_populates="order_items"
    )


# ============================================================
# الخدمات
# ============================================================

class Service(Base):
    __tablename__ = "services"

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    name = Column(
        String(200),
        nullable=False
    )

    category = Column(
        String(100)
    )

    price = Column(
        Float,
        default=0
    )

    notes = Column(
        Text
    )

    created_at = Column(
        String
    )
