"""Pharmacy stock and dispensing records; quantities use the medicine's base unit."""
from datetime import datetime

from sqlalchemy import (Boolean, CheckConstraint, Column, Date, DateTime, ForeignKey,
                        Integer, Numeric, String, Text, UniqueConstraint)
from sqlalchemy.orm import relationship

from database import Base


class LegacyMedication(Base):
    """Compatibility with the medication IDs required by older prescription tables."""
    __tablename__ = "medications"
    id = Column(Integer, primary_key=True)
    name = Column(String(300), nullable=False)
    category = Column(String(100))
    company = Column(String(200))
    quantity = Column(Integer, default=0)
    purchase_price = Column(Numeric(12, 2), default=0)
    selling_price = Column(Numeric(12, 2), default=0)
    expiry_date = Column(String(30))
    notes = Column(Text)
    created_at = Column(String(50))


class Medicine(Base):
    __tablename__ = "pharmacy_medicines"
    __table_args__ = (
        UniqueConstraint("clinic_id", "code"),
        CheckConstraint("sale_price >= 0 AND minimum_stock >= 0"),
    )
    id = Column(Integer, primary_key=True)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), nullable=False, index=True)
    code = Column(String(80), nullable=False)
    name = Column(String(250), nullable=False)
    generic_name = Column(String(250), default="")
    strength = Column(String(100), default="")
    unit = Column(String(60), nullable=False, default="وحدة")
    sale_price = Column(Numeric(12, 2), nullable=False, default=0)
    minimum_stock = Column(Integer, nullable=False, default=10)
    active = Column(Boolean, nullable=False, default=True)
    legacy_medication_id = Column(Integer, ForeignKey("medications.id"), nullable=True, unique=True)
    batches = relationship("MedicineBatch", back_populates="medicine")


class MedicineBatch(Base):
    __tablename__ = "pharmacy_batches"
    __table_args__ = (
        UniqueConstraint("medicine_id", "batch_number", "expiry_date"),
        CheckConstraint("quantity >= 0 AND purchase_price >= 0"),
    )
    id = Column(Integer, primary_key=True)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), nullable=False, index=True)
    medicine_id = Column(Integer, ForeignKey("pharmacy_medicines.id"), nullable=False, index=True)
    batch_number = Column(String(100), nullable=False)
    expiry_date = Column(Date, nullable=True, index=True)
    quantity = Column(Integer, nullable=False, default=0)
    purchase_price = Column(Numeric(12, 2), nullable=False, default=0)
    supplier = Column(String(250), default="")
    received_at = Column(DateTime, nullable=False, default=datetime.now)
    medicine = relationship("Medicine", back_populates="batches")


class PharmacyOrder(Base):
    __tablename__ = "pharmacy_orders"
    __table_args__ = (UniqueConstraint("clinic_id", "visit_id"),)
    id = Column(Integer, primary_key=True)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), nullable=False, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False, index=True)
    visit_id = Column(Integer, ForeignKey("visits.id"), nullable=True)
    prescription_id = Column(Integer, ForeignKey("prescriptions.id"), nullable=False, unique=True)
    invoice_id = Column(Integer, ForeignKey("invoices.id"), nullable=True, unique=True)
    status = Column(String(30), nullable=False, default="pending", index=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    dispensed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.now)
    dispensed_at = Column(DateTime, nullable=True)
    patient = relationship("Patient")
    prescription = relationship("Prescription")
    items = relationship("PharmacyOrderItem", back_populates="order", cascade="all, delete-orphan")


class PharmacyOrderItem(Base):
    __tablename__ = "pharmacy_order_items"
    __table_args__ = (CheckConstraint("quantity > 0 AND unit_price >= 0"),)
    id = Column(Integer, primary_key=True)
    order_id = Column(Integer, ForeignKey("pharmacy_orders.id"), nullable=False, index=True)
    medicine_id = Column(Integer, ForeignKey("pharmacy_medicines.id"), nullable=False)
    medicine_name = Column(String(350), nullable=False)
    quantity = Column(Integer, nullable=False)
    unit = Column(String(60), nullable=False)
    unit_price = Column(Numeric(12, 2), nullable=False)
    dosage = Column(String(200), default="")
    frequency = Column(String(200), default="")
    duration = Column(String(200), default="")
    instructions = Column(Text, default="")
    order = relationship("PharmacyOrder", back_populates="items")


class StockMovement(Base):
    __tablename__ = "pharmacy_movements"
    __table_args__ = (CheckConstraint("quantity <> 0"),)
    id = Column(Integer, primary_key=True)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), nullable=False, index=True)
    medicine_id = Column(Integer, ForeignKey("pharmacy_medicines.id"), nullable=False)
    batch_id = Column(Integer, ForeignKey("pharmacy_batches.id"), nullable=False)
    order_id = Column(Integer, ForeignKey("pharmacy_orders.id"), nullable=True)
    quantity = Column(Integer, nullable=False)
    movement_type = Column(String(40), nullable=False)
    reason = Column(Text, default="")
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.now)
    medicine = relationship("Medicine")
    batch = relationship("MedicineBatch")
