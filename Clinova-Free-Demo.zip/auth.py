# ============================================================
# CLINOVA
# نظام إدارة العيادات الذكي والمتكامل
# auth.py
# المصادقة وإدارة المستخدمين
# Multi-Tenant Authentication
# ============================================================

import datetime
import hashlib
import hmac
import secrets
from html import escape
from fastapi import HTTPException


def validate_new_password(value):
    if not 12 <= len(value) <= 256:
        raise HTTPException(400, "كلمة المرور يجب أن تكون بين 12 و256 حرفًا")

from fastapi import (
    APIRouter,
    Request,
    Form,
    Depends,
    HTTPException,
)

from fastapi.responses import (
    HTMLResponse,
    RedirectResponse,
)

from sqlalchemy.orm import Session

from database import get_db
from models import User, Clinic


router = APIRouter()


# ============================================================
# الأدوار
# ============================================================

ROLES = {
    "admin": "مدير النظام",
    "doctor": "طبيب",
    "reception": "استقبال",
    "laboratory": "مختبر",
    "radiology": "أشعة",
    "accounting": "محاسبة",
    "pharmacist": "صيدلي",
}


# ============================================================
# الوقت
# ============================================================

def now_string():
    return datetime.datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )


# ============================================================
# تشفير كلمة المرور
# ============================================================

PBKDF2_ITERATIONS = 600_000


def hash_password(password: str) -> str:
    """
    تشفير كلمة المرور باستخدام PBKDF2 + SHA256.
    """

    salt = secrets.token_hex(16)

    password_hash = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("utf-8"),
        PBKDF2_ITERATIONS,
    ).hex()

    return (
        f"pbkdf2_sha256$"
        f"{PBKDF2_ITERATIONS}$"
        f"{salt}$"
        f"{password_hash}"
    )


def verify_password(
    password: str,
    stored_hash: str,
) -> bool:
    """
    التحقق من كلمة المرور.
    """

    if not password or not stored_hash:
        return False

    try:
        parts = stored_hash.split("$")

        if len(parts) != 4:
            return False

        algorithm = parts[0]
        iterations = int(parts[1])
        salt = parts[2]
        expected_hash = parts[3]

        if algorithm != "pbkdf2_sha256":
            return False

        calculated_hash = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt.encode("utf-8"),
            iterations,
        ).hex()

        return hmac.compare_digest(
            calculated_hash,
            expected_hash,
        )

    except Exception:
        return False


# ============================================================
# المستخدم الحالي
# ============================================================

def get_current_user(
    request: Request,
    db: Session,
):
    """
    الحصول على المستخدم الحالي من Session.
    """

    user_id = request.session.get("user_id")

    if user_id:
        user = (
            db.query(User)
            .filter(User.id == user_id)
            .first()
        )

        if user and user.is_active:
            return user

    username = request.session.get("username")

    if username:
        user = (
            db.query(User)
            .filter(User.username == username)
            .first()
        )

        if user and user.is_active:
            return user

    return None


# ============================================================
# العيادة الحالية
# ============================================================

def get_current_clinic(
    request: Request,
    db: Session,
):
    """
    الحصول على العيادة المرتبطة بالمستخدم الحالي.
    """

    clinic_id = request.session.get("clinic_id")

    if not clinic_id:
        return None

    clinic = (
        db.query(Clinic)
        .filter(
            Clinic.id == clinic_id,
            Clinic.is_active == 1,
        )
        .first()
    )

    return clinic


def get_current_clinic_id(
    request: Request,
):
    """
    الحصول على clinic_id من Session.
    """

    return request.session.get("clinic_id")


# ============================================================
# التحقق من تسجيل الدخول
# ============================================================

def is_logged_in(
    request: Request,
) -> bool:
    return bool(
        request.session.get("logged_in")
    )


# ============================================================
# التحقق من المدير
# ============================================================

def is_admin_user(
    request: Request,
    db: Session,
):
    """
    إرجاع المستخدم إذا كان مدير النظام.
    """

    user = get_current_user(
        request,
        db,
    )

    if not user:
        return None

    if user.role != "admin":
        return None

    return user


def admin_required(
    request: Request,
    db: Session,
):
    """
    التحقق من أن المستخدم الحالي مدير.
    """

    return is_admin_user(
        request,
        db,
    )

# ============================================================
# نظام الصلاحيات المركزي
# ============================================================

PERMISSIONS = {
    "admin": {
        "patients": "full",
        "appointments": "full",
        "visits": "full",
        "laboratory": "full",
        "radiology": "full",
        "billing": "full",
        "reports": "full",
        "users": "full",
    },

    "doctor": {
        "patients": "full",
        "appointments": "full",
        "visits": "full",
        "laboratory": "request",
        "radiology": "request",
        "billing": "view",
        "reports": "view",
        "users": "none",
    },

    "reception": {
        "patients": "full",
        "appointments": "full",
        "visits": "view",
        "laboratory": "view",
        "radiology": "view",
        "billing": "view",
        "reports": "limited",
        "users": "none",
    },

    "laboratory": {
        "patients": "view",
        "appointments": "none",
        "visits": "view",
        "laboratory": "full",
        "radiology": "none",
        "billing": "none",
        "reports": "laboratory",
        "users": "none",
    },

    "radiology": {
        "patients": "view",
        "appointments": "none",
        "visits": "view",
        "laboratory": "none",
        "radiology": "full",
        "billing": "none",
        "reports": "radiology",
        "users": "none",
    },

    "accounting": {
        "patients": "view",
        "appointments": "none",
        "visits": "none",
        "laboratory": "none",
        "radiology": "none",
        "billing": "full",
        "reports": "financial",
        "users": "none",
    },
}

# Pharmacy inventory is writable by the pharmacist and administrator only.
# Clinicians prescribe; reception and accounting can follow orders and invoices.
for _role, _level in {"admin": "full", "doctor": "request", "reception": "view", "accounting": "view"}.items():
    PERMISSIONS[_role]["pharmacy"] = _level
for _role, _level in {"admin": "full", "doctor": "view", "reception": "view"}.items():
    PERMISSIONS[_role]["doctors"] = _level
PERMISSIONS["pharmacist"] = {
    "patients": "view", "appointments": "none", "visits": "view",
    "laboratory": "none", "radiology": "none", "billing": "view",
    "reports": "none", "users": "none", "pharmacy": "full",
}


# ============================================================
# التحقق من صلاحية المستخدم
# ============================================================

def has_permission(
    request: Request,
    db: Session,
    permission: str,
    level: str = "view",
) -> bool:
    """
    التحقق من امتلاك المستخدم للصلاحية المطلوبة.

    permission:
        patients
        appointments
        visits
        laboratory
        radiology
        billing
        reports
        users

    level:
        view
        full
        request
        limited
        laboratory
        radiology
        financial
    """

    user = get_current_user(
        request,
        db,
    )

    if not user:
        return False

    role = user.role or "user"

    # المدير لديه كل الصلاحيات
    if role == "admin":
        return True

    role_permissions = PERMISSIONS.get(
        role,
        {},
    )

    current_permission = role_permissions.get(
        permission,
        "none",
    )

    if current_permission == "none":
        return False

    if current_permission == "full":
        return True

    if level == "view":
        return current_permission in {
            "view",
            "full",
            "request",
            "limited",
            "laboratory",
            "radiology",
            "financial",
        }

    if level == "request":
        return current_permission in {
            "request",
            "full",
        }

    if level == "full":
        return current_permission == "full"

    if level == "limited":
        return current_permission in {
            "limited",
            "full",
        }

    if level == "laboratory":
        return current_permission in {
            "laboratory",
            "full",
        }

    if level == "radiology":
        return current_permission in {
            "radiology",
            "full",
        }

    if level == "financial":
        return current_permission in {
            "financial",
            "full",
        }

    return False


# ============================================================
# التحقق من صلاحية محددة
# ============================================================

def permission_required(
    request: Request,
    db: Session,
    permission: str,
    level: str = "view",
):
    """
    يرجع المستخدم إذا كانت لديه الصلاحية،
    وإلا يرجع None.
    """

    user = get_current_user(
        request,
        db,
    )

    if not user:
        return None

    if has_permission(
        request,
        db,
        permission,
        level,
    ):
        return user

    return None


# ============================================================
# اسم الصلاحية بالعربية
# ============================================================

def get_role_name(
    role: str,
) -> str:
    return ROLES.get(
        role,
        "مستخدم",
    )


# ============================================================
# تحديث Session
# ============================================================

def credential_stamp(user):
    """Invalidate signed sessions after a password change without exposing its hash."""
    from settings import session_secret
    return hmac.new(session_secret().encode(), str(user.password_hash or user.password or "").encode(), hashlib.sha256).hexdigest()


def refresh_session(
    request: Request,
    user: User,
    db: Session,
):
    """
    تحديث بيانات المستخدم داخل Session.
    """

    clinic = None

    if user.clinic_id:
        clinic = (
            db.query(Clinic)
            .filter(
                Clinic.id == user.clinic_id
            )
            .first()
        )

    request.session.clear()
    request.session["credential_stamp"] = credential_stamp(user)
    request.session["logged_in"] = True
    request.session["user_id"] = user.id
    request.session["username"] = user.username
    request.session["full_name"] = user.full_name or ""
    request.session["role"] = user.role or "user"
    request.session["clinic_id"] = (
        clinic.id
        if clinic
        else user.clinic_id
    )

    request.session["clinic_name"] = (
        clinic.name
        if clinic
        else None
    )


# ============================================================
# تسجيل الدخول
# ============================================================

@router.get(
    "/login",
    response_class=HTMLResponse,
)
def login_page(
    request: Request,
):
    if request.session.get("logged_in"):
        return RedirectResponse(
            "/",
            status_code=303,
        )

    return HTMLResponse(
        """
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">

        <head>

            <meta charset="UTF-8">

            <meta
                name="viewport"
                content="width=device-width, initial-scale=1.0"
            >

            <title>تسجيل الدخول - CLINOVA</title>

            <style>

                * {
                    box-sizing: border-box;
                }

                body {
                    margin: 0;
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background:
                        linear-gradient(
                            135deg,
                            #eff6ff,
                            #f8fafc
                        );
                    font-family:
                        Tahoma,
                        Arial,
                        sans-serif;
                }

                .card {
                    width: 100%;
                    max-width: 430px;
                    background: white;
                    padding: 35px;
                    border-radius: 22px;
                    box-shadow:
                        0 15px 45px
                        rgba(15, 23, 42, 0.10);
                }

                .logo {
                    width: 72px;
                    height: 72px;
                    margin: 0 auto 18px;
                    border-radius: 20px;
                    background: #2563eb;
                    color: white;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 30px;
                    font-weight: bold;
                }

                h1 {
                    text-align: center;
                    margin: 0 0 8px;
                    color: #0f172a;
                }

                .subtitle {
                    text-align: center;
                    color: #64748b;
                    margin-bottom: 30px;
                }

                label {
                    display: block;
                    margin: 15px 0 8px;
                    font-weight: bold;
                    color: #334155;
                }

                input {
                    width: 100%;
                    padding: 14px;
                    border: 1px solid #cbd5e1;
                    border-radius: 12px;
                    font-size: 16px;
                    outline: none;
                }

                input:focus {
                    border-color: #2563eb;
                    box-shadow:
                        0 0 0 3px
                        rgba(37, 99, 235, 0.10);
                }

                button {
                    width: 100%;
                    margin-top: 25px;
                    padding: 14px;
                    border: none;
                    border-radius: 12px;
                    background: #2563eb;
                    color: white;
                    font-size: 16px;
                    font-weight: bold;
                    cursor: pointer;
                }

                button:hover {
                    background: #1d4ed8;
                }

                .footer {
                    margin-top: 25px;
                    text-align: center;
                    color: #94a3b8;
                    font-size: 13px;
                }

            </style>

        </head>

        <body>

            <div class="card">

                <div class="logo">
                    C
                </div>

                <h1>
                    CLINOVA
                </h1>

                <div class="subtitle">
                    نظام إدارة العيادات الذكي والمتكامل
                </div>

                <form
                    method="post"
                    action="/login"
                >

                    <label>
                        اسم المستخدم
                    </label>

                    <input
                        type="text"
                        name="username"
                        autocomplete="username"
                        required
                        autofocus
                    >

                    <label>
                        كلمة المرور
                    </label>

                    <input
                        type="password"
                        name="password"
                        autocomplete="current-password"
                        required
                    >

                    <button type="submit">
                        تسجيل الدخول
                    </button>

                </form>

                <div class="footer">
                    CLINOVA © 2026
                </div>

            </div>

        </body>

        </html>
        """
    )


@router.post("/login")
def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    username = username.strip()

    if len(username) > 150 or len(password) > 256:
        raise HTTPException(400, "بيانات الدخول غير صالحة")

    user = (
        db.query(User)
        .filter(
            User.username == username
        )
        .first()
    )

    if not user:
        return HTMLResponse(
            """
            <script>
                alert("اسم المستخدم أو كلمة المرور غير صحيحة");
                window.location.href="/login";
            </script>
            """
        )

    if not user.is_active:
        return HTMLResponse(
            """
            <script>
                alert("هذا المستخدم غير فعال");
                window.location.href="/login";
            </script>
            """
        )

    valid = False

    # دعم النظام الحالي الذي يستخدم password_hash
    if user.password_hash:
        valid = verify_password(
            password,
            user.password_hash,
        )

    # دعم احتياطي للبيانات القديمة
    if not user.password_hash and user.password:
        if hmac.compare_digest(
            str(user.password),
            str(password),
        ):
            valid = True

    if not valid:
        return HTMLResponse(
            """
            <script>
                alert("اسم المستخدم أو كلمة المرور غير صحيحة");
                window.location.href="/login";
            </script>
            """
        )

    if not user.password_hash or user.password or int(user.password_hash.split("$")[1]) < PBKDF2_ITERATIONS:
        user.password_hash = hash_password(password)
        user.password = ""
        db.commit()

    refresh_session(
        request,
        user,
        db,
    )

    return RedirectResponse(
        "/",
        status_code=303,
    )


# ============================================================
# تسجيل الخروج
# ============================================================

@router.post("/logout")
def logout(
    request: Request,
):
    request.session.clear()

    return RedirectResponse(
        "/login",
        status_code=303,
    )


# ============================================================
# قائمة المستخدمين
# ============================================================

@router.get(
    "/users",
    response_class=HTMLResponse,
)
def users_page(
    request: Request,
    db: Session = Depends(get_db),
):
    admin = admin_required(
        request,
        db,
    )

    if not admin:
        return RedirectResponse(
            "/",
            status_code=303,
        )

    clinic = get_current_clinic(
        request,
        db,
    )

    if not clinic:
        return RedirectResponse(
            "/login",
            status_code=303,
        )

    users = (
        db.query(User)
        .filter(
            User.clinic_id == clinic.id
        )
        .order_by(User.id.asc())
        .all()
    )

    rows = ""

    for user in users:

        role_label = ROLES.get(
            user.role,
            user.role or "مستخدم",
        )

        status_text = (
            "فعال"
            if user.is_active
            else "معطل"
        )

        status_class = (
            "active"
            if user.is_active
            else "inactive"
        )

        toggle_text = (
            "تعطيل"
            if user.is_active
            else "تفعيل"
        )

        rows += f"""
        <tr>

            <td>
                {user.id}
            </td>

            <td>
                {escape(user.full_name or '-')}
            </td>

            <td>
                {escape(user.username or "")}
            </td>

            <td>
                {role_label}
            </td>

            <td>
                <span class="status {status_class}">
                    {status_text}
                </span>
            </td>

            <td class="actions">

                <a
                    href="/users/edit/{user.id}"
                    class="btn edit"
                >
                    تعديل
                </a>

                {
                    ""
                    if user.id == admin.id
                    else
                    f'''
                    <form method="post" action="/users/toggle/{user.id}" style="display:inline" onsubmit="return confirm('هل تريد تأكيد هذا الإجراء؟')"><button type="submit" class="btn toggle">
                        {toggle_text}
                    </button></form>
                    '''
                }

            </td>

        </tr>
        """

    if not rows:
        rows = """
        <tr>
            <td
                colspan="6"
                class="empty"
            >
                لا يوجد مستخدمون
            </td>
        </tr>
        """

    return HTMLResponse(
        f"""
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">

        <head>

            <meta charset="UTF-8">

            <meta
                name="viewport"
                content="width=device-width, initial-scale=1.0"
            >

            <title>
                مستخدمو العيادة - CLINOVA
            </title>

            <style>

                * {{
                    box-sizing: border-box;
                }}

                body {{
                    margin: 0;
                    background: #f8fafc;
                    font-family:
                        Tahoma,
                        Arial,
                        sans-serif;
                    color: #0f172a;
                }}

                header {{
                    background: white;
                    padding: 18px 30px;
                    border-bottom:
                        1px solid #e2e8f0;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }}

                .brand {{
                    font-weight: bold;
                    color: #2563eb;
                    font-size: 20px;
                }}

                .user {{
                    color: #475569;
                }}

                .container {{
                    max-width: 1200px;
                    margin: 35px auto;
                    padding: 0 20px;
                }}

                .top {{
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    gap: 20px;
                    margin-bottom: 25px;
                }}

                h1 {{
                    margin: 0;
                }}

                .btn {{
                    display: inline-block;
                    padding: 10px 15px;
                    border-radius: 9px;
                    text-decoration: none;
                    font-size: 14px;
                    margin: 2px;
                }}

                .home {{
                    background: #e2e8f0;
                    color: #334155;
                }}

                .new {{
                    background: #2563eb;
                    color: white;
                }}

                .edit {{
                    background: #dbeafe;
                    color: #1d4ed8;
                }}

                .toggle {{
                    background: #fef3c7;
                    color: #92400e;
                }}

                table {{
                    width: 100%;
                    border-collapse: collapse;
                    background: white;
                    border-radius: 16px;
                    overflow: hidden;
                    box-shadow:
                        0 5px 25px
                        rgba(0,0,0,.06);
                }}

                th,
                td {{
                    padding: 15px;
                    text-align: right;
                    border-bottom:
                        1px solid #e2e8f0;
                }}

                th {{
                    background: #f1f5f9;
                    color: #334155;
                }}

                .status {{
                    display: inline-block;
                    padding: 5px 10px;
                    border-radius: 20px;
                    font-size: 12px;
                    font-weight: bold;
                }}

                .active {{
                    background: #dcfce7;
                    color: #166534;
                }}

                .inactive {{
                    background: #fee2e2;
                    color: #991b1b;
                }}

                .empty {{
                    text-align: center;
                    padding: 40px;
                    color: #64748b;
                }}

                @media (max-width: 700px) {{

                    .top {{
                        flex-direction: column;
                        align-items: stretch;
                    }}

                    table {{
                        font-size: 13px;
                    }}

                    th,
                    td {{
                        padding: 9px;
                    }}

                }}

            </style>

        </head>

        <body>

            <header>

                <div class="brand">
                    CLINOVA
                </div>

                <div class="user">
                    {escape(admin.full_name or admin.username or '')}
                </div>

            </header>

            <main class="container">

                <div class="top">

                    <h1>
                        مستخدمو العيادة
                    </h1>

                    <div>

                        <a
                            href="/"
                            class="btn home"
                        >
                            الرئيسية
                        </a>

                        <a
                            href="/users/create"
                            class="btn new"
                        >
                            + إضافة مستخدم
                        </a>

                    </div>

                </div>

                <table>

                    <thead>

                        <tr>

                            <th>#</th>

                            <th>الاسم</th>

                            <th>اسم المستخدم</th>

                            <th>الصلاحية</th>

                            <th>الحالة</th>

                            <th>الإجراءات</th>

                        </tr>

                    </thead>

                    <tbody>

                        {rows}

                    </tbody>

                </table>

            </main>

        </body>

        </html>
        """
    )


# ============================================================
# إضافة مستخدم
# ============================================================

@router.get(
    "/users/create",
    response_class=HTMLResponse,
)
def create_user_page(
    request: Request,
    db: Session = Depends(get_db),
):
    admin = admin_required(
        request,
        db,
    )

    if not admin:
        return RedirectResponse(
            "/",
            status_code=303,
        )

    clinic = get_current_clinic(
        request,
        db,
    )

    if not clinic:
        return RedirectResponse(
            "/login",
            status_code=303,
        )

    role_options = ""

    for key, label in ROLES.items():
        role_options += f"""
        <option value="{key}">
            {label}
        </option>
        """

    return HTMLResponse(
        f"""
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">

        <head>

            <meta charset="UTF-8">

            <meta
                name="viewport"
                content="width=device-width, initial-scale=1.0"
            >

            <title>
                إضافة مستخدم - CLINOVA
            </title>

            <style>

                * {{
                    box-sizing: border-box;
                }}

                body {{
                    margin: 0;
                    background: #f8fafc;
                    font-family:
                        Tahoma,
                        Arial,
                        sans-serif;
                }}

                .container {{
                    max-width: 650px;
                    margin: 50px auto;
                    padding: 20px;
                }}

                .card {{
                    background: white;
                    padding: 30px;
                    border-radius: 18px;
                    box-shadow:
                        0 5px 25px
                        rgba(0,0,0,.08);
                }}

                h1 {{
                    margin-top: 0;
                }}

                .clinic {{
                    background: #eff6ff;
                    padding: 12px;
                    border-radius: 10px;
                    margin-bottom: 25px;
                    color: #1d4ed8;
                }}

                label {{
                    display: block;
                    margin: 15px 0 7px;
                    font-weight: bold;
                }}

                input,
                select {{
                    width: 100%;
                    padding: 13px;
                    border: 1px solid #cbd5e1;
                    border-radius: 10px;
                    font-size: 15px;
                }}

                button {{
                    width: 100%;
                    margin-top: 25px;
                    padding: 14px;
                    background: #2563eb;
                    color: white;
                    border: none;
                    border-radius: 10px;
                    font-size: 16px;
                    cursor: pointer;
                }}

                .back {{
                    display: block;
                    text-align: center;
                    margin-top: 15px;
                    color: #2563eb;
                    text-decoration: none;
                }}

            </style>

        </head>

        <body>

            <div class="container">

                <div class="card">

                    <h1>
                        إضافة مستخدم
                    </h1>

                    <div class="clinic">

                        سيتم إنشاء المستخدم داخل:

                        <strong>
                            {escape(clinic.name or "")}
                        </strong>

                    </div>

                    <form
                        method="post"
                        action="/users/create"
                    >

                        <label>
                            الاسم الكامل
                        </label>

                        <input
                            type="text"
                            name="full_name"
                            required
                        >

                        <label>
                            اسم المستخدم
                        </label>

                        <input
                            type="text"
                            name="username"
                            required
                        >

                        <label>
                            كلمة المرور
                        </label>

                        <input
                            type="password"
                            name="password"
                            required
                        >

                        <label>
                            الصلاحية
                        </label>

                        <select
                            name="role"
                            required
                        >

                            {role_options}

                        </select>

                        <button type="submit">
                            إنشاء المستخدم
                        </button>

                    </form>

                    <a
                        class="back"
                        href="/users"
                    >
                        العودة إلى المستخدمين
                    </a>

                </div>

            </div>

        </body>

        </html>
        """
    )


# ============================================================
# حفظ مستخدم جديد
# ============================================================

@router.post("/users/create")
def create_user(
    request: Request,
    full_name: str = Form(...),
    username: str = Form(...),
    password: str = Form(...),
    role: str = Form(...),
    db: Session = Depends(get_db),
):
    admin = admin_required(
        request,
        db,
    )

    if not admin:
        return RedirectResponse(
            "/",
            status_code=303,
        )

    clinic = get_current_clinic(
        request,
        db,
    )

    if not clinic:
        return RedirectResponse(
            "/login",
            status_code=303,
        )

    username = username.strip()
    full_name = full_name.strip()
    password = password.strip()

    if role not in ROLES:
        return HTMLResponse(
            """
            <script>
                alert("الصلاحية غير صحيحة");
                window.location.href="/users/create";
            </script>
            """
        )

    if not username:
        return HTMLResponse(
            """
            <script>
                alert("اسم المستخدم مطلوب");
                window.location.href="/users/create";
            </script>
            """
        )

    if not password:
        return HTMLResponse(
            """
            <script>
                alert("كلمة المرور مطلوبة");
                window.location.href="/users/create";
            </script>
            """
        )

    existing = (
        db.query(User)
        .filter(
            User.username == username
        )
        .first()
    )

    if existing:
        return HTMLResponse(
            """
            <script>
                alert("اسم المستخدم موجود مسبقاً");
                window.location.href="/users/create";
            </script>
            """
        )

    validate_new_password(password)
    user = User(
        username=username,
        full_name=full_name,
        password_hash=hash_password(
            password
        ),
        role=role,
        is_active=1,
        created_at=datetime.datetime.now(),
        clinic_id=clinic.id,
    )

    # دعم قواعد البيانات القديمة التي تحتوي
    # على عمود password إلزامي.
    if hasattr(User, "password"):
        user.password = ""

    db.add(user)

    try:
        db.commit()

    except Exception as error:

        db.rollback()

        print(
            "Create user error:",
            error,
        )

        return HTMLResponse(
            """
            <script>
                alert("حدث خطأ أثناء إنشاء المستخدم");
                window.location.href="/users/create";
            </script>
            """
        )

    return RedirectResponse(
        "/users",
        status_code=303,
    )


# ============================================================
# تعديل مستخدم
# ============================================================

@router.get(
    "/users/edit/{user_id}",
    response_class=HTMLResponse,
)
def edit_user_page(
    user_id: int,
    request: Request,
    db: Session = Depends(get_db),
):
    admin = admin_required(
        request,
        db,
    )

    if not admin:
        return RedirectResponse(
            "/",
            status_code=303,
        )

    clinic = get_current_clinic(
        request,
        db,
    )

    if not clinic:
        return RedirectResponse(
            "/login",
            status_code=303,
        )

    user = (
        db.query(User)
        .filter(
            User.id == user_id,
            User.clinic_id == clinic.id,
        )
        .first()
    )

    if not user:
        return HTMLResponse(
            """
            <script>
                alert("المستخدم غير موجود في هذه العيادة");
                window.location.href="/users";
            </script>
            """
        )

    role_options = ""

    for key, label in ROLES.items():

        selected = (
            "selected"
            if user.role == key
            else ""
        )

        role_options += f"""
        <option
            value="{key}"
            {selected}
        >
            {label}
        </option>
        """

    return HTMLResponse(
        f"""
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">

        <head>

            <meta charset="UTF-8">

            <meta
                name="viewport"
                content="width=device-width, initial-scale=1.0"
            >

            <title>
                تعديل المستخدم - CLINOVA
            </title>

            <style>

                * {{
                    box-sizing: border-box;
                }}

                body {{
                    margin: 0;
                    background: #f8fafc;
                    font-family:
                        Tahoma,
                        Arial,
                        sans-serif;
                }}

                .container {{
                    max-width: 650px;
                    margin: 50px auto;
                    padding: 20px;
                }}

                .card {{
                    background: white;
                    padding: 30px;
                    border-radius: 18px;
                    box-shadow:
                        0 5px 25px
                        rgba(0,0,0,.08);
                }}

                h1 {{
                    margin-top: 0;
                }}

                label {{
                    display: block;
                    margin: 15px 0 7px;
                    font-weight: bold;
                }}

                small {{
                    display: block;
                    margin-top: 5px;
                    color: #64748b;
                    font-weight: normal;
                }}

                input,
                select {{
                    width: 100%;
                    padding: 13px;
                    border: 1px solid #cbd5e1;
                    border-radius: 10px;
                    font-size: 15px;
                }}

                button {{
                    width: 100%;
                    margin-top: 25px;
                    padding: 14px;
                    background: #2563eb;
                    color: white;
                    border: none;
                    border-radius: 10px;
                    font-size: 16px;
                    cursor: pointer;
                }}

                .back {{
                    display: block;
                    text-align: center;
                    margin-top: 15px;
                    color: #2563eb;
                    text-decoration: none;
                }}

            </style>

        </head>

        <body>

            <div class="container">

                <div class="card">

                    <h1>
                        تعديل المستخدم
                    </h1>

                    <form
                        method="post"
                        action="/users/edit/{user.id}"
                    >

                        <label>
                            الاسم الكامل
                        </label>

                        <input
                            type="text"
                            name="full_name"
                            value="{escape(user.full_name or '')}"
                            required
                        >

                        <label>
                            اسم المستخدم
                        </label>

                        <input
                            type="text"
                            name="username"
                            value="{escape(user.username or "")}"
                            required
                        >

                        <label>
                            كلمة المرور الجديدة

                            <small>
                                اتركها فارغة للإبقاء على كلمة المرور الحالية
                            </small>

                        </label>

                        <input
                            type="password"
                            name="password"
                        >

                        <label>
                            الصلاحية
                        </label>

                        <select
                            name="role"
                            required
                        >

                            {role_options}

                        </select>

                        <button type="submit">
                            حفظ التعديلات
                        </button>

                    </form>

                    <a
                        class="back"
                        href="/users"
                    >
                        العودة إلى المستخدمين
                    </a>

                </div>

            </div>

        </body>

        </html>
        """
    )


# ============================================================
# حفظ تعديل المستخدم
# ============================================================

@router.post(
    "/users/edit/{user_id}"
)
def edit_user(
    user_id: int,
    request: Request,
    full_name: str = Form(...),
    username: str = Form(...),
    password: str = Form(""),
    role: str = Form(...),
    db: Session = Depends(get_db),
):
    admin = admin_required(
        request,
        db,
    )

    if not admin:
        return RedirectResponse(
            "/",
            status_code=303,
        )

    clinic = get_current_clinic(
        request,
        db,
    )

    if not clinic:
        return RedirectResponse(
            "/login",
            status_code=303,
        )

    user = (
        db.query(User)
        .filter(
            User.id == user_id,
            User.clinic_id == clinic.id,
        )
        .first()
    )

    if not user:
        return HTMLResponse(
            """
            <script>
                alert("المستخدم غير موجود");
                window.location.href="/users";
            </script>
            """
        )

    username = username.strip()
    full_name = full_name.strip()
    password = password.strip()

    if role not in ROLES:
        return HTMLResponse(
            """
            <script>
                alert("الصلاحية غير صحيحة");
                window.location.href="/users";
            </script>
            """
        )

    if not username:
        return HTMLResponse(
            """
            <script>
                alert("اسم المستخدم مطلوب");
                window.location.href="/users";
            </script>
            """
        )

    duplicate = (
        db.query(User)
        .filter(
            User.username == username,
            User.id != user.id,
        )
        .first()
    )

    if duplicate:
        return HTMLResponse(
            """
            <script>
                alert("اسم المستخدم مستخدم مسبقاً");
                window.location.href="/users";
            </script>
            """
        )

    user.full_name = full_name
    user.username = username
    if user.role == "admin" and user.is_active and role != "admin":
        remaining_admins = db.query(User.id).filter(User.clinic_id == clinic.id, User.role == "admin", User.is_active == True, User.id != user.id).count()
        if remaining_admins == 0:
            raise HTTPException(409, "لا يمكن تغيير دور آخر مدير فعال في المنشأة")
    user.role = role

    if password:
        validate_new_password(password)
        user.password_hash = hash_password(
            password
        )

        if hasattr(User, "password"):
            user.password = ""

    try:

        db.commit()

    except Exception as error:

        db.rollback()

        print(
            "Edit user error:",
            error,
        )

        return HTMLResponse(
            """
            <script>
                alert("حدث خطأ أثناء حفظ التعديلات");
                window.location.href="/users";
            </script>
            """
        )

    if user.id == admin.id:

        refresh_session(
            request,
            user,
            db,
        )

    return RedirectResponse(
        "/users",
        status_code=303,
    )


# ============================================================
# تفعيل / تعطيل مستخدم
# ============================================================

@router.post(
    "/users/toggle/{user_id}"
)
def toggle_user(
    user_id: int,
    request: Request,
    db: Session = Depends(get_db),
):
    admin = admin_required(
        request,
        db,
    )

    if not admin:
        return RedirectResponse(
            "/",
            status_code=303,
        )

    clinic = get_current_clinic(
        request,
        db,
    )

    if not clinic:
        return RedirectResponse(
            "/login",
            status_code=303,
        )

    user = (
        db.query(User)
        .filter(
            User.id == user_id,
            User.clinic_id == clinic.id,
        )
        .first()
    )

    if not user:
        return RedirectResponse(
            "/users",
            status_code=303,
        )

    # لا يمكن للمدير تعطيل نفسه
    if user.id == admin.id:
        return HTMLResponse(
            """
            <script>
                alert("لا يمكنك تعطيل حسابك الحالي");
                window.location.href="/users";
            </script>
            """
        )

    user.is_active = (
        0
        if user.is_active
        else 1
    )

    db.commit()

    return RedirectResponse(
        "/users",
        status_code=303,
    )


# ============================================================
# معلومات المستخدم الحالي
# ============================================================

@router.get(
    "/api/current-user"
)
def current_user_api(
    request: Request,
    db: Session = Depends(get_db),
):
    user = get_current_user(
        request,
        db,
    )

    if not user:
        return {
            "logged_in": False
        }

    clinic = get_current_clinic(
        request,
        db,
    )

    return {
        "logged_in": True,
        "user_id": user.id,
        "username": user.username,
        "full_name": user.full_name,
        "role": user.role,
        "role_name": ROLES.get(
            user.role,
            user.role,
        ),
        "clinic_id": (
            clinic.id
            if clinic
            else user.clinic_id
        ),
        "clinic_name": (
            clinic.name
            if clinic
            else None
        ),
    }


# ============================================================
# صفحة الحساب
# ============================================================



# ============================================================
# تعديل الملف الشخصي
# ============================================================

@router.get(
    "/account/profile",
    response_class=HTMLResponse,
)
def account_profile_page(
    request: Request,
    db: Session = Depends(get_db),
):
    user = get_current_user(
        request,
        db,
    )

    if not user:
        return RedirectResponse(
            "/login",
            status_code=303,
        )

    return HTMLResponse(
        f"""
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">

        <head>

            <meta charset="UTF-8">

            <meta
                name="viewport"
                content="width=device-width, initial-scale=1.0"
            >

            <title>
                تعديل الحساب - CLINOVA
            </title>

            <style>

                body {{
                    margin: 0;
                    background: #f8fafc;
                    font-family:
                        Tahoma,
                        Arial,
                        sans-serif;
                }}

                .container {{
                    max-width: 650px;
                    margin: 50px auto;
                    padding: 20px;
                }}

                .card {{
                    background: white;
                    padding: 30px;
                    border-radius: 18px;
                    box-shadow:
                        0 5px 25px
                        rgba(0,0,0,.08);
                }}

                label {{
                    display: block;
                    margin: 15px 0 7px;
                    font-weight: bold;
                }}

                input {{
                    width: 100%;
                    box-sizing: border-box;
                    padding: 13px;
                    border: 1px solid #cbd5e1;
                    border-radius: 10px;
                    font-size: 15px;
                }}

                button {{
                    width: 100%;
                    margin-top: 25px;
                    padding: 14px;
                    background: #2563eb;
                    color: white;
                    border: none;
                    border-radius: 10px;
                    font-size: 16px;
                    cursor: pointer;
                }}

                .back {{
                    display: block;
                    text-align: center;
                    margin-top: 15px;
                    color: #2563eb;
                    text-decoration: none;
                }}

            </style>

        </head>

        <body>

            <div class="container">

                <div class="card">

                    <h1>
                        تعديل بيانات الحساب
                    </h1>

                    <form
                        method="post"
                        action="/account/profile"
                    >

                        <label>
                            الاسم الكامل
                        </label>

                        <input
                            type="text"
                            name="full_name"
                            value="{escape(user.full_name or '')}"
                            required
                        >

                        <label>
                            اسم المستخدم
                        </label>

                        <input
                            type="text"
                            name="username"
                            value="{escape(user.username or "")}"
                            required
                        >

                        <button type="submit">
                            حفظ التغييرات
                        </button>

                    </form>

                    <a
                        class="back"
                        href="/account"
                    >
                        العودة إلى الحساب
                    </a>

                </div>

            </div>

        </body>

        </html>
        """
    )




# ============================================================
# تغيير كلمة المرور
# ============================================================

@router.get(
    "/account/password",
    response_class=HTMLResponse,
)
def account_password_page(
    request: Request,
    db: Session = Depends(get_db),
):
    user = get_current_user(
        request,
        db,
    )

    if not user:
        return RedirectResponse(
            "/login",
            status_code=303,
        )

    return HTMLResponse(
        """
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">

        <head>

            <meta charset="UTF-8">

            <meta
                name="viewport"
                content="width=device-width, initial-scale=1.0"
            >

            <title>
                تغيير كلمة المرور - CLINOVA
            </title>

            <style>

                body {
                    margin: 0;
                    background: #f8fafc;
                    font-family:
                        Tahoma,
                        Arial,
                        sans-serif;
                }

                .container {
                    max-width: 650px;
                    margin: 50px auto;
                    padding: 20px;
                }

                .card {
                    background: white;
                    padding: 30px;
                    border-radius: 18px;
                    box-shadow:
                        0 5px 25px
                        rgba(0,0,0,.08);
                }

                label {
                    display: block;
                    margin: 15px 0 7px;
                    font-weight: bold;
                }

                input {
                    width: 100%;
                    box-sizing: border-box;
                    padding: 13px;
                    border: 1px solid #cbd5e1;
                    border-radius: 10px;
                    font-size: 15px;
                }

                button {
                    width: 100%;
                    margin-top: 25px;
                    padding: 14px;
                    background: #2563eb;
                    color: white;
                    border: none;
                    border-radius: 10px;
                    font-size: 16px;
                    cursor: pointer;
                }

                .back {
                    display: block;
                    text-align: center;
                    margin-top: 15px;
                    color: #2563eb;
                    text-decoration: none;
                }

            </style>

        </head>

        <body>

            <div class="container">

                <div class="card">

                    <h1>
                        تغيير كلمة المرور
                    </h1>

                    <form
                        method="post"
                        action="/account/password"
                    >

                        <label>
                            كلمة المرور الحالية
                        </label>

                        <input
                            type="password"
                            name="current_password"
                            required
                        >

                        <label>
                            كلمة المرور الجديدة
                        </label>

                        <input
                            type="password"
                            name="new_password"
                            required
                        >

                        <label>
                            تأكيد كلمة المرور الجديدة
                        </label>

                        <input
                            type="password"
                            name="confirm_password"
                            required
                        >

                        <button type="submit">
                            تغيير كلمة المرور
                        </button>

                    </form>

                    <a
                        class="back"
                        href="/account"
                    >
                        العودة إلى الحساب
                    </a>

                </div>

            </div>

        </body>

        </html>
        """
    )




# ============================================================
# إنشاء المدير الافتراضي عند الحاجة
# ============================================================

def ensure_default_admin():
    """
    إنشاء المدير الافتراضي إذا لم يكن موجوداً.
    """

    import os
    from database import SessionLocal

    db = SessionLocal()

    try:

        admin = (
            db.query(User)
            .filter(
                User.username == "admin"
            )
            .first()
        )

        if admin or db.query(User.id).filter(User.role == "admin", User.is_active == True).first():
            return

        clinic = (
            db.query(Clinic)
            .filter(
                Clinic.id == 1
            )
            .first()
        )

        if not clinic:

            clinic = Clinic(
                name="CLINOVA - المنشأة الرئيسية",
                clinic_type="عيادة",
                is_active=True,
                created_at=datetime.datetime.now(),
            )

            db.add(clinic)
            db.commit()
            db.refresh(clinic)

        initial_password = os.environ.get("CLINOVA_ADMIN_PASSWORD") or secrets.token_urlsafe(14)
        admin = User(
            username="admin",
            full_name="مدير النظام",
            password_hash=hash_password(
                initial_password
            ),
            role="admin",
            is_active=1,
            clinic_id=clinic.id,
            created_at=datetime.datetime.now(),
        )

        if hasattr(User, "password"):
            admin.password = ""

        db.add(admin)
        db.commit()

        print("Initial local administrator created: admin / " + initial_password)

    except Exception as error:

        db.rollback()

        print(
            "Could not initialize default admin:",
            error,
        )

    finally:
        db.close()


# ============================================================
# تهيئة المدير الافتراضي
# ============================================================

