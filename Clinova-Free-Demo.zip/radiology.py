from clinic_security import section_guard
# =========================================================
# CLINOVA
# نظام إدارة العيادات الذكي والمتكامل
# radiology.py
# نظام إدارة التصوير الشعاعي
# =========================================================

from datetime import datetime, date
from html import escape as html_escape
from typing import Optional

from fastapi import (
    APIRouter,
    Request,
    HTTPException,
    Form,
)
from fastapi.responses import (
    HTMLResponse,
    RedirectResponse,
)
from sqlalchemy.orm import Session

from database import SessionLocal
from models import Patient, Visit
from radiology_models import (
    RadiologyRequest,
    RadiologyReport,
    RadiologyAppointment,
)


# =========================================================
# Router
# =========================================================

router = APIRouter(
    prefix="/radiology",
    tags=["Radiology"], dependencies=[section_guard("radiology")]
)


# =========================================================
# Database
# =========================================================

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# =========================================================
# Helpers
# =========================================================

def get_current_user(request: Request):
    """
    الحصول على المستخدم الحالي من Session.
    """
    user_id = request.session.get("user_id")

    if not user_id:
        return None

    try:
        return int(user_id)
    except Exception:
        return None


def esc(value):
    """
    حماية النصوص قبل إدخالها إلى HTML.
    """
    if value is None:
        return ""

    return html_escape(str(value))


def format_date(value):
    if not value:
        return "-"

    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M")

    if isinstance(value, date):
        return value.strftime("%Y-%m-%d")

    return esc(value)


def format_datetime(value):
    if not value:
        return "-"

    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M")

    return esc(value)


def parse_date(value):
    if not value:
        return None

    try:
        return datetime.strptime(
            value,
            "%Y-%m-%d"
        ).date()
    except Exception:
        return None


def parse_datetime_local(value):
    if not value:
        return None

    formats = [
        "%Y-%m-%dT%H:%M",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%dT%H:%M:%S",
    ]

    for fmt in formats:
        try:
            return datetime.strptime(
                value,
                fmt
            )
        except Exception:
            continue

    return None


def generate_request_number(db: Session):
    """
    إنشاء رقم طلب مثل:

    RAD-2026-00001
    RAD-2026-00002
    """

    year = datetime.now().year
    prefix = f"RAD-{year}-"

    last = (
        db.query(RadiologyRequest)
        .order_by(RadiologyRequest.id.desc())
        .first()
    )

    number = 1

    if last and last.request_number:
        try:
            if last.request_number.startswith(prefix):
                old_number = int(
                    last.request_number.replace(
                        prefix,
                        ""
                    )
                )

                number = old_number + 1

        except Exception:
            number = 1

    while True:
        request_number = f"{prefix}{number:05d}"

        exists = (
            db.query(RadiologyRequest)
            .filter(
                RadiologyRequest.request_number
                == request_number
            )
            .first()
        )

        if not exists:
            return request_number

        number += 1


def status_class(status):
    mapping = {
        "جديد": "status-new",
        "قيد التنفيذ": "status-progress",
        "مكتمل": "status-completed",
        "ملغي": "status-cancelled",
    }

    return mapping.get(
        status,
        "status-new"
    )


def appointment_status_class(status):
    mapping = {
        "مجدول": "status-new",
        "تم": "status-completed",
        "لم يحضر": "status-progress",
        "ملغي": "status-cancelled",
    }

    return mapping.get(
        status,
        "status-new"
    )


def status_badge(status):
    return (
        f'<span class="status-badge {status_class(status)}">'
        f'{esc(status)}'
        f'</span>'
    )


def appointment_badge(status):
    return (
        f'<span class="status-badge '
        f'{appointment_status_class(status)}">'
        f'{esc(status)}'
        f'</span>'
    )


def get_request_or_404(
    db: Session,
    request_id: int
):
    item = (
        db.query(RadiologyRequest)
        .filter(
            RadiologyRequest.id == request_id
        )
        .first()
    )

    if not item:
        raise HTTPException(
            status_code=404,
            detail="طلب الأشعة غير موجود"
        )

    return item


def get_patient_or_404(
    db: Session,
    patient_id: int
):
    patient = (
        db.query(Patient)
        .filter(
            Patient.id == patient_id
        )
        .first()
    )

    if not patient:
        raise HTTPException(
            status_code=404,
            detail="المريض غير موجود"
        )

    return patient


def get_visit_for_patient(
    db: Session,
    visit_id: int,
    patient_id: int
):
    visit = (
        db.query(Visit)
        .filter(
            Visit.id == visit_id,
            Visit.patient_id == patient_id
        )
        .first()
    )

    if not visit:
        raise HTTPException(
            status_code=404,
            detail="الزيارة غير موجودة أو لا تتبع هذا المريض"
        )

    return visit


# =========================================================
# HTML Layout
# =========================================================

def page(
    title: str,
    content: str
):
    return f"""
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>{esc(title)} - CLINOVA</title>

<style>

* {{
    box-sizing: border-box;
}}

body {{
    margin: 0;
    font-family:
        "Segoe UI",
        Tahoma,
        Arial,
        sans-serif;

    background: #f4f7fb;
    color: #172033;
}}

a {{
    text-decoration: none;
    color: inherit;
}}

.container {{
    width: min(1400px, 94%);
    margin: 30px auto;
}}

.header {{
    background: linear-gradient(
        135deg,
        #0f172a,
        #1e3a8a
    );

    color: white;
    border-radius: 20px;
    padding: 24px 28px;
    margin-bottom: 24px;

    box-shadow:
        0 12px 35px
        rgba(15, 23, 42, .12);
}}

.header-row {{
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}}

.logo {{
    font-size: 28px;
    font-weight: 800;
}}

.subtitle {{
    margin-top: 6px;
    opacity: .82;
    font-size: 14px;
}}

.nav {{
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}}

.nav a {{
    background: rgba(255,255,255,.12);
    border: 1px solid rgba(255,255,255,.16);
    padding: 9px 13px;
    border-radius: 10px;
    font-size: 13px;
}}

.nav a:hover {{
    background: rgba(255,255,255,.2);
}}

.cards {{
    display: grid;
    grid-template-columns:
        repeat(auto-fit, minmax(190px, 1fr));

    gap: 16px;
    margin-bottom: 24px;
}}

.card {{
    background: white;
    border-radius: 16px;
    padding: 20px;

    border: 1px solid #e6eaf0;

    box-shadow:
        0 6px 20px
        rgba(15, 23, 42, .05);
}}

.stat-number {{
    font-size: 30px;
    font-weight: 800;
    margin-top: 7px;
}}

.stat-title {{
    color: #64748b;
    font-size: 14px;
}}

.section {{
    background: white;
    border-radius: 18px;
    padding: 22px;
    margin-bottom: 20px;

    border: 1px solid #e6eaf0;

    box-shadow:
        0 6px 20px
        rgba(15, 23, 42, .04);
}}

.section-title {{
    font-size: 19px;
    font-weight: 800;
    margin-bottom: 18px;
}}

.grid {{
    display: grid;
    grid-template-columns:
        repeat(auto-fit, minmax(250px, 1fr));

    gap: 16px;
}}

label {{
    display: block;
    font-weight: 700;
    margin-bottom: 7px;
    color: #334155;
}}

input,
select,
textarea {{
    width: 100%;
    border: 1px solid #d9e0ea;
    border-radius: 10px;
    padding: 11px 12px;
    font-family: inherit;
    font-size: 14px;
    background: white;
}}

textarea {{
    min-height: 120px;
    resize: vertical;
}}

input:focus,
select:focus,
textarea:focus {{
    outline: none;
    border-color: #2563eb;
    box-shadow:
        0 0 0 3px
        rgba(37,99,235,.10);
}}

.form-group {{
    margin-bottom: 16px;
}}

.full {{
    grid-column: 1 / -1;
}}

.btn {{
    display: inline-flex;
    align-items: center;
    justify-content: center;

    border: 0;
    border-radius: 10px;

    padding: 10px 15px;

    font-family: inherit;
    font-size: 14px;
    font-weight: 700;

    cursor: pointer;
}}

.btn-primary {{
    background: #2563eb;
    color: white;
}}

.btn-success {{
    background: #16a34a;
    color: white;
}}

.btn-warning {{
    background: #d97706;
    color: white;
}}

.btn-danger {{
    background: #dc2626;
    color: white;
}}

.btn-secondary {{
    background: #e2e8f0;
    color: #1e293b;
}}

.btn-dark {{
    background: #0f172a;
    color: white;
}}

.actions {{
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}}

.table-wrap {{
    overflow-x: auto;
}}

table {{
    width: 100%;
    border-collapse: collapse;
    min-width: 950px;
}}

th {{
    background: #f8fafc;
    color: #475569;
    font-size: 13px;
}}

th,
td {{
    padding: 13px 11px;
    border-bottom: 1px solid #edf0f4;
    text-align: right;
    vertical-align: middle;
}}

tr:hover td {{
    background: #fafcff;
}}

.status-badge {{
    display: inline-block;
    padding: 5px 10px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 800;
}}

.status-new {{
    background: #dbeafe;
    color: #1d4ed8;
}}

.status-progress {{
    background: #fef3c7;
    color: #92400e;
}}

.status-completed {{
    background: #dcfce7;
    color: #166534;
}}

.status-cancelled {{
    background: #fee2e2;
    color: #991b1b;
}}

.info-grid {{
    display: grid;
    grid-template-columns:
        repeat(auto-fit, minmax(220px, 1fr));

    gap: 12px;
}}

.info-item {{
    background: #f8fafc;
    padding: 14px;
    border-radius: 12px;
}}

.info-label {{
    color: #64748b;
    font-size: 12px;
    margin-bottom: 5px;
}}

.info-value {{
    font-weight: 700;
}}

.alert {{
    padding: 14px 16px;
    border-radius: 12px;
    margin-bottom: 18px;
}}

.alert-info {{
    background: #eff6ff;
    color: #1e40af;
}}

.alert-warning {{
    background: #fffbeb;
    color: #92400e;
}}

.alert-success {{
    background: #f0fdf4;
    color: #166534;
}}

.empty {{
    text-align: center;
    padding: 35px 15px;
    color: #64748b;
}}

.result-box {{
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    padding: 18px;
    white-space: pre-wrap;
    line-height: 1.9;
}}

.timeline {{
    border-right: 3px solid #dbeafe;
    padding-right: 18px;
}}

.timeline-item {{
    margin-bottom: 18px;
    position: relative;
}}

.timeline-item::before {{
    content: "";
    position: absolute;
    right: -26px;
    top: 4px;

    width: 11px;
    height: 11px;

    background: #2563eb;
    border-radius: 50%;
}}

.small {{
    font-size: 12px;
    color: #64748b;
}}

.danger-text {{
    color: #b91c1c;
}}

.success-text {{
    color: #15803d;
}}

@media (max-width: 700px) {{

    .container {{
        width: 96%;
        margin: 15px auto;
    }}

    .header {{
        padding: 18px;
    }}

    .section {{
        padding: 16px;
    }}

    .logo {{
        font-size: 23px;
    }}
}}

</style>

</head>

<body>

<div class="container">

<div class="header">

    <div class="header-row">

        <div>
            <div class="logo">
                CLINOVA
            </div>

            <div class="subtitle">
                نظام إدارة التصوير الشعاعي
            </div>
        </div>

        <div class="nav">

            <a href="/">
                الرئيسية
            </a>

            <a href="/patients">
                المرضى
            </a>

            <a href="/appointments">
                المواعيد
            </a>

            <a href="/laboratory">
                المختبر
            </a>

            <a href="/radiology">
                التصوير الشعاعي
            </a>

        </div>

    </div>

</div>

{content}

</div>

</body>
</html>
"""


# =========================================================
# الصفحة الرئيسية للأشعة
# =========================================================

@router.get(
    "",
    response_class=HTMLResponse
)
@router.get(
    "/",
    response_class=HTMLResponse
)
def radiology_home(
    request: Request
):

    db = SessionLocal()

    try:

        total = (
            db.query(RadiologyRequest)
            .count()
        )

        new_count = (
            db.query(RadiologyRequest)
            .filter(
                RadiologyRequest.status == "جديد"
            )
            .count()
        )

        progress_count = (
            db.query(RadiologyRequest)
            .filter(
                RadiologyRequest.status
                == "قيد التنفيذ"
            )
            .count()
        )

        completed_count = (
            db.query(RadiologyRequest)
            .filter(
                RadiologyRequest.status
                == "مكتمل"
            )
            .count()
        )

        requests = (
            db.query(RadiologyRequest)
            .order_by(
                RadiologyRequest.id.desc()
            )
            .limit(100)
            .all()
        )

        rows = ""

        for item in requests:

            patient = item.patient
            visit = item.visit
            appointment = item.scheduled_appointment

            patient_name = (
                patient.full_name
                if patient
                else "غير معروف"
            )

            visit_text = "-"

            if visit:
                visit_text = (
                    f"زيارة #{visit.id}"
                    f" - {format_date(visit.visit_date)}"
                )

            appointment_text = "-"

            if appointment:
                appointment_text = (
                    f"{format_datetime(appointment.appointment_date)}"
                    f"<br>"
                    f"{appointment_badge(appointment.status)}"
                )

            rows += f"""
<tr>

<td>
    <strong>{esc(item.request_number)}</strong>
</td>

<td>
    <a href="/patients/{item.patient_id}"
       style="color:#2563eb;font-weight:700;">
        {esc(patient_name)}
    </a>
</td>

<td>
    {esc(item.imaging_type)}
</td>

<td>
    {esc(item.examination_name)}
</td>

<td>
    {esc(item.doctor_name or "-")}
</td>

<td>
    {esc(visit_text)}
</td>

<td>
    {format_date(item.request_date)}
</td>

<td>
    {status_badge(item.status)}
</td>

<td>
    {appointment_text}
</td>

<td>

<div class="actions">

<a class="btn btn-primary"
   href="/radiology/{item.id}">
   فتح
</a>

</div>

</td>

</tr>
"""

        if not rows:

            rows = """
<tr>
<td colspan="10">
    <div class="empty">
        لا توجد طلبات أشعة حتى الآن
    </div>
</td>
</tr>
"""

        content = f"""

<div class="actions"
     style="margin-bottom:20px;">

<a href="/radiology/new"
   class="btn btn-primary">
   + طلب أشعة جديد
</a>

</div>

<div class="cards">

<div class="card">
    <div class="stat-title">
        إجمالي الطلبات
    </div>

    <div class="stat-number">
        {total}
    </div>
</div>

<div class="card">
    <div class="stat-title">
        طلبات جديدة
    </div>

    <div class="stat-number">
        {new_count}
    </div>
</div>

<div class="card">
    <div class="stat-title">
        قيد التنفيذ
    </div>

    <div class="stat-number">
        {progress_count}
    </div>
</div>

<div class="card">
    <div class="stat-title">
        مكتملة
    </div>

    <div class="stat-number">
        {completed_count}
    </div>
</div>

</div>

<div class="section">

<div class="section-title">
    طلبات التصوير الشعاعي
</div>

<div class="table-wrap">

<table>

<thead>

<tr>

<th>رقم الطلب</th>
<th>المريض</th>
<th>التصوير</th>
<th>الفحص</th>
<th>الطبيب المحيل</th>
<th>الزيارة</th>
<th>التاريخ</th>
<th>الحالة</th>
<th>الموعد</th>
<th>الإجراء</th>

</tr>

</thead>

<tbody>

{rows}

</tbody>

</table>

</div>

</div>
"""

        return HTMLResponse(
            page(
                "التصوير الشعاعي",
                content
            )
        )

    finally:
        db.close()


# =========================================================
# إنشاء طلب أشعة
# =========================================================

@router.get(
    "/new",
    response_class=HTMLResponse
)
def new_radiology_request(
    request: Request,
    patient_id: Optional[int] = None,
    visit_id: Optional[int] = None,
):

    db = SessionLocal()

    try:

        patients = (
            db.query(Patient)
            .order_by(
                Patient.full_name.asc()
            )
            .all()
        )

        visits = (
            db.query(Visit)
            .order_by(
                Visit.visit_date.desc(),
                Visit.id.desc()
            )
            .limit(500)
            .all()
        )

        selected_patient = None
        selected_visit = None

        if patient_id:

            selected_patient = (
                db.query(Patient)
                .filter(
                    Patient.id == patient_id
                )
                .first()
            )

        if visit_id and patient_id:

            selected_visit = (
                db.query(Visit)
                .filter(
                    Visit.id == visit_id,
                    Visit.patient_id == patient_id
                )
                .first()
            )

        patient_options = ""

        for patient in patients:

            selected = (
                "selected"
                if selected_patient
                and patient.id == selected_patient.id
                else ""
            )

            patient_options += f"""
<option value="{patient.id}" {selected}>
    {esc(patient.full_name)}
    -
    ملف #{esc(patient.file_number or patient.id)}
</option>
"""

        visit_options = """
<option value="">
    بدون ربط بزيارة
</option>
"""

        for visit in visits:

            patient = visit.patient

            patient_name = (
                patient.full_name
                if patient
                else "مريض"
            )

            selected = (
                "selected"
                if selected_visit
                and visit.id == selected_visit.id
                else ""
            )

            visit_options += f"""
<option
    value="{visit.id}"
    data-patient-id="{visit.patient_id}"
    {selected}
>
    {esc(patient_name)}
    -
    زيارة #{visit.id}
    -
    {format_date(visit.visit_date)}
    -
    {esc(visit.doctor_name or "بدون طبيب")}
</option>
"""

        content = f"""

<div class="section">

<div class="section-title">
    إنشاء طلب تصوير شعاعي جديد
</div>

<div class="alert alert-info">

يفضل إنشاء طلب الأشعة من داخل
<strong>زيارة المريض</strong>
حتى يتم ربط الطلب تلقائياً بالزيارة والملف الطبي.

</div>

<form method="post"
      action="/radiology/new">

<div class="grid">

<div class="form-group">

<label>
    المريض *
</label>

<select
    name="patient_id"
    id="patient_id"
    required
>

<option value="">
    اختر المريض
</option>

{patient_options}

</select>

</div>


<div class="form-group">

<label>
    الزيارة
</label>

<select
    name="visit_id"
    id="visit_id"
>

{visit_options}

</select>

<div class="small"
     style="margin-top:6px;">
    اختر زيارة المريض إذا كان الطلب مرتبطاً بزيارة محددة.
</div>

</div>


<div class="form-group">

<label>
    نوع التصوير *
</label>

<select
    name="imaging_type"
    required
>

<option value="">
    اختر نوع التصوير
</option>

<option value="X-Ray">
    X-Ray
</option>

<option value="CT">
    CT Scan
</option>

<option value="MRI">
    MRI
</option>

<option value="Ultrasound">
    Ultrasound
</option>

<option value="Mammography">
    Mammography
</option>

<option value="Doppler">
    Doppler
</option>

<option value="Fluoroscopy">
    Fluoroscopy
</option>

<option value="PET Scan">
    PET Scan
</option>

<option value="Other">
    أخرى
</option>

</select>

</div>


<div class="form-group">

<label>
    اسم الفحص *
</label>

<input
    type="text"
    name="examination_name"
    required
    placeholder="مثال: صورة صدر أمامية وجانبية"
>

</div>


<div class="form-group">

<label>
    المنطقة المراد تصويرها
</label>

<input
    type="text"
    name="body_part"
    placeholder="مثال: الصدر، الرأس، البطن..."
>

</div>


<div class="form-group">

<label>
    الطبيب المحيل
</label>

<input
    type="text"
    name="doctor_name"
    placeholder="اسم الطبيب"
>

</div>


<div class="form-group">

<label>
    الأولوية
</label>

<select name="priority">

<option value="عادي">
    عادي
</option>

<option value="عاجل">
    عاجل
</option>

<option value="طارئ">
    طارئ
</option>

</select>

</div>


<div class="form-group">

<label>
    تاريخ إجراء الفحص المتوقع
</label>

<input
    type="date"
    name="examination_date"
>

</div>


<div class="form-group full">

<label>
    الاستطباب / السبب السريري
</label>

<textarea
    name="clinical_indication"
    placeholder="سبب طلب التصوير والأعراض أو التشخيص السريري..."
></textarea>

</div>


<div class="form-group full">

<label>
    ملاحظات
</label>

<textarea
    name="notes"
    placeholder="أي ملاحظات إضافية..."
></textarea>

</div>

</div>


<div class="actions"
     style="margin-top:20px;">

<button
    type="submit"
    class="btn btn-primary"
>
    إنشاء طلب الأشعة
</button>

<a
    href="/radiology"
    class="btn btn-secondary"
>
    إلغاء
</a>

</div>

</form>

</div>


<script>

const patientSelect =
    document.getElementById("patient_id");

const visitSelect =
    document.getElementById("visit_id");


function filterVisits() {{

    const patientId =
        patientSelect.value;

    const options =
        visitSelect.querySelectorAll(
            "option[data-patient-id]"
        );

    options.forEach(function(option) {{

        if (
            !patientId ||
            option.dataset.patientId === patientId
        ) {{
            option.hidden = false;
        }} else {{
            option.hidden = true;

            if (option.selected) {{
                visitSelect.value = "";
            }}
        }}

    }});
}}


patientSelect.addEventListener(
    "change",
    filterVisits
);

filterVisits();

</script>

"""

        return HTMLResponse(
            page(
                "طلب أشعة جديد",
                content
            )
        )

    finally:
        db.close()


# =========================================================
# حفظ طلب الأشعة
# =========================================================

@router.post(
    "/new"
)
def create_radiology_request(
    request: Request,
    patient_id: int = Form(...),
    visit_id: Optional[str] = Form(None),
    doctor_name: Optional[str] = Form(None),
    imaging_type: str = Form(...),
    examination_name: str = Form(...),
    body_part: Optional[str] = Form(None),
    priority: str = Form("عادي"),
    examination_date: Optional[str] = Form(None),
    clinical_indication: Optional[str] = Form(None),
    notes: Optional[str] = Form(None),
):

    db = SessionLocal()

    try:

        patient = get_patient_or_404(
            db,
            patient_id
        )

        parsed_visit_id = None

        if visit_id:
            try:
                parsed_visit_id = int(visit_id)
            except Exception:
                raise HTTPException(
                    status_code=400,
                    detail="رقم الزيارة غير صحيح"
                )

        visit = None

        if parsed_visit_id:

            visit = get_visit_for_patient(
                db,
                parsed_visit_id,
                patient.id
            )

        allowed_types = {
            "X-Ray",
            "CT",
            "MRI",
            "Ultrasound",
            "Mammography",
            "Doppler",
            "Fluoroscopy",
            "PET Scan",
            "Other",
        }

        if imaging_type not in allowed_types:
            raise HTTPException(
                status_code=400,
                detail="نوع التصوير غير صحيح"
            )

        if not examination_name.strip():
            raise HTTPException(
                status_code=400,
                detail="اسم الفحص مطلوب"
            )

        valid_priorities = {
            "عادي",
            "عاجل",
            "طارئ",
        }

        if priority not in valid_priorities:
            priority = "عادي"

        examination_date_value = parse_date(
            examination_date
        )

        current_user_id = get_current_user(
            request
        )

        item = RadiologyRequest(

            request_number=
                generate_request_number(db),

            patient_id=patient.id,

            doctor_name=
                doctor_name.strip()
                if doctor_name
                else None,

            imaging_type=
                imaging_type.strip(),

            examination_name=
                examination_name.strip(),

            body_part=
                body_part.strip()
                if body_part
                else None,

            clinical_indication=
                clinical_indication.strip()
                if clinical_indication
                else None,

            priority=priority,

            status="جديد",

            request_date=date.today(),

            examination_date=
                examination_date_value,

            notes=
                notes.strip()
                if notes
                else None,

            created_by=current_user_id,
        )

        # -------------------------------------------------
        # ربط الزيارة
        # -------------------------------------------------

        if parsed_visit_id:

            if not hasattr(
                RadiologyRequest,
                "visit_id"
            ):
                raise HTTPException(
                    status_code=500,
                    detail=(
                        "نموذج الأشعة لا يحتوي visit_id. "
                        "استبدل radiology_models.py "
                        "بالنسخة الجديدة."
                    )
                )

            item.visit_id = parsed_visit_id

        db.add(item)

        db.commit()

        db.refresh(item)

        return RedirectResponse(
            url=f"/radiology/{item.id}",
            status_code=303
        )

    except HTTPException:
        db.rollback()
        raise

    except Exception:
        db.rollback()
        raise

    finally:
        db.close()


# =========================================================
# أشعة مريض محدد
# =========================================================

@router.get(
    "/patient/{patient_id}",
    response_class=HTMLResponse
)
def patient_radiology(
    request: Request,
    patient_id: int
):

    db = SessionLocal()

    try:

        patient = get_patient_or_404(
            db,
            patient_id
        )

        items = (
            db.query(RadiologyRequest)
            .filter(
                RadiologyRequest.patient_id
                == patient.id
            )
            .order_by(
                RadiologyRequest.id.desc()
            )
            .all()
        )

        rows = ""

        for item in items:

            visit_text = "-"

            if item.visit:
                visit_text = (
                    f"زيارة #{item.visit.id}"
                    f" - "
                    f"{format_date(item.visit.visit_date)}"
                )

            rows += f"""
<tr>

<td>
    {esc(item.request_number)}
</td>

<td>
    {esc(item.imaging_type)}
</td>

<td>
    {esc(item.examination_name)}
</td>

<td>
    {esc(visit_text)}
</td>

<td>
    {format_date(item.request_date)}
</td>

<td>
    {status_badge(item.status)}
</td>

<td>

<a
 href="/radiology/{item.id}"
 class="btn btn-primary"
>
    فتح
</a>

</td>

</tr>
"""

        if not rows:

            rows = """
<tr>
<td colspan="7">
<div class="empty">
    لا توجد طلبات أشعة لهذا المريض.
</div>
</td>
</tr>
"""

        content = f"""

<div class="section">

<div class="section-title">
    ملف الأشعة للمريض:
    {esc(patient.full_name)}
</div>

<div class="actions"
     style="margin-bottom:18px;">

<a
 href="/radiology/new?patient_id={patient.id}"
 class="btn btn-primary"
>
    + طلب أشعة جديد
</a>

<a
 href="/patients/{patient.id}"
 class="btn btn-secondary"
>
    العودة إلى ملف المريض
</a>

</div>


<div class="info-grid">

<div class="info-item">

<div class="info-label">
    اسم المريض
</div>

<div class="info-value">
    {esc(patient.full_name)}
</div>

</div>


<div class="info-item">

<div class="info-label">
    رقم الملف
</div>

<div class="info-value">
    {esc(patient.file_number or "-")}
</div>

</div>


<div class="info-item">

<div class="info-label">
    الرقم الطبي
</div>

<div class="info-value">
    {esc(patient.medical_number or "-")}
</div>

</div>

</div>

</div>


<div class="section">

<div class="section-title">
    طلبات الأشعة
</div>

<div class="table-wrap">

<table>

<thead>

<tr>
<th>رقم الطلب</th>
<th>النوع</th>
<th>الفحص</th>
<th>الزيارة</th>
<th>التاريخ</th>
<th>الحالة</th>
<th>الإجراء</th>
</tr>

</thead>

<tbody>

{rows}

</tbody>

</table>

</div>

</div>

"""

        return HTMLResponse(
            page(
                f"أشعة المريض - {patient.full_name}",
                content
            )
        )

    finally:
        db.close()


# =========================================================
# أشعة زيارة محددة
# =========================================================

@router.get(
    "/visit/{visit_id}",
    response_class=HTMLResponse
)
def visit_radiology(
    request: Request,
    visit_id: int
):

    db = SessionLocal()

    try:

        visit = (
            db.query(Visit)
            .filter(
                Visit.id == visit_id
            )
            .first()
        )

        if not visit:

            raise HTTPException(
                status_code=404,
                detail="الزيارة غير موجودة"
            )

        patient = visit.patient

        items = (
            db.query(RadiologyRequest)
            .filter(
                RadiologyRequest.visit_id
                == visit.id
            )
            .order_by(
                RadiologyRequest.id.desc()
            )
            .all()
        )

        rows = ""

        for item in items:

            rows += f"""
<tr>

<td>
    {esc(item.request_number)}
</td>

<td>
    {esc(item.imaging_type)}
</td>

<td>
    {esc(item.examination_name)}
</td>

<td>
    {esc(item.doctor_name or "-")}
</td>

<td>
    {format_date(item.request_date)}
</td>

<td>
    {status_badge(item.status)}
</td>

<td>
<a
 href="/radiology/{item.id}"
 class="btn btn-primary"
>
    فتح
</a>
</td>

</tr>
"""

        if not rows:

            rows = """
<tr>
<td colspan="7">
<div class="empty">
    لا توجد طلبات أشعة مرتبطة بهذه الزيارة.
</div>
</td>
</tr>
"""

        content = f"""

<div class="section">

<div class="section-title">
    تصوير الأشعة للزيارة #{visit.id}
</div>

<div class="actions"
     style="margin-bottom:18px;">

<a
 href="/radiology/new?patient_id={visit.patient_id}&visit_id={visit.id}"
 class="btn btn-primary"
>
    + طلب أشعة لهذه الزيارة
</a>

<a
 href="/patients/{visit.patient_id}/visits/{visit.id}"
 class="btn btn-secondary"
>
    العودة إلى الزيارة
</a>

</div>


<div class="info-grid">

<div class="info-item">

<div class="info-label">
    المريض
</div>

<div class="info-value">
    {esc(patient.full_name if patient else "-")}
</div>

</div>


<div class="info-item">

<div class="info-label">
    تاريخ الزيارة
</div>

<div class="info-value">
    {format_date(visit.visit_date)}
</div>

</div>


<div class="info-item">

<div class="info-label">
    الطبيب
</div>

<div class="info-value">
    {esc(visit.doctor_name or "-")}
</div>

</div>

</div>

</div>


<div class="section">

<div class="section-title">
    طلبات الأشعة المرتبطة بالزيارة
</div>

<div class="table-wrap">

<table>

<thead>

<tr>
<th>رقم الطلب</th>
<th>النوع</th>
<th>الفحص</th>
<th>الطبيب المحيل</th>
<th>التاريخ</th>
<th>الحالة</th>
<th>الإجراء</th>
</tr>

</thead>

<tbody>

{rows}

</tbody>

</table>

</div>

</div>

"""

        return HTMLResponse(
            page(
                "أشعة الزيارة",
                content
            )
        )

    finally:
        db.close()


# =========================================================
# تفاصيل طلب الأشعة
# =========================================================

@router.get(
    "/{request_id}",
    response_class=HTMLResponse
)
def radiology_detail(
    request: Request,
    request_id: int
):

    db = SessionLocal()

    try:

        item = get_request_or_404(
            db,
            request_id
        )

        patient = item.patient
        visit = item.visit
        appointment = item.scheduled_appointment
        report = item.report_record

        patient_name = (
            patient.full_name
            if patient
            else "-"
        )

        visit_html = "-"

        if visit:

            visit_html = f"""
<a
 href="/patients/{visit.patient_id}/visits/{visit.id}"
 style="color:#2563eb;font-weight:700;"
>
    زيارة #{visit.id}
    -
    {format_date(visit.visit_date)}
</a>
"""

        appointment_html = """

<div class="alert alert-info">
    لا يوجد موعد تصوير مرتبط بهذا الطلب.
</div>

<a
 href="/radiology/{id}/appointment"
 class="btn btn-primary"
>
    تحديد موعد
</a>

""".format(
    id=item.id
)

        if appointment:

            appointment_html = f"""

<div class="info-grid">

<div class="info-item">

<div class="info-label">
    الموعد
</div>

<div class="info-value">
    {format_datetime(appointment.appointment_date)}
</div>

</div>


<div class="info-item">

<div class="info-label">
    الحالة
</div>

<div class="info-value">
    {appointment_badge(appointment.status)}
</div>

</div>


<div class="info-item">

<div class="info-label">
    الغرفة
</div>

<div class="info-value">
    {esc(appointment.room or "-")}
</div>

</div>


<div class="info-item">

<div class="info-label">
    الجهاز
</div>

<div class="info-value">
    {esc(appointment.machine or "-")}
</div>

</div>

</div>

<div class="actions"
     style="margin-top:15px;">

<a
 href="/radiology/{item.id}/appointment"
 class="btn btn-warning"
>
    تعديل الموعد
</a>

</div>

"""

        report_html = """

<div class="alert alert-warning">
    لم يتم إدخال تقرير الأشعة بعد.
</div>

<a
 href="/radiology/{id}/report"
 class="btn btn-primary"
>
    كتابة التقرير والنتيجة
</a>

""".format(
    id=item.id
)

        if report:

            report_html = f"""

<div class="info-grid">

<div class="info-item">

<div class="info-label">
    طبيب الأشعة
</div>

<div class="info-value">
    {esc(report.radiologist_name or "-")}
</div>

</div>


<div class="info-item">

<div class="info-label">
    تاريخ التقرير
</div>

<div class="info-value">
    {format_date(report.report_date)}
</div>

</div>


<div class="info-item">

<div class="info-label">
    حالة التقرير
</div>

<div class="info-value">
    {esc(report.status)}
</div>

</div>

</div>


<h4>
    التقرير / الموجودات
</h4>

<div class="result-box">
{esc(report.findings or "لا يوجد تقرير")}
</div>


<h4>
    النتيجة / الانطباع
</h4>

<div class="result-box">
{esc(report.impression or "لا توجد نتيجة")}
</div>


<h4>
    التوصيات
</h4>

<div class="result-box">
{esc(report.recommendations or "لا توجد توصيات")}
</div>


<h4>
    ملاحظات
</h4>

<div class="result-box">
{esc(report.notes or "-")}
</div>


<div class="actions"
     style="margin-top:15px;">

<a
 href="/radiology/{item.id}/report"
 class="btn btn-warning"
>
    تعديل التقرير
</a>

</div>

"""

        content = f"""

<div class="actions"
     style="margin-bottom:20px;">

<a
 href="/radiology"
 class="btn btn-secondary"
>
    ← قائمة الأشعة
</a>

<a
 href="/patients/{item.patient_id}"
 class="btn btn-secondary"
>
    ملف المريض
</a>

<a
 href="/radiology/new?patient_id={item.patient_id}"
 class="btn btn-primary"
>
    + طلب أشعة جديد
</a>

</div>


<div class="section">

<div class="section-title">

    طلب الأشعة
    <span class="small">
        #{esc(item.request_number)}
    </span>

</div>


<div class="info-grid">

<div class="info-item">

<div class="info-label">
    المريض
</div>

<div class="info-value">
    <a
     href="/patients/{item.patient_id}"
     style="color:#2563eb;"
    >
        {esc(patient_name)}
    </a>
</div>

</div>


<div class="info-item">

<div class="info-label">
    الزيارة
</div>

<div class="info-value">
    {visit_html}
</div>

</div>


<div class="info-item">

<div class="info-label">
    نوع التصوير
</div>

<div class="info-value">
    {esc(item.imaging_type)}
</div>

</div>


<div class="info-item">

<div class="info-label">
    اسم الفحص
</div>

<div class="info-value">
    {esc(item.examination_name)}
</div>

</div>


<div class="info-item">

<div class="info-label">
    المنطقة
</div>

<div class="info-value">
    {esc(item.body_part or "-")}
</div>

</div>


<div class="info-item">

<div class="info-label">
    الطبيب المحيل
</div>

<div class="info-value">
    {esc(item.doctor_name or "-")}
</div>

</div>


<div class="info-item">

<div class="info-label">
    الأولوية
</div>

<div class="info-value">
    {esc(item.priority)}
</div>

</div>


<div class="info-item">

<div class="info-label">
    تاريخ الطلب
</div>

<div class="info-value">
    {format_date(item.request_date)}
</div>

</div>


<div class="info-item">

<div class="info-label">
    تاريخ الفحص
</div>

<div class="info-value">
    {format_date(item.examination_date)}
</div>

</div>


<div class="info-item">

<div class="info-label">
    الحالة
</div>

<div class="info-value">
    {status_badge(item.status)}
</div>

</div>

</div>


<div style="margin-top:18px;">

<div class="info-label">
    الاستطباب / السبب السريري
</div>

<div class="result-box">
{esc(item.clinical_indication or "-")}
</div>

</div>


<div style="margin-top:18px;">

<div class="info-label">
    ملاحظات
</div>

<div class="result-box">
{esc(item.notes or "-")}
</div>

</div>

</div>


<div class="section">

<div class="section-title">
    حالة طلب الأشعة
</div>

<form
 method="post"
 action="/radiology/{item.id}/status"
>

<div class="grid">

<div class="form-group">

<label>
    الحالة
</label>

<select name="status">

<option value="جديد"
 {"selected" if item.status == "جديد" else ""}>
    جديد
</option>

<option value="قيد التنفيذ"
 {"selected" if item.status == "قيد التنفيذ" else ""}>
    قيد التنفيذ
</option>

<option value="مكتمل"
 {"selected" if item.status == "مكتمل" else ""}>
    مكتمل
</option>

<option value="ملغي"
 {"selected" if item.status == "ملغي" else ""}>
    ملغي
</option>

</select>

</div>

</div>

<div class="actions">

<button
 type="submit"
 class="btn btn-primary"
>
    تحديث الحالة
</button>

</div>

</form>

</div>


<div class="section">

<div class="section-title">
    موعد التصوير
</div>

{appointment_html}

</div>


<div class="section">

<div class="section-title">
    تقرير الأشعة والنتيجة
</div>

{report_html}

</div>


<div class="section">

<div class="section-title">
    إجراءات
</div>

<div class="actions">

<a
 href="/radiology/{item.id}/appointment"
 class="btn btn-warning"
>
    📅 الموعد
</a>

<a
 href="/radiology/{item.id}/report"
 class="btn btn-primary"
>
    📝 التقرير والنتيجة
</a>

<form
 method="post"
 action="/radiology/{item.id}/delete"
 onsubmit="return confirm('هل أنت متأكد من حذف طلب الأشعة؟');"
>

<button
 type="submit"
 class="btn btn-danger"
>
    حذف الطلب
</button>

</form>

</div>

</div>

"""

        return HTMLResponse(
            page(
                f"طلب الأشعة {item.request_number}",
                content
            )
        )

    finally:
        db.close()


# =========================================================
# تحديث حالة طلب الأشعة
# =========================================================

@router.post(
    "/{request_id}/status"
)
def update_radiology_status(
    request: Request,
    request_id: int,
    status: str = Form(...)
):

    db = SessionLocal()

    try:

        item = get_request_or_404(
            db,
            request_id
        )

        allowed = {
            "جديد",
            "قيد التنفيذ",
            "مكتمل",
            "ملغي",
        }

        if status not in allowed:

            raise HTTPException(
                status_code=400,
                detail="حالة غير صحيحة"
            )

        item.status = status

        db.commit()

        return RedirectResponse(
            url=f"/radiology/{item.id}",
            status_code=303
        )

    finally:
        db.close()


# =========================================================
# صفحة موعد الأشعة
# =========================================================

@router.get(
    "/{request_id}/appointment",
    response_class=HTMLResponse
)
def radiology_appointment_form(
    request: Request,
    request_id: int
):

    db = SessionLocal()

    try:

        item = get_request_or_404(
            db,
            request_id
        )

        appointment = (
            db.query(RadiologyAppointment)
            .filter(
                RadiologyAppointment
                .radiology_request_id
                == item.id
            )
            .first()
        )

        current_datetime = ""

        if appointment:

            current_datetime = (
                appointment.appointment_date
                .strftime("%Y-%m-%dT%H:%M")
            )

        content = f"""

<div class="section">

<div class="section-title">
    موعد التصوير الشعاعي
</div>

<div class="alert alert-info">

المريض:
<strong>
{esc(item.patient.full_name if item.patient else "-")}
</strong>

<br>

الفحص:
<strong>
{esc(item.examination_name)}
</strong>

</div>


<form
 method="post"
 action="/radiology/{item.id}/appointment"
>

<div class="grid">

<div class="form-group">

<label>
    تاريخ ووقت الموعد *
</label>

<input
 type="datetime-local"
 name="appointment_date"
 value="{current_datetime}"
 required
>

</div>


<div class="form-group">

<label>
    الغرفة
</label>

<input
 type="text"
 name="room"
 value="{esc(appointment.room if appointment else '')}"
 placeholder="مثال: غرفة الأشعة 1"
>

</div>


<div class="form-group">

<label>
    الجهاز
</label>

<input
 type="text"
 name="machine"
 value="{esc(appointment.machine if appointment else '')}"
 placeholder="مثال: CT Scanner"
>

</div>


<div class="form-group">

<label>
    حالة الموعد
</label>

<select name="status">

<option value="مجدول"
 {"selected" if not appointment or appointment.status == "مجدول" else ""}>
    مجدول
</option>

<option value="تم"
 {"selected" if appointment and appointment.status == "تم" else ""}>
    تم
</option>

<option value="لم يحضر"
 {"selected" if appointment and appointment.status == "لم يحضر" else ""}>
    لم يحضر
</option>

<option value="ملغي"
 {"selected" if appointment and appointment.status == "ملغي" else ""}>
    ملغي
</option>

</select>

</div>


<div class="form-group full">

<label>
    ملاحظات الموعد
</label>

<textarea
 name="notes"
>{esc(appointment.notes if appointment else '')}</textarea>

</div>

</div>


<div class="actions">

<button
 type="submit"
 class="btn btn-primary"
>
    حفظ الموعد
</button>

<a
 href="/radiology/{item.id}"
 class="btn btn-secondary"
>
    إلغاء
</a>

</div>

</form>

</div>

"""

        return HTMLResponse(
            page(
                "موعد الأشعة",
                content
            )
        )

    finally:
        db.close()


# =========================================================
# حفظ موعد الأشعة
# =========================================================

@router.post(
    "/{request_id}/appointment"
)
def save_radiology_appointment(
    request: Request,
    request_id: int,
    appointment_date: str = Form(...),
    room: Optional[str] = Form(None),
    machine: Optional[str] = Form(None),
    status: str = Form("مجدول"),
    notes: Optional[str] = Form(None),
):

    db = SessionLocal()

    try:

        item = get_request_or_404(
            db,
            request_id
        )

        appointment_date_value = (
            parse_datetime_local(
                appointment_date
            )
        )

        if not appointment_date_value:

            raise HTTPException(
                status_code=400,
                detail="تاريخ الموعد غير صحيح"
            )

        allowed_statuses = {
            "مجدول",
            "تم",
            "لم يحضر",
            "ملغي",
        }

        if status not in allowed_statuses:

            raise HTTPException(
                status_code=400,
                detail="حالة الموعد غير صحيحة"
            )

        appointment = (
            db.query(RadiologyAppointment)
            .filter(
                RadiologyAppointment
                .radiology_request_id
                == item.id
            )
            .first()
        )

        if appointment:

            appointment.appointment_date = (
                appointment_date_value
            )

            appointment.room = (
                room.strip()
                if room
                else None
            )

            appointment.machine = (
                machine.strip()
                if machine
                else None
            )

            appointment.status = status

            appointment.notes = (
                notes.strip()
                if notes
                else None
            )

        else:

            appointment = RadiologyAppointment(

                radiology_request_id=
                    item.id,

                patient_id=
                    item.patient_id,

                appointment_date=
                    appointment_date_value,

                room=
                    room.strip()
                    if room
                    else None,

                machine=
                    machine.strip()
                    if machine
                    else None,

                status=status,

                notes=
                    notes.strip()
                    if notes
                    else None,
            )

            db.add(appointment)

        # ---------------------------------------------
        # مزامنة حالة طلب الأشعة
        # ---------------------------------------------

        if status == "ملغي":

            item.status = "ملغي"

        elif status == "تم":

            if item.report_record:
                item.status = "مكتمل"
            else:
                item.status = "قيد التنفيذ"

            if not item.examination_date:
                item.examination_date = (
                    appointment_date_value.date()
                )

        elif status == "مجدول":

            if item.status != "مكتمل":
                item.status = "جديد"

        elif status == "لم يحضر":

            if item.status != "مكتمل":
                item.status = "جديد"

        db.commit()

        return RedirectResponse(
            url=f"/radiology/{item.id}",
            status_code=303
        )

    except HTTPException:
        db.rollback()
        raise

    finally:
        db.close()


# =========================================================
# صفحة تقرير الأشعة
# =========================================================

@router.get(
    "/{request_id}/report",
    response_class=HTMLResponse
)
def radiology_report_form(
    request: Request,
    request_id: int
):

    db = SessionLocal()

    try:

        item = get_request_or_404(
            db,
            request_id
        )

        report = (
            db.query(RadiologyReport)
            .filter(
                RadiologyReport
                .radiology_request_id
                == item.id
            )
            .first()
        )

        content = f"""

<div class="section">

<div class="section-title">
    تقرير ونتيجة الأشعة
</div>


<div class="alert alert-info">

<strong>
    المريض:
</strong>

{esc(item.patient.full_name if item.patient else "-")}

<br>

<strong>
    الفحص:
</strong>

{esc(item.examination_name)}

<br>

<strong>
    نوع التصوير:
</strong>

{esc(item.imaging_type)}

</div>


<form
 method="post"
 action="/radiology/{item.id}/report"
>

<div class="grid">


<div class="form-group">

<label>
    طبيب الأشعة
</label>

<input
 type="text"
 name="radiologist_name"
 value="{esc(report.radiologist_name if report else item.radiologist_name or '')}"
 placeholder="اسم طبيب الأشعة"
>

</div>


<div class="form-group">

<label>
    حالة التقرير
</label>

<select name="status">

<option value="مسودة"
 {"selected" if not report or report.status == "مسودة" else ""}>
    مسودة
</option>

<option value="نهائي"
 {"selected" if report and report.status == "نهائي" else ""}>
    نهائي
</option>

</select>

</div>


<div class="form-group full">

<label>
    التقرير / الموجودات *
</label>

<textarea
 name="findings"
 required
 placeholder="اكتب وصف الصور والنتائج التي ظهرت بالفحص..."
>{esc(report.findings if report else item.report or '')}</textarea>

</div>


<div class="form-group full">

<label>
    النتيجة / الانطباع *
</label>

<textarea
 name="impression"
 required
 placeholder="اكتب النتيجة النهائية أو الانطباع التشخيصي..."
>{esc(report.impression if report else item.impression or '')}</textarea>

</div>


<div class="form-group full">

<label>
    التوصيات
</label>

<textarea
 name="recommendations"
 placeholder="التوصيات أو الفحوصات المقترحة..."
>{esc(report.recommendations if report else item.recommendations or '')}</textarea>

</div>


<div class="form-group full">

<label>
    ملاحظات
</label>

<textarea
 name="notes"
 placeholder="ملاحظات إضافية..."
>{esc(report.notes if report else item.notes or '')}</textarea>

</div>

</div>


<div class="actions">

<button
 type="submit"
 class="btn btn-success"
>
    حفظ التقرير والنتيجة
</button>

<a
 href="/radiology/{item.id}"
 class="btn btn-secondary"
>
    إلغاء
</a>

</div>

</form>

</div>

"""

        return HTMLResponse(
            page(
                "تقرير الأشعة",
                content
            )
        )

    finally:
        db.close()


# =========================================================
# حفظ تقرير الأشعة والنتيجة
# =========================================================

@router.post(
    "/{request_id}/report"
)
def save_radiology_report(
    request: Request,
    request_id: int,
    radiologist_name: Optional[str] = Form(None),
    status: str = Form("مسودة"),
    findings: str = Form(...),
    impression: str = Form(...),
    recommendations: Optional[str] = Form(None),
    notes: Optional[str] = Form(None),
):

    db = SessionLocal()

    try:

        item = get_request_or_404(
            db,
            request_id
        )

        if not findings.strip():

            raise HTTPException(
                status_code=400,
                detail="التقرير / الموجودات مطلوبة"
            )

        if not impression.strip():

            raise HTTPException(
                status_code=400,
                detail="النتيجة / الانطباع مطلوبة"
            )

        if status not in {
            "مسودة",
            "نهائي",
        }:

            status = "مسودة"

        current_user_id = get_current_user(
            request
        )

        report = (
            db.query(RadiologyReport)
            .filter(
                RadiologyReport
                .radiology_request_id
                == item.id
            )
            .first()
        )

        if report:

            report.radiologist_name = (
                radiologist_name.strip()
                if radiologist_name
                else None
            )

            report.findings = (
                findings.strip()
            )

            report.impression = (
                impression.strip()
            )

            report.recommendations = (
                recommendations.strip()
                if recommendations
                else None
            )

            report.notes = (
                notes.strip()
                if notes
                else None
            )

            report.report_date = date.today()

            report.status = status

        else:

            report = RadiologyReport(

                radiology_request_id=
                    item.id,

                radiologist_name=
                    radiologist_name.strip()
                    if radiologist_name
                    else None,

                findings=
                    findings.strip(),

                impression=
                    impression.strip(),

                recommendations=
                    recommendations.strip()
                    if recommendations
                    else None,

                notes=
                    notes.strip()
                    if notes
                    else None,

                report_date=date.today(),

                status=status,

                created_by=
                    current_user_id,
            )

            db.add(report)

        # ---------------------------------------------
        # مزامنة بيانات التقرير مع طلب الأشعة
        # ---------------------------------------------

        item.radiologist_name = (
            radiologist_name.strip()
            if radiologist_name
            else None
        )

        item.report = (
            findings.strip()
        )

        item.impression = (
            impression.strip()
        )

        item.recommendations = (
            recommendations.strip()
            if recommendations
            else None
        )

        # ---------------------------------------------
        # حالة الطلب
        # ---------------------------------------------

        if status == "نهائي":

            item.status = "مكتمل"

            if not item.examination_date:

                item.examination_date = (
                    date.today()
                )

        else:

            if item.status != "ملغي":

                item.status = "قيد التنفيذ"

        db.commit()

        return RedirectResponse(
            url=f"/radiology/{item.id}",
            status_code=303
        )

    except HTTPException:
        db.rollback()
        raise

    finally:
        db.close()


# =========================================================
# حذف طلب الأشعة
# =========================================================

@router.post(
    "/{request_id}/delete"
)
def delete_radiology_request(
    request: Request,
    request_id: int
):

    db = SessionLocal()

    try:

        item = get_request_or_404(
            db,
            request_id
        )

        report = (
            db.query(RadiologyReport)
            .filter(
                RadiologyReport
                .radiology_request_id
                == item.id
            )
            .first()
        )

        if report:
            db.delete(report)

        appointment = (
            db.query(RadiologyAppointment)
            .filter(
                RadiologyAppointment
                .radiology_request_id
                == item.id
            )
            .first()
        )

        if appointment:
            db.delete(appointment)

        db.delete(item)

        db.commit()

        return RedirectResponse(
            url="/radiology",
            status_code=303
        )

    finally:
        db.close()