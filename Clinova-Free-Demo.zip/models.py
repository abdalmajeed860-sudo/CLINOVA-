# ============================================================
# CLINOVA
# نظام إدارة العيادات الذكي والمتكامل
# models.py
# Multi-Tenant / Clinics
# ============================================================

import datetime

from sqlalchemy import (
    Column,
    Integer,
    String,
    Text,
    Date,
    DateTime,
    Float,
    Boolean,
    ForeignKey,
)

from sqlalchemy.orm import relationship

from database import Base


# ============================================================
# CLINIC
# المنشآت الطبية
# ============================================================

class Clinic(Base):
    __tablename__ = "clinics"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    name = Column(
        String(250),
        nullable=False,
        index=True
    )

    clinic_type = Column(
        String(100),
        default="عيادة",
        nullable=False
    )

    phone = Column(
        String(100),
        nullable=True
    )

    email = Column(
        String(200),
        nullable=True
    )

    address = Column(
        String(500),
        nullable=True
    )

    logo = Column(
        String(500),
        nullable=True
    )

    description = Column(
        Text,
        nullable=True
    )

    is_active = Column(
        Boolean,
        default=True,
        nullable=False
    )

    created_at = Column(
        DateTime,
        default=datetime.datetime.now,
        nullable=False
    )

    # --------------------------------------------------------
    # العلاقات
    # --------------------------------------------------------

    users = relationship(
        "User",
        back_populates="clinic"
    )

    patients = relationship(
        "Patient",
        back_populates="clinic"
    )

    visits = relationship(
        "Visit",
        back_populates="clinic"
    )

    prescriptions = relationship(
        "Prescription",
        back_populates="clinic"
    )

    prescription_items = relationship(
        "PrescriptionItem",
        back_populates="clinic"
    )

    pregnancies = relationship(
        "Pregnancy",
        back_populates="clinic"
    )

    pregnancy_followups = relationship(
        "PregnancyFollowUp",
        back_populates="clinic"
    )

    family_planning_records = relationship(
        "FamilyPlanning",
        back_populates="clinic"
    )


# ============================================================
# PATIENT
# المرضى
# ============================================================

class Patient(Base):
    __tablename__ = "patients"

    # NULL denotes a legacy shared record; new request-created records are owned.
    owner_user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    # --------------------------------------------------------
    # المنشأة
    # --------------------------------------------------------

    clinic_id = Column(
        Integer,
        ForeignKey("clinics.id"),
        nullable=True,
        index=True
    )

    medical_number = Column(
        String(100),
        unique=True,
        index=True,
        nullable=True
    )

    file_number = Column(
        String(100),
        index=True,
        nullable=True
    )

    full_name = Column(
        String(200),
        nullable=False
    )

    gender = Column(
        String(30),
        nullable=True
    )

    birth_date = Column(
        Date,
        nullable=True
    )

    phone = Column(
        String(50),
        nullable=True
    )

    address = Column(
        String(300),
        nullable=True
    )

    blood_type = Column(
        String(20),
        nullable=True
    )

    allergies = Column(
        Text,
        nullable=True
    )

    chronic_diseases = Column(
        Text,
        nullable=True
    )

    notes = Column(
        Text,
        nullable=True
    )

    created_at = Column(
        DateTime,
        default=datetime.datetime.now
    )

    clinic = relationship(
        "Clinic",
        back_populates="patients"
    )

    visits = relationship(
        "Visit",
        back_populates="patient"
    )

    pregnancies = relationship(
        "Pregnancy",
        back_populates="patient",
        cascade="all, delete-orphan"
    )

    family_planning_records = relationship(
        "FamilyPlanning",
        back_populates="patient",
        cascade="all, delete-orphan"
    )

    prescriptions = relationship(
        "Prescription",
        back_populates="patient"
    )


# ============================================================
# VISITS
# الزيارات الطبية
# ============================================================

class Visit(Base):
    __tablename__ = "visits"
    doctor_id = Column(Integer, ForeignKey("doctors.id"), nullable=True)

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    clinic_id = Column(
        Integer,
        ForeignKey("clinics.id"),
        nullable=True,
        index=True
    )

    patient_id = Column(
        Integer,
        ForeignKey("patients.id"),
        nullable=False,
        index=True
    )

    visit_date = Column(
        DateTime,
        default=datetime.datetime.now
    )

    doctor_name = Column(
        String(200),
        nullable=True
    )

    chief_complaint = Column(
        Text,
        nullable=True
    )

    examination = Column(
        Text,
        nullable=True
    )

    diagnosis = Column(
        Text,
        nullable=True
    )

    treatment = Column(
        Text,
        nullable=True
    )

    prescription = Column(
        Text,
        nullable=True
    )

    lab_requests = Column(
        Text,
        nullable=True
    )

    radiology_requests = Column(
        Text,
        nullable=True
    )

    notes = Column(
        Text,
        nullable=True
    )

    created_at = Column(
        DateTime,
        default=datetime.datetime.now
    )

    clinic = relationship(
        "Clinic",
        back_populates="visits"
    )

    patient = relationship(
        "Patient",
        back_populates="visits"
    )


# ============================================================
# PRESCRIPTION
# الوصفات الطبية
# ============================================================

class Prescription(Base):
    __tablename__ = "prescriptions"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    clinic_id = Column(
        Integer,
        ForeignKey("clinics.id"),
        nullable=True,
        index=True
    )

    patient_id = Column(
        Integer,
        ForeignKey("patients.id"),
        nullable=False
    )

    visit_id = Column(
        Integer,
        ForeignKey("visits.id"),
        nullable=True
    )

    prescription_date = Column(
        DateTime,
        default=datetime.datetime.now
    )

    diagnosis = Column(
        Text,
        nullable=True
    )

    notes = Column(
        Text,
        nullable=True
    )

    created_at = Column(
        DateTime,
        default=datetime.datetime.now
    )

    clinic = relationship(
        "Clinic",
        back_populates="prescriptions"
    )

    patient = relationship(
        "Patient",
        back_populates="prescriptions"
    )

    items = relationship(
        "PrescriptionItem",
        back_populates="prescription",
        cascade="all, delete-orphan"
    )


# ============================================================
# PRESCRIPTION ITEMS
# أدوية الوصفة
# ============================================================

class PrescriptionItem(Base):
    __tablename__ = "prescription_items"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    clinic_id = Column(
        Integer,
        ForeignKey("clinics.id"),
        nullable=True,
        index=True
    )

    prescription_id = Column(
        Integer,
        ForeignKey("prescriptions.id"),
        nullable=False
    )

    # Older databases require the legacy medication foreign key as well as the
    # readable name. New pharmacy prescriptions populate both consistently.
    medication_id = Column(Integer, ForeignKey("medications.id"), nullable=True)

    medication_name = Column(
        String(300),
        nullable=False
    )

    dosage = Column(
        String(200),
        nullable=True
    )

    frequency = Column(
        String(200),
        nullable=True
    )

    duration = Column(
        String(200),
        nullable=True
    )

    instructions = Column(
        Text,
        nullable=True
    )

    clinic = relationship(
        "Clinic",
        back_populates="prescription_items"
    )

    prescription = relationship(
        "Prescription",
        back_populates="items"
    )


# ============================================================
# PREGNANCY
# الحمل
# ============================================================

class Pregnancy(Base):
    __tablename__ = "pregnancies"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    clinic_id = Column(
        Integer,
        ForeignKey("clinics.id"),
        nullable=True,
        index=True
    )

    patient_id = Column(
        Integer,
        ForeignKey("patients.id"),
        nullable=False,
        index=True
    )

    last_menstrual_period = Column(
        Date,
        nullable=True
    )

    expected_delivery_date = Column(
        Date,
        nullable=True
    )

    pregnancy_status = Column(
        String(50),
        default="حامل"
    )

    pregnancy_type = Column(
        String(100),
        default="مفرد"
    )

    risk_level = Column(
        String(100),
        default="طبيعي"
    )

    gravida = Column(
        Integer,
        default=1
    )

    para = Column(
        Integer,
        default=0
    )

    abortions = Column(
        Integer,
        default=0
    )

    living_children = Column(
        Integer,
        default=0
    )

    fetal_heart_rate = Column(
        String(50),
        nullable=True
    )

    blood_pressure = Column(
        String(50),
        nullable=True
    )

    weight = Column(
        String(50),
        nullable=True
    )

    fundal_height = Column(
        String(50),
        nullable=True
    )

    fetal_position = Column(
        String(100),
        nullable=True
    )

    notes = Column(
        Text,
        nullable=True
    )

    created_at = Column(
        DateTime,
        default=datetime.datetime.now
    )

    clinic = relationship(
        "Clinic",
        back_populates="pregnancies"
    )

    patient = relationship(
        "Patient",
        back_populates="pregnancies"
    )

    follow_ups = relationship(
        "PregnancyFollowUp",
        back_populates="pregnancy",
        cascade="all, delete-orphan"
    )


# ============================================================
# PREGNANCY FOLLOW UP
# متابعة الحمل
# ============================================================

class PregnancyFollowUp(Base):
    __tablename__ = "pregnancy_followups"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    clinic_id = Column(
        Integer,
        ForeignKey("clinics.id"),
        nullable=True,
        index=True
    )

    pregnancy_id = Column(
        Integer,
        ForeignKey("pregnancies.id"),
        nullable=False,
        index=True
    )

    visit_date = Column(
        DateTime,
        default=datetime.datetime.now,
        nullable=False
    )

    gestational_weeks = Column(
        Integer,
        nullable=True
    )

    gestational_days = Column(
        Integer,
        nullable=True
    )

    gestational_total_days = Column(
        Integer,
        nullable=True
    )

    blood_pressure = Column(
        String(50),
        nullable=True
    )

    weight = Column(
        String(50),
        nullable=True
    )

    temperature = Column(
        String(50),
        nullable=True
    )

    pulse = Column(
        String(50),
        nullable=True
    )

    fetal_heart_rate = Column(
        String(50),
        nullable=True
    )

    fetal_movement = Column(
        String(100),
        nullable=True
    )

    fundal_height = Column(
        String(50),
        nullable=True
    )

    fetal_position = Column(
        String(100),
        nullable=True
    )

    ultrasound_result = Column(
        Text,
        nullable=True
    )

    laboratory_results = Column(
        Text,
        nullable=True
    )

    symptoms = Column(
        Text,
        nullable=True
    )

    diagnosis = Column(
        Text,
        nullable=True
    )

    treatment = Column(
        Text,
        nullable=True
    )

    medications = Column(
        Text,
        nullable=True
    )

    doctor_notes = Column(
        Text,
        nullable=True
    )

    next_visit_date = Column(
        DateTime,
        nullable=True
    )

    created_at = Column(
        DateTime,
        default=datetime.datetime.now
    )

    clinic = relationship(
        "Clinic",
        back_populates="pregnancy_followups"
    )

    pregnancy = relationship(
        "Pregnancy",
        back_populates="follow_ups"
    )


# ============================================================
# FAMILY PLANNING
# تنظيم الأسرة
# ============================================================

class FamilyPlanning(Base):
    __tablename__ = "family_planning"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    clinic_id = Column(
        Integer,
        ForeignKey("clinics.id"),
        nullable=True,
        index=True
    )

    patient_id = Column(
        Integer,
        ForeignKey("patients.id"),
        nullable=False,
        index=True
    )

    visit_date = Column(
        String(100),
        nullable=True
    )

    method = Column(
        String(200),
        nullable=True
    )

    method_details = Column(
        Text,
        nullable=True
    )

    start_date = Column(
        String(100),
        nullable=True
    )

    end_date = Column(
        String(100),
        nullable=True
    )

    side_effects = Column(
        Text,
        nullable=True
    )

    counseling = Column(
        Text,
        nullable=True
    )

    pregnancy_test = Column(
        String(100),
        nullable=True
    )

    notes = Column(
        Text,
        nullable=True
    )

    created_at = Column(
        String(100),
        nullable=True
    )

    consultation_date = Column(
        String(100),
        nullable=True
    )

    doctor_name = Column(
        String(200),
        nullable=True
    )

    marital_status = Column(
        String(100),
        nullable=True
    )

    number_of_children = Column(
        String(50),
        nullable=True
    )

    desired_number_of_children = Column(
        String(50),
        nullable=True
    )

    method_start_date = Column(
        String(100),
        nullable=True
    )

    method_end_date = Column(
        String(100),
        nullable=True
    )

    contraceptive_type = Column(
        String(200),
        nullable=True
    )

    dose_or_schedule = Column(
        String(200),
        nullable=True
    )

    complications = Column(
        Text,
        nullable=True
    )

    blood_pressure = Column(
        String(100),
        nullable=True
    )

    weight = Column(
        String(100),
        nullable=True
    )

    medical_history = Column(
        Text,
        nullable=True
    )

    examination = Column(
        Text,
        nullable=True
    )

    diagnosis = Column(
        Text,
        nullable=True
    )

    recommendations = Column(
        Text,
        nullable=True
    )

    doctor_notes = Column(
        Text,
        nullable=True
    )

    follow_up_date = Column(
        String(100),
        nullable=True
    )

    clinic = relationship(
        "Clinic",
        back_populates="family_planning_records"
    )

    patient = relationship(
        "Patient",
        back_populates="family_planning_records"
    )


# ============================================================
# USER
# المستخدمون
# ============================================================

class User(Base):
    __tablename__ = "users"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    # --------------------------------------------------------
    # المنشأة التي ينتمي إليها المستخدم
    # --------------------------------------------------------

    clinic_id = Column(
        Integer,
        ForeignKey("clinics.id"),
        nullable=True,
        index=True
    )

    username = Column(
        String(100),
        unique=True,
        nullable=False,
        index=True
    )

    password = Column(
        String(300),
        nullable=True
    )

    password_hash = Column(
        String(300),
        nullable=True
    )

    full_name = Column(
        String(200),
        nullable=True
    )

    role = Column(
        String(100),
        default="user"
    )

    is_active = Column(
        Boolean,
        default=True
    )

    created_at = Column(
        DateTime,
        default=datetime.datetime.now
    )

    clinic = relationship(
        "Clinic",
        back_populates="users"
    )


# ============================================================
# HELPERS
# أدوات حساب الحمل
# ============================================================

def calculate_gestational_age(
    last_menstrual_period,
    target_date=None
):
    """
    حساب عمر الحمل اعتماداً على تاريخ آخر دورة شهرية.

    النتيجة:
    total_days
    weeks
    days
    due_date
    """

    if not last_menstrual_period:
        return {
            "total_days": 0,
            "weeks": 0,
            "days": 0,
            "due_date": None
        }

    if isinstance(
        last_menstrual_period,
        datetime.datetime
    ):
        lmp = last_menstrual_period.date()

    elif isinstance(
        last_menstrual_period,
        datetime.date
    ):
        lmp = last_menstrual_period

    else:
        try:
            lmp = datetime.datetime.strptime(
                str(last_menstrual_period),
                "%Y-%m-%d"
            ).date()

        except (ValueError, TypeError):
            return {
                "total_days": 0,
                "weeks": 0,
                "days": 0,
                "due_date": None
            }

    if target_date is None:

        target = datetime.date.today()

    elif isinstance(
        target_date,
        datetime.datetime
    ):

        target = target_date.date()

    elif isinstance(
        target_date,
        datetime.date
    ):

        target = target_date

    else:

        try:
            target = datetime.datetime.strptime(
                str(target_date),
                "%Y-%m-%d"
            ).date()

        except (ValueError, TypeError):

            target = datetime.date.today()

    total_days = (
        target - lmp
    ).days

    if total_days < 0:
        total_days = 0

    weeks = total_days // 7

    days = total_days % 7

    due_date = (
        lmp +
        datetime.timedelta(days=280)
    )

    return {
        "total_days": total_days,
        "weeks": weeks,
        "days": days,
        "due_date": due_date
    }


# ============================================================
# END OF MODELS
# ============================================================
