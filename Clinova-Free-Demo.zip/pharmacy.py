"""Arabic pharmacy UI, clinical prescription handoff and inventory reports."""
import csv
import io
import secrets
from datetime import date, timedelta
from pathlib import Path

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from jinja2 import Environment, FileSystemLoader, select_autoescape
from sqlalchemy import case, func, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from auth import get_current_user, has_permission
from database import get_db
from models import Patient, Visit
from pharmacy_models import LegacyMedication, Medicine, MedicineBatch, PharmacyOrder, StockMovement
from pharmacy_service import (cash, create_order, dispense_order, patient_for_clinic,
                              positive_quantity, receive_stock, remove_stock)

router = APIRouter(prefix="/pharmacy", tags=["pharmacy"])
templates = Environment(loader=FileSystemLoader(Path(__file__).parent / "templates"),
                        autoescape=select_autoescape(["html", "xml"]))
templates.filters["money"] = lambda value: f"{float(value or 0):,.2f}"
STATUS = {"pending": "بانتظار الصرف", "dispensed": "تم الصرف", "cancelled": "ملغاة"}


def access(request, db, level="view"):
    user = get_current_user(request, db)
    if not user or not has_permission(request, db, "pharmacy", level):
        raise HTTPException(403, "ليس لديك صلاحية لهذا الإجراء في الصيدلية")
    if not user.clinic_id:
        raise HTTPException(403, "يجب ربط الحساب بمنشأة طبية قبل استخدام الصيدلية")
    return user


def csrf(request):
    if "pharmacy_csrf" not in request.session:
        request.session["pharmacy_csrf"] = secrets.token_urlsafe(32)
    return request.session["pharmacy_csrf"]


def verify_csrf(request, token):
    expected = request.session.get("pharmacy_csrf", "")
    if not expected or not isinstance(token, str) or not token.isascii() or not secrets.compare_digest(expected, token):
        raise HTTPException(403, "انتهت صلاحية النموذج؛ حدّث الصفحة وحاول مجددًا")


def render(request, db, template, **context):
    user = access(request, db)
    return HTMLResponse(templates.get_template(template).render(
        user=user, csrf=csrf(request), status_names=STATUS, today=date.today(),
        can_manage=has_permission(request, db, "pharmacy", "full"),
        can_prescribe=has_permission(request, db, "pharmacy", "request"), **context))


def inventory(db, clinic_id, search=""):
    available = func.coalesce(func.sum(case(
        (MedicineBatch.expiry_date >= date.today(), MedicineBatch.quantity), else_=0)), 0)
    expired = func.coalesce(func.sum(case(
        (MedicineBatch.expiry_date < date.today(), MedicineBatch.quantity), else_=0)), 0)
    query = db.query(Medicine, available.label("available"), expired.label("expired")).outerjoin(
        MedicineBatch, (MedicineBatch.medicine_id == Medicine.id) & (MedicineBatch.clinic_id == clinic_id)
    ).filter(Medicine.clinic_id == clinic_id).group_by(Medicine.id)
    if search:
        term = "%" + search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        query = query.filter(Medicine.name.ilike(term, escape="\\") | Medicine.code.ilike(term, escape="\\") |
                             Medicine.generic_name.ilike(term, escape="\\"))
    return query.order_by(Medicine.name).all()


@router.get("", response_class=HTMLResponse)
def dashboard(request: Request, q: str = "", db: Session = Depends(get_db)):
    user = access(request, db)
    all_rows = inventory(db, user.clinic_id)
    rows = inventory(db, user.clinic_id, q) if q else all_rows
    orders = db.query(PharmacyOrder).filter_by(clinic_id=user.clinic_id).order_by(PharmacyOrder.id.desc()).limit(8).all()
    expiring = db.query(MedicineBatch).filter(
        MedicineBatch.clinic_id == user.clinic_id, MedicineBatch.quantity > 0,
        MedicineBatch.expiry_date >= date.today(), MedicineBatch.expiry_date <= date.today() + timedelta(days=90)).count()
    return render(request, db, "pharmacy/dashboard.html", title="الصيدلية", active="inventory", rows=rows,
                  q=q, orders=orders, stats={"medicines": len(all_rows),
                  "low": sum(1 for row in all_rows if row.Medicine.active and row.available <= row.Medicine.minimum_stock),
                  "expiring": expiring, "pending": db.query(PharmacyOrder).filter_by(clinic_id=user.clinic_id, status="pending").count()})


@router.post("/medicines")
def add_medicine(request: Request, csrf_token: str = Form(...), code: str = Form(...), name: str = Form(...),
                 generic_name: str = Form(""), strength: str = Form(""), unit: str = Form("وحدة"),
                 sale_price: str = Form("0"), minimum_stock: int = Form(10), db: Session = Depends(get_db)):
    user = access(request, db, "full")
    verify_csrf(request, csrf_token)
    if not code.strip() or len(code.strip()) > 80 or not name.strip() or len(name.strip()) > 250 or not unit.strip() or minimum_stock < 0:
        raise HTTPException(400, "تحقق من اسم الدواء ورمزه ووحدة الصرف وحد التنبيه")
    try:
        medicine = Medicine(clinic_id=user.clinic_id, code=code.strip(), name=name.strip(),
                            generic_name=generic_name[:250], strength=strength[:100], unit=unit[:60],
                            sale_price=cash(sale_price), minimum_stock=minimum_stock)
        db.add(medicine)
        db.commit()
        return RedirectResponse(f"/pharmacy/medicines/{medicine.id}", 303)
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "رمز الدواء مستخدم مسبقًا داخل المنشأة")


@router.get("/medicines/{medicine_id}", response_class=HTMLResponse)
def medicine_details(request: Request, medicine_id: int, db: Session = Depends(get_db)):
    user = access(request, db)
    medicine = db.query(Medicine).filter_by(id=medicine_id, clinic_id=user.clinic_id).first()
    if not medicine:
        raise HTTPException(404, "الدواء غير موجود")
    batches = db.query(MedicineBatch).filter_by(medicine_id=medicine_id, clinic_id=user.clinic_id).order_by(MedicineBatch.expiry_date).all()
    movements = db.query(StockMovement).filter_by(medicine_id=medicine_id, clinic_id=user.clinic_id).order_by(StockMovement.id.desc()).limit(100).all()
    return render(request, db, "pharmacy/medicine.html", title=medicine.name, active="inventory", medicine=medicine,
                  batches=batches, movements=movements, available=sum(b.quantity for b in batches if b.expiry_date and b.expiry_date >= date.today()))


@router.post("/medicines/{medicine_id}/edit")
def edit_medicine(request: Request, medicine_id: int, csrf_token: str = Form(...), sale_price: str = Form(...),
                  minimum_stock: int = Form(...), active: str = Form(""), db: Session = Depends(get_db)):
    user = access(request, db, "full")
    verify_csrf(request, csrf_token)
    medicine = db.query(Medicine).filter_by(id=medicine_id, clinic_id=user.clinic_id).first()
    if not medicine:
        raise HTTPException(404, "الدواء غير موجود")
    if minimum_stock < 0:
        raise HTTPException(400, "حد التنبيه لا يمكن أن يكون سالبًا")
    medicine.sale_price, medicine.minimum_stock, medicine.active = cash(sale_price), minimum_stock, active == "on"
    db.commit()
    return RedirectResponse(f"/pharmacy/medicines/{medicine_id}", 303)


@router.post("/receipts")
def stock_receipt(request: Request, csrf_token: str = Form(...), medicine_id: int = Form(...),
                  batch_number: str = Form(...), expiry_date: date = Form(...), quantity: str = Form(...),
                  purchase_price: str = Form("0"), supplier: str = Form(""), db: Session = Depends(get_db)):
    user = access(request, db, "full")
    verify_csrf(request, csrf_token)
    receive_stock(db, user.clinic_id, user.id, medicine_id, batch_number, expiry_date, quantity, purchase_price, supplier)
    return RedirectResponse(f"/pharmacy/medicines/{medicine_id}", 303)


@router.post("/adjustments")
def stock_adjustment(request: Request, csrf_token: str = Form(...), batch_id: int = Form(...),
                     quantity: str = Form(...), reason: str = Form(...), db: Session = Depends(get_db)):
    user = access(request, db, "full")
    verify_csrf(request, csrf_token)
    remove_stock(db, user.clinic_id, user.id, batch_id, quantity, reason)
    return RedirectResponse("/pharmacy/reports", 303)


@router.get("/prescriptions/new", response_class=HTMLResponse)
def prescription_form(request: Request, patient_id: int | None = None, visit_id: int | None = None,
                      db: Session = Depends(get_db)):
    user = access(request, db, "request")
    patient = patient_for_clinic(db, patient_id, user.clinic_id) if patient_id else None
    visit = None
    if visit_id:
        visit = db.query(Visit).join(Patient).filter(Visit.id == visit_id, Patient.clinic_id == user.clinic_id).first()
        if not visit or (patient_id and visit.patient_id != patient_id) or visit.clinic_id not in (None, user.clinic_id):
            raise HTTPException(404, "الزيارة غير موجودة")
        patient = patient_for_clinic(db, visit.patient_id, user.clinic_id)
        existing = db.query(PharmacyOrder).filter_by(clinic_id=user.clinic_id, visit_id=visit_id).first()
        if existing:
            return RedirectResponse(f"/pharmacy/orders/{existing.id}", 303)
    patients = db.query(Patient).filter_by(clinic_id=user.clinic_id).order_by(Patient.full_name).all()
    medicines = [row for row in inventory(db, user.clinic_id) if row.Medicine.active]
    return render(request, db, "pharmacy/prescribe.html", title="وصفة جديدة", active="orders", patients=patients,
                  patient=patient, visit=visit, medicines=medicines)


@router.post("/prescriptions")
def save_prescription(request: Request, csrf_token: str = Form(...), patient_id: int = Form(...),
                      visit_id: str = Form(""), medicine_id: list[int] = Form(...), quantity: list[str] = Form(...),
                      dosage: list[str] = Form([]), frequency: list[str] = Form([]), duration: list[str] = Form([]),
                      instructions: list[str] = Form([]), diagnosis: str = Form(""), notes: str = Form(""),
                      db: Session = Depends(get_db)):
    user = access(request, db, "request")
    verify_csrf(request, csrf_token)
    if len(medicine_id) != len(quantity):
        raise HTTPException(400, "عدد الأدوية والكميات غير متطابق")
    try:
        parsed_visit_id = int(visit_id) if visit_id else None
    except ValueError:
        raise HTTPException(400, "رقم الزيارة غير صالح")
    details = {"dosage": dosage, "frequency": frequency, "duration": duration, "instructions": instructions}
    lines = [dict(medicine_id=mid, quantity=quantity[i], **{
        key: values[i] if i < len(values) else "" for key, values in details.items()
    }) for i, mid in enumerate(medicine_id)]
    order = create_order(db, user.clinic_id, user.id, patient_id, parsed_visit_id, lines, diagnosis, notes)
    return RedirectResponse(f"/pharmacy/orders/{order.id}", 303)


@router.get("/orders", response_class=HTMLResponse)
def orders_page(request: Request, status: str = "", patient_id: int | None = None, db: Session = Depends(get_db)):
    user = access(request, db)
    query = db.query(PharmacyOrder).filter_by(clinic_id=user.clinic_id)
    if patient_id:
        patient_for_clinic(db, patient_id, user.clinic_id)
        query = query.filter_by(patient_id=patient_id)
    if status:
        if status not in STATUS:
            raise HTTPException(400, "حالة الوصفة غير صالحة")
        query = query.filter_by(status=status)
    orders = query.order_by(PharmacyOrder.id.desc()).limit(200).all()
    legacy = db.query(Visit).join(Patient).filter(
        Patient.clinic_id == user.clinic_id, Visit.prescription.isnot(None), Visit.prescription != "",
        ~db.query(PharmacyOrder.id).filter(PharmacyOrder.visit_id == Visit.id).exists())
    if patient_id:
        legacy = legacy.filter(Visit.patient_id == patient_id)
    return render(request, db, "pharmacy/orders.html", title="الوصفات والصرف", active="orders", orders=orders,
                  selected_status=status, patient_id=patient_id, legacy=legacy.order_by(Visit.id.desc()).limit(50).all())


@router.get("/orders/{order_id}", response_class=HTMLResponse)
def order_details(request: Request, order_id: int, db: Session = Depends(get_db)):
    user = access(request, db)
    order = db.query(PharmacyOrder).filter_by(id=order_id, clinic_id=user.clinic_id).first()
    if not order:
        raise HTTPException(404, "الوصفة غير موجودة")
    stocks = {row.Medicine.id: row.available for row in inventory(db, user.clinic_id)}
    return render(request, db, "pharmacy/order.html", title=f"وصفة RX-{order.id:06d}", active="orders", order=order,
                  stocks=stocks, total=sum(item.quantity * item.unit_price for item in order.items))


@router.post("/orders/{order_id}/dispense")
def dispense(request: Request, order_id: int, csrf_token: str = Form(...), db: Session = Depends(get_db)):
    user = access(request, db, "full")
    verify_csrf(request, csrf_token)
    order = dispense_order(db, order_id, user.clinic_id, user.id)
    return RedirectResponse(f"/billing/invoice/{order.invoice_id}", 303)


@router.post("/orders/{order_id}/cancel")
def cancel(request: Request, order_id: int, csrf_token: str = Form(...), db: Session = Depends(get_db)):
    user = access(request, db, "full")
    verify_csrf(request, csrf_token)
    changed = db.execute(update(PharmacyOrder).where(
        PharmacyOrder.id == order_id, PharmacyOrder.clinic_id == user.clinic_id,
        PharmacyOrder.status == "pending").values(status="cancelled"))
    if changed.rowcount != 1:
        db.rollback()
        raise HTTPException(409, "يمكن إلغاء الوصفات غير المصروفة فقط")
    db.commit()
    return RedirectResponse(f"/pharmacy/orders/{order_id}", 303)


@router.get("/reports", response_class=HTMLResponse)
def reports_page(request: Request, db: Session = Depends(get_db)):
    user = access(request, db)
    rows = inventory(db, user.clinic_id)
    batches = db.query(MedicineBatch).filter(MedicineBatch.clinic_id == user.clinic_id,
        MedicineBatch.quantity > 0, MedicineBatch.expiry_date <= date.today() + timedelta(days=90)).order_by(MedicineBatch.expiry_date).all()
    movements = db.query(StockMovement).filter_by(clinic_id=user.clinic_id).order_by(StockMovement.id.desc()).limit(200).all()
    return render(request, db, "pharmacy/reports.html", title="تقارير الصيدلية", active="reports", rows=rows,
                  low=[row for row in rows if row.Medicine.active and row.available <= row.Medicine.minimum_stock],
                  batches=batches, movements=movements)


@router.get("/inventory.csv")
def export_inventory(request: Request, db: Session = Depends(get_db)):
    user = access(request, db)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["الرمز", "الدواء", "التركيز", "الوحدة", "الرصيد الصالح", "المنتهي", "حد التنبيه", "سعر البيع"])
    for row in inventory(db, user.clinic_id):
        medicine = row.Medicine
        values = [medicine.code, medicine.name, medicine.strength, medicine.unit,
                  row.available, row.expired, medicine.minimum_stock, medicine.sale_price]
        writer.writerow([("'" + str(value)) if str(value).startswith(("=", "+", "-", "@", "\t", "\r")) else value for value in values])
    return Response("\ufeff" + output.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": 'attachment; filename="pharmacy-inventory.csv"'})
