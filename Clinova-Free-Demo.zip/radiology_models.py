# ============================================================
# CLINOVA
# نظام إدارة العيادات الذكي والمتكامل
# radiology_models.py
# ============================================================

from datetime import datetime, date

from sqlalchemy import (
    Column,
    Integer,
    String,
    Text,
    Date,
    DateTime,
    ForeignKey,
)

from sqlalchemy.orm import relationship

from database import Base


# ============================================================
# RADIOLOGY REQUEST
# ============================================================

class RadiologyRequest(Base):
    __tablename__ = "radiology_requests"

    id = Column(
        Integer,
        primary_key=True,
        index=True,
    )

    request_number = Column(
        String(50),
        unique=True,
        nullable=False,
        index=True,
    )

    # --------------------------------------------------------
    # Patient
    # --------------------------------------------------------

    patient_id = Column(
        Integer,
        ForeignKey("patients.id"),
        nullable=False,
        index=True,
    )

    # --------------------------------------------------------
    # Visit
    # --------------------------------------------------------

    visit_id = Column(
        Integer,
        ForeignKey("visits.id"),
        nullable=True,
        index=True,
    )

    # --------------------------------------------------------
    # Basic request information
    # --------------------------------------------------------

    doctor_name = Column(
        String(255),
        nullable=True,
    )

    appointment_id = Column(
        Integer,
        nullable=True,
        index=True,
    )

    imaging_type = Column(
        String(100),
        nullable=False,
        index=True,
    )

    examination_name = Column(
        String(255),
        nullable=False,
    )

    body_part = Column(
        String(255),
        nullable=True,
    )

    clinical_indication = Column(
        Text,
        nullable=True,
    )

    priority = Column(
        String(50),
        nullable=False,
        default="عادي",
    )

    status = Column(
        String(50),
        nullable=False,
        default="جديد",
        index=True,
    )

    request_date = Column(
        Date,
        nullable=False,
        default=date.today,
    )

    examination_date = Column(
        Date,
        nullable=True,
    )

    # --------------------------------------------------------
    # Radiology report
    # --------------------------------------------------------

    radiologist_name = Column(
        String(255),
        nullable=True,
    )

    report = Column(
        Text,
        nullable=True,
    )

    impression = Column(
        Text,
        nullable=True,
    )

    recommendations = Column(
        Text,
        nullable=True,
    )

    notes = Column(
        Text,
        nullable=True,
    )

    image_file = Column(
        String(500),
        nullable=True,
    )

    report_file = Column(
        String(500),
        nullable=True,
    )

    # --------------------------------------------------------
    # Audit
    # --------------------------------------------------------

    created_by = Column(
        Integer,
        ForeignKey("users.id"),
        nullable=True,
    )

    created_at = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
    )

    updated_at = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    # ========================================================
    # RELATIONSHIPS
    # ========================================================

    patient = relationship(
        "Patient",
        foreign_keys=[patient_id],
    )

    visit = relationship(
        "Visit",
        foreign_keys=[visit_id],
    )

    creator = relationship(
        "User",
        foreign_keys=[created_by],
    )

    report_record = relationship(
        "RadiologyReport",
        back_populates="radiology_request",
        uselist=False,
        cascade="all, delete-orphan",
    )

    scheduled_appointment = relationship(
        "RadiologyAppointment",
        back_populates="radiology_request",
        uselist=False,
        cascade="all, delete-orphan",
    )


# ============================================================
# RADIOLOGY REPORT
# ============================================================

class RadiologyReport(Base):
    __tablename__ = "radiology_reports"

    id = Column(
        Integer,
        primary_key=True,
        index=True,
    )

    radiology_request_id = Column(
        Integer,
        ForeignKey("radiology_requests.id"),
        nullable=False,
        unique=True,
        index=True,
    )

    radiologist_name = Column(
        String(255),
        nullable=True,
    )

    findings = Column(
        Text,
        nullable=True,
    )

    impression = Column(
        Text,
        nullable=True,
    )

    recommendations = Column(
        Text,
        nullable=True,
    )

    notes = Column(
        Text,
        nullable=True,
    )

    report_date = Column(
        Date,
        nullable=False,
        default=date.today,
    )

    status = Column(
        String(50),
        nullable=False,
        default="مسودة",
    )

    created_by = Column(
        Integer,
        ForeignKey("users.id"),
        nullable=True,
    )

    created_at = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
    )

    updated_at = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    radiology_request = relationship(
        "RadiologyRequest",
        back_populates="report_record",
    )

    creator = relationship(
        "User",
        foreign_keys=[created_by],
    )


# ============================================================
# RADIOLOGY APPOINTMENT
# ============================================================

class RadiologyAppointment(Base):
    __tablename__ = "radiology_appointments"

    id = Column(
        Integer,
        primary_key=True,
        index=True,
    )

    radiology_request_id = Column(
        Integer,
        ForeignKey("radiology_requests.id"),
        nullable=False,
        index=True,
    )

    patient_id = Column(
        Integer,
        ForeignKey("patients.id"),
        nullable=False,
        index=True,
    )

    appointment_date = Column(
        DateTime,
        nullable=False,
    )

    room = Column(
        String(100),
        nullable=True,
    )

    machine = Column(
        String(255),
        nullable=True,
    )

    status = Column(
        String(50),
        nullable=False,
        default="مجدول",
    )

    notes = Column(
        Text,
        nullable=True,
    )

    radiology_request = relationship(
        "RadiologyRequest",
        back_populates="scheduled_appointment",
    )

    patient = relationship(
        "Patient",
        foreign_keys=[patient_id],
    )