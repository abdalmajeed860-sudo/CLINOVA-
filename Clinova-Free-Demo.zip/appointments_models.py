"""Doctors and appointments; included in fresh database creation."""
from sqlalchemy import Column, ForeignKey, Integer, String, Text
from database import Base


class Doctor(Base):
    __tablename__ = "doctors"
    id = Column(Integer, primary_key=True)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), index=True, nullable=True)
    full_name = Column(String(200), nullable=False)
    specialization = Column(String(200))
    phone = Column(String(100))
    address = Column(String(500))
    notes = Column(Text)
    created_at = Column(String(100))


class Appointment(Base):
    __tablename__ = "appointments"
    id = Column(Integer, primary_key=True)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), index=True, nullable=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False, index=True)
    doctor_id = Column(Integer, ForeignKey("doctors.id"), nullable=True, index=True)
    appointment_date = Column(String(30), nullable=False)
    appointment_time = Column(String(20), nullable=False)
    status = Column(String(60), default="مجدول")
    reason = Column(Text)
    notes = Column(Text)
    created_at = Column(String(100))
