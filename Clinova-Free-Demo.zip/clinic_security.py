"""Request ownership and explicit tenant bindings for legacy SQL pages."""
from contextvars import ContextVar
from fastapi import Depends, HTTPException, Request
from sqlalchemy import event, select, text as sql_text
from sqlalchemy.orm import Session, with_loader_criteria

active_clinic = ContextVar("clinova_active_clinic", default=None)


def clinic_id():
    value = active_clinic.get()
    if not value:
        raise HTTPException(403, "الحساب غير مرتبط بمنشأة طبية فعالة")
    return value


def tenant_text(statement):
    """Bind only queries whose source code already declares an ownership filter."""
    clause = sql_text(statement)
    if ":active_clinic_id" in statement:
        clause = clause.bindparams(active_clinic_id=clinic_id())
    return clause


def section_guard(section):
    async def guard(request: Request):
        from auth import get_current_user, has_permission
        from database import SessionLocal
        with SessionLocal() as db:
            user = get_current_user(request, db)
            if not user or not user.clinic_id:
                raise HTTPException(403, "يرجى تسجيل الدخول بحساب مرتبط بمنشأة")
            path = request.url.path
            action = path.rsplit("/", 1)[-1]
            if section == "radiology":
                level = "request" if path.endswith("/new") else ("full" if request.method != "GET" or action in {"appointment", "report"} else "view")
            elif section == "laboratory":
                manage = ("/tests/" in path and (action in {"add", "edit", "toggle"})) or "/results" in path
                level = "full" if manage else ("request" if request.method != "GET" or "/new-order" in path else "view")
            else:
                manage = request.method != "GET" or any(word in path for word in ("/new", "/edit/", "/delete/"))
                level = "full" if manage else "view"
            if not has_permission(request, db, section, level):
                raise HTTPException(403, "ليس لديك صلاحية لهذا الإجراء")
            values = dict(request.path_params)
            if request.method == "POST":
                form = await request.form()
                for key in ("patient_id", "doctor_id", "visit_id"):
                    if form.get(key): values[key] = form[key]
            from models import Patient, Visit, Pregnancy
            from appointments_models import Doctor, Appointment
            from laboratory_models import LaboratoryOrder, LaboratoryTest
            from radiology_models import RadiologyRequest
            lookup = {"patient_id": Patient, "doctor_id": Doctor, "appointment_id": Appointment,
                      "visit_id": Visit, "pregnancy_id": Pregnancy, "request_id": RadiologyRequest,
                      "order_id": LaboratoryOrder, "test_id": LaboratoryTest}
            records = {}
            for key, entity in lookup.items():
                value = values.get(key)
                if value in (None, ""): continue
                try: value = int(value)
                except (TypeError, ValueError): raise HTTPException(400, "معرّف السجل غير صالح")
                columns = [entity.id]
                columns.append(entity.patient_id if hasattr(entity, "patient_id") else entity.clinic_id)
                record = db.query(*columns).filter(entity.id == value).first()
                if not record:
                    raise HTTPException(404, "السجل غير موجود في المنشأة الحالية")
                if entity is Patient: owned = record.clinic_id == user.clinic_id
                elif hasattr(entity, "patient_id"):
                    owned = db.query(Patient.id).filter_by(id=record.patient_id, clinic_id=user.clinic_id).first() is not None
                else: owned = record.clinic_id == user.clinic_id
                if not owned: raise HTTPException(404, "السجل غير موجود في المنشأة الحالية")
                records[key] = record
            if "visit_id" in records and "patient_id" in records and records["visit_id"].patient_id != records["patient_id"].id:
                raise HTTPException(400, "الزيارة لا تتبع المريض المختار")
    return Depends(guard)


async def patient_access(request: Request):
    section = "visits" if any(part in request.url.path for part in ("/visits", "/prescriptions")) else "patients"
    await section_guard(section).dependency(request)


def protect_referenced_record(db, references, record_id):
    """Reject deletion of a referenced clinical or financial record."""
    from sqlalchemy import inspect
    inspector = inspect(db.get_bind())
    for table, column in references:
        if not inspector.has_table(table): continue
        if column not in {item["name"] for item in inspector.get_columns(table)}: continue
        if db.execute(sql_text(f'SELECT 1 FROM "{table}" WHERE "{column}"=:id LIMIT 1'), {"id": record_id}).first():
            raise HTTPException(409, "لا يمكن حذف السجل لوجود بيانات طبية أو مالية مرتبطة به؛ احتفظ بالسجل وسجله التاريخي")


_installed = False


def install_orm_scope():
    """Scope ORM queries and lazy relationships; raw SQL has explicit filters.

    Jobs and migrations outside a request retain normal database access.
    """
    global _installed
    if _installed: return
    _installed = True

    @event.listens_for(Session, "do_orm_execute")
    def scope_queries(state):
        tenant = active_clinic.get()
        if not tenant or not state.is_select: return
        from models import Patient, Visit, Prescription, PrescriptionItem, Pregnancy, PregnancyFollowUp, FamilyPlanning
        from appointments_models import Doctor, Appointment
        from laboratory_models import LaboratoryTest, LaboratoryOrder, LaboratoryOrderItem
        from billing_models import Invoice
        from radiology_models import RadiologyRequest, RadiologyReport, RadiologyAppointment
        patients = select(Patient.__table__.c.id).where(Patient.__table__.c.clinic_id == tenant)
        pregnancies = select(Pregnancy.__table__.c.id).where(Pregnancy.__table__.c.patient_id.in_(patients))
        prescriptions = select(Prescription.__table__.c.id).where(Prescription.__table__.c.patient_id.in_(patients))
        orders = select(LaboratoryOrder.__table__.c.id).where(LaboratoryOrder.__table__.c.patient_id.in_(patients))
        radiology = select(RadiologyRequest.__table__.c.id).where(RadiologyRequest.__table__.c.patient_id.in_(patients))
        filters = [(Patient, Patient.clinic_id == tenant), (Doctor, Doctor.clinic_id == tenant),
                   (LaboratoryTest, LaboratoryTest.clinic_id == tenant)]
        for entity in (Visit, Prescription, Pregnancy, FamilyPlanning, Invoice, Appointment, LaboratoryOrder, RadiologyRequest):
            filters.append((entity, entity.patient_id.in_(patients)))
        filters += [(PrescriptionItem, PrescriptionItem.prescription_id.in_(prescriptions)),
                    (PregnancyFollowUp, PregnancyFollowUp.pregnancy_id.in_(pregnancies)),
                    (LaboratoryOrderItem, LaboratoryOrderItem.order_id.in_(orders)),
                    (RadiologyReport, RadiologyReport.radiology_request_id.in_(radiology)),
                    (RadiologyAppointment, RadiologyAppointment.radiology_request_id.in_(radiology))]
        state.statement = state.statement.options(*[
            with_loader_criteria(entity, condition, include_aliases=True) for entity, condition in filters])

    @event.listens_for(Session, "before_flush")
    def assign_owner(session, *_):
        tenant = active_clinic.get()
        if not tenant: return
        for row in session.new:
            if hasattr(row, "clinic_id"):
                if row.clinic_id is None: row.clinic_id = tenant
                elif row.clinic_id != tenant: raise HTTPException(403, "لا يمكن حفظ بيانات في منشأة أخرى")
