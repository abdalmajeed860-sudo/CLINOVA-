from input_validation import required_name, nonnegative_price
from clinic_security import section_guard
# ============================================================

# CLINOVA

# نظام إدارة العيادات الذكي والمتكامل

# laboratory.py

# ============================================================



import datetime

from html import escape

from urllib.parse import quote



from fastapi import APIRouter, Form, Request

from fastapi.responses import HTMLResponse, RedirectResponse

from sqlalchemy import or_



from database import SessionLocal

from auth import has_permission



from models import (

    Patient,

    Visit,

)



from laboratory_models import (

    LaboratoryTest,

    LaboratoryOrder,

    LaboratoryOrderItem,

)





# ============================================================

# Router

# ============================================================



router = APIRouter(dependencies=[section_guard("laboratory")])





# ============================================================

# قاعدة البيانات

# ============================================================



def get_db():

    return SessionLocal()





# ============================================================

# أدوات مساعدة

# ============================================================



def safe(value):

    if value is None:

        return ""



    return escape(str(value))





def now():

    return datetime.datetime.now().strftime(

        "%Y-%m-%d %H:%M:%S"

    )





def today():

    return datetime.datetime.now().strftime(

        "%Y-%m-%d"

    )





def generate_order_number(db):

    last_order = (

        db.query(LaboratoryOrder)

        .order_by(LaboratoryOrder.id.desc())

        .first()

    )



    if not last_order:

        number = 1

    else:

        number = last_order.id + 1



    return f"LAB-{number:06d}"





def status_badge(status):

    status = status or "جديد"



    if status == "مكتمل":

        cls = "badge-green"



    elif status == "نتيجة حرجة":

        cls = "badge-red"



    elif status == "قيد العمل":

        cls = "badge-orange"



    else:

        cls = "badge-blue"



    return (

        f'<span class="badge {cls}">'

        f'{safe(status)}'

        f'</span>'

    )





def result_status_badge(status):

    status = status or "لم تظهر"



    if status == "طبيعي":

        cls = "badge-green"



    elif status == "غير طبيعي":

        cls = "badge-orange"



    elif status == "نتيجة حرجة":

        cls = "badge-red"



    else:

        cls = "badge-blue"



    return (

        f'<span class="badge {cls}">'

        f'{safe(status)}'

        f'</span>'

    )





# ============================================================

# HTML الأساسي

# ============================================================



def page_start(title):

    return f"""

<!DOCTYPE html>

<html lang="ar" dir="rtl">



<head>



<meta charset="UTF-8">



<meta

    name="viewport"

    content="width=device-width, initial-scale=1.0"

>



<title>

    {safe(title)} - CLINOVA

</title>



<style>



* {{

    box-sizing: border-box;

}}



body {{

    margin: 0;

    font-family:

        Tahoma,

        Arial,

        sans-serif;



    background: #f5f7fb;

    color: #1f2937;

}}



a {{

    text-decoration: none;

}}



.topbar {{

    background:

        linear-gradient(

            135deg,

            #0f766e,

            #0e7490

        );



    color: white;

    padding: 18px 30px;



    display: flex;

    justify-content: space-between;

    align-items: center;



    gap: 20px;



    box-shadow:

        0 4px 15px

        rgba(0, 0, 0, 0.08);

}}



.brand {{

    display: flex;

    align-items: center;

    gap: 12px;

}}



.logo {{

    width: 48px;

    height: 48px;



    border-radius: 14px;



    background: rgba(

        255,

        255,

        255,

        0.14

    );



    display: flex;

    align-items: center;

    justify-content: center;



    font-size: 27px;

}}



.brand-name {{

    font-size: 23px;

    font-weight: bold;

}}



.brand-sub {{

    font-size: 12px;

    opacity: 0.85;

    margin-top: 3px;

}}



.top-actions {{

    display: flex;

    gap: 8px;

    flex-wrap: wrap;

}}



.top-btn {{

    color: white;



    background:

        rgba(

            255,

            255,

            255,

            0.12

        );



    border:

        1px solid

        rgba(

            255,

            255,

            255,

            0.18

        );



    padding: 9px 13px;



    border-radius: 9px;



    font-size: 13px;

}}



.top-btn:hover {{

    background:

        rgba(

            255,

            255,

            255,

            0.22

        );

}}



.container {{

    width: 94%;

    max-width: 1400px;



    margin: 30px auto;

}}



.page-header {{

    display: flex;

    justify-content: space-between;

    align-items: center;



    gap: 15px;



    flex-wrap: wrap;



    margin-bottom: 22px;

}}



.page-title {{

    margin: 0;



    color: #0f766e;



    font-size: 28px;

}}



.page-subtitle {{

    color: #64748b;

    margin-top: 7px;

    font-size: 14px;

}}



.card {{

    background: white;



    border-radius: 16px;



    padding: 22px;



    margin-bottom: 22px;



    box-shadow:

        0 5px 20px

        rgba(

            15,

            23,

            42,

            0.055

        );



    border:

        1px solid

        #e8edf3;

}}



.card-title {{

    margin: 0 0 18px;



    color: #0f766e;



    font-size: 20px;

}}



.stats {{

    display: grid;



    grid-template-columns:

        repeat(

            4,

            minmax(0, 1fr)

        );



    gap: 16px;



    margin-bottom: 22px;

}}



.stat {{

    background: white;



    border-radius: 15px;



    padding: 20px;



    border:

        1px solid

        #e8edf3;



    box-shadow:

        0 5px 18px

        rgba(

            15,

            23,

            42,

            0.04

        );

}}



.stat-label {{

    color: #64748b;

    font-size: 13px;

}}



.stat-value {{

    font-size: 30px;



    font-weight: bold;



    color: #0f766e;



    margin-top: 7px;

}}



.search {{

    display: flex;



    gap: 10px;



    flex-wrap: wrap;

}}



.search input {{

    flex: 1;



    min-width: 230px;

}}



input,

select,

textarea {{

    width: 100%;



    padding: 11px 12px;



    border:

        1px solid

        #d7dee8;



    border-radius: 9px;



    font-family: inherit;



    font-size: 14px;



    background: white;



    outline: none;

}}



input:focus,

select:focus,

textarea:focus {{

    border-color: #0f766e;



    box-shadow:

        0 0 0 3px

        rgba(

            15,

            118,

            110,

            0.08

        );

}}



textarea {{

    min-height: 100px;

    resize: vertical;

}}



label {{

    display: block;



    margin-bottom: 7px;



    font-weight: bold;



    color: #475569;

}}



.form-grid {{

    display: grid;



    grid-template-columns:

        repeat(

            2,

            minmax(0, 1fr)

        );



    gap: 16px;

}}



.full {{

    grid-column: 1 / -1;

}}



.field {{

    min-width: 0;

}}



button,

.btn {{

    display: inline-block;



    border: none;



    border-radius: 9px;



    padding: 11px 17px;



    cursor: pointer;



    font-family: inherit;



    font-size: 14px;



    text-decoration: none;



    background: #0f766e;



    color: white;

}}



button:hover,

.btn:hover {{

    opacity: 0.9;

}}



.btn-secondary {{

    background: #64748b;

}}



.btn-info {{

    background: #0e7490;

}}



.btn-success {{

    background: #15803d;

}}



.btn-warning {{

    background: #d97706;

}}



.btn-danger {{

    background: #dc2626;

}}



.btn-dark {{

    background: #334155;

}}



.actions {{

    display: flex;



    gap: 8px;



    flex-wrap: wrap;



    justify-content: center;

}}



table {{

    width: 100%;



    border-collapse: collapse;

}}



th {{

    background: #0f766e;



    color: white;



    padding: 12px;



    font-size: 13px;

}}



td {{

    padding: 11px;



    border-bottom:

        1px solid

        #edf0f4;



    text-align: center;



    font-size: 13px;

}}



tr:hover {{

    background: #f8fafc;

}}



.badge {{

    display: inline-block;



    padding: 5px 10px;



    border-radius: 20px;



    font-size: 12px;



    font-weight: bold;



    background: #e2e8f0;



    color: #475569;

}}



.badge-green {{

    background: #dcfce7;

    color: #166534;

}}



.badge-red {{

    background: #fee2e2;

    color: #991b1b;

}}



.badge-orange {{

    background: #ffedd5;

    color: #9a3412;

}}



.badge-blue {{

    background: #dbeafe;

    color: #1e40af;

}}



.notice {{

    padding: 14px 17px;



    border-radius: 10px;



    margin-bottom: 18px;



    background: #ecfeff;



    color: #155e75;



    border:

        1px solid

        #a5f3fc;

}}



.error {{

    padding: 14px 17px;



    border-radius: 10px;



    margin-bottom: 18px;



    background: #fef2f2;



    color: #991b1b;



    border:

        1px solid

        #fecaca;

}}



.patient-header {{

    display: flex;



    justify-content:

        space-between;



    align-items: center;



    gap: 20px;



    flex-wrap: wrap;

}}



.patient-name {{

    font-size: 25px;



    font-weight: bold;



    color: #0f766e;

}}



.info-grid {{

    display: grid;



    grid-template-columns:

        repeat(

            4,

            minmax(0, 1fr)

        );



    gap: 12px;



    margin-top: 18px;

}}



.info {{

    background: #f8fafc;



    border-radius: 10px;



    padding: 14px;

}}



.info strong {{

    display: block;



    color: #64748b;



    font-size: 12px;



    margin-bottom: 5px;

}}



.test-row {{

    display: grid;



    grid-template-columns:

        1fr 120px;



    gap: 10px;



    margin-bottom: 10px;



    align-items: center;

}}



.test-row .remove {{

    background: #dc2626;

}}



.section-title {{

    border-right:

        5px solid

        #0f766e;



    padding-right: 10px;



    margin:

        25px 0

        17px;

}}



.empty {{

    text-align: center;



    padding: 35px;



    color: #94a3b8;

}}



.report-header {{

    text-align: center;



    border-bottom:

        2px solid

        #0f766e;



    padding-bottom: 20px;



    margin-bottom: 20px;

}}



.report-title {{

    font-size: 27px;



    color: #0f766e;



    font-weight: bold;

}}



.report-subtitle {{

    margin-top: 7px;



    color: #64748b;

}}



.signature-grid {{

    display: grid;



    grid-template-columns:

        repeat(

            2,

            1fr

        );



    gap: 50px;



    margin-top: 70px;



    text-align: center;

}}



.signature {{

    border-top:

        1px solid

        #94a3b8;



    padding-top: 10px;

}}



@media (max-width: 1000px) {{



    .stats {{

        grid-template-columns:

            repeat(

                2,

                1fr

            );

    }}



    .info-grid {{

        grid-template-columns:

            repeat(

                2,

                1fr

            );

    }}

}}



@media (max-width: 700px) {{



    .container {{

        width: 96%;

        margin-top: 20px;

    }}



    .topbar {{

        padding: 15px;

    }}



    .top-actions {{

        display: none;

    }}



    .form-grid {{

        grid-template-columns: 1fr;

    }}



    .full {{

        grid-column: auto;

    }}



    .stats {{

        grid-template-columns: 1fr;

    }}



    .info-grid {{

        grid-template-columns: 1fr;

    }}



    table {{

        display: block;

        overflow-x: auto;

    }}



    th,

    td {{

        white-space: nowrap;

    }}



    .test-row {{

        grid-template-columns: 1fr;

    }}

}}



@media print {{



    .topbar,

    .no-print,

    .btn,

    button {{

        display: none !important;

    }}



    body {{

        background: white;

    }}



    .container {{

        width: 100%;

        max-width: none;

        margin: 0;

    }}



    .card {{

        box-shadow: none;

        border: none;

    }}

}}



</style>



</head>



<body>



<div class="topbar">



    <div class="brand">



        <div class="logo">

            ✚

        </div>



        <div>

            <div class="brand-name">

                CLINOVA

            </div>



            <div class="brand-sub">

                نظام إدارة العيادات الذكي والمتكامل

            </div>

        </div>



    </div>



    <div class="top-actions">



        <a

            href="/"

            class="top-btn"

        >

            🏠 الرئيسية

        </a>



        <a

            href="/patients"

            class="top-btn"

        >

            👥 المرضى

        </a>



        <a

            href="/laboratory"

            class="top-btn"

        >

            🧪 المختبر

        </a>



        <a

            href="/appointments"

            class="top-btn"

        >

            📅 المواعيد

        </a>



    </div>



</div>



<div class="container">



"""





def page_end():

    return """



</div>



</body>

</html>

"""





def permission_denied():
    return HTMLResponse(
        page_start("غير مصرح")
        + """
<div class="card">
    <div class="error">
        ليس لديك صلاحية لتنفيذ هذه العملية.
    </div>
    <a href="/laboratory" class="btn btn-secondary">
        ↩ العودة إلى المختبر
    </a>
</div>
"""
        + page_end(),
        status_code=403,
    )


# ============================================================

# لوحة المختبر

# ============================================================



@router.get(

    "/laboratory",

    response_class=HTMLResponse

)

def laboratory_dashboard(

    
    request: Request,
search: str = ""

):



    db = get_db()

    if not has_permission(request, db, "laboratory", "view"):
        return permission_denied()



    try:



        search = (search or "").strip()



        active_tests = (

            db.query(LaboratoryTest)

            .filter(

                LaboratoryTest.is_active == 1

            )

            .count()

        )



        total_orders = (

            db.query(LaboratoryOrder)

            .count()

        )



        completed_orders = (

            db.query(LaboratoryOrder)

            .filter(

                LaboratoryOrder.status == "مكتمل"

            )

            .count()

        )



        pending_orders = (

            db.query(LaboratoryOrder)

            .filter(

                LaboratoryOrder.status.in_(

                    [

                        "جديد",

                        "قيد العمل",

                        "نتيجة حرجة"

                    ]

                )

            )

            .count()

        )



        query = (

            db.query(LaboratoryOrder)

            .join(

                Patient,

                LaboratoryOrder.patient_id == Patient.id

            )

        )



        if search:



            term = f"%{search}%"



            query = query.filter(

                or_(

                    Patient.full_name.ilike(term),

                    Patient.medical_number.ilike(term),

                    Patient.file_number.ilike(term),

                    Patient.phone.ilike(term),

                    LaboratoryOrder.order_number.ilike(term)

                )

            )



        orders = (

            query

            .order_by(

                LaboratoryOrder.id.desc()

            )

            .limit(100)

            .all()

        )



        rows = ""



        for order in orders:



            patient_name = (

                order.patient.full_name

                if order.patient

                else "غير معروف"

            )



            doctor = (

                order.doctor_name

                or "-"

            )



            test_count = len(

                order.items

                or []

            )



            rows += f"""

<tr>



<td>

    <strong>

        {safe(order.order_number)}

    </strong>

</td>



<td>

    {safe(patient_name)}

</td>



<td>

    {safe(order.order_date)}

</td>



<td>

    {safe(doctor)}

</td>



<td>

    {test_count}

</td>



<td>

    {status_badge(order.status)}

</td>



<td>



<div class="actions">



<a

    class="btn btn-info"

    href="/laboratory/order/{order.id}"

>

    عرض

</a>



<a

    class="btn btn-warning"

    href="/laboratory/order/{order.id}/results"

>

    النتائج

</a>



<a

    class="btn btn-success"

    href="/laboratory/order/{order.id}/report"

>

    التقرير

</a>



</div>



</td>



</tr>

"""



        if not rows:



            rows = """

<tr>

    <td colspan="7">

        <div class="empty">

            لا توجد طلبات مخبرية.

        </div>

    </td>

</tr>

"""



        html = page_start(

            "المختبر"

        )



        html += f"""



<div class="page-header">



    <div>



        <h1 class="page-title">

            🧪 المختبر

        </h1>



        <div class="page-subtitle">

            إدارة التحاليل والطلبات والنتائج والتقارير المخبرية

        </div>



    </div>



    <div class="actions">



        <a

            href="/laboratory/new-order"

            class="btn btn-success"

        >

            ➕ طلب مخبري جديد

        </a>



        <a

            href="/laboratory/tests"

            class="btn btn-info"

        >

            🧪 إدارة التحاليل

        </a>



    </div>



</div>



<div class="stats">



    <div class="stat">



        <div class="stat-label">

            التحاليل النشطة

        </div>



        <div class="stat-value">

            {active_tests}

        </div>



    </div>



    <div class="stat">



        <div class="stat-label">

            إجمالي الطلبات

        </div>



        <div class="stat-value">

            {total_orders}

        </div>



    </div>



    <div class="stat">



        <div class="stat-label">

            الطلبات المكتملة

        </div>



        <div class="stat-value">

            {completed_orders}

        </div>



    </div>



    <div class="stat">



        <div class="stat-label">

            الطلبات قيد المتابعة

        </div>



        <div class="stat-value">

            {pending_orders}

        </div>



    </div>



</div>



<div class="card">



    <form

        method="get"

        action="/laboratory"

        class="search"

    >



        <input

            name="search"

            value="{safe(search)}"

            placeholder="ابحث باسم المريض أو رقم الملف أو رقم الطلب..."

        >



        <button type="submit">

            🔎 بحث

        </button>



        <a

            href="/laboratory"

            class="btn btn-secondary"

        >

            إعادة ضبط

        </a>



    </form>



</div>



<div class="card">



    <h2 class="card-title">

        📋 الطلبات المخبرية

    </h2>



    <div style="overflow-x:auto;">



    <table>



        <thead>



            <tr>



                <th>

                    رقم الطلب

                </th>



                <th>

                    المريض

                </th>



                <th>

                    التاريخ

                </th>



                <th>

                    الطبيب

                </th>



                <th>

                    التحاليل

                </th>



                <th>

                    الحالة

                </th>



                <th>

                    الإجراءات

                </th>



            </tr>



        </thead>



        <tbody>



            {rows}



        </tbody>



    </table>



    </div>



</div>



"""



        html += page_end()



        return HTMLResponse(

            html

        )



    finally:



        db.close()





# ============================================================

# إدارة التحاليل

# ============================================================



@router.get(

    "/laboratory/tests",

    response_class=HTMLResponse

)

def laboratory_tests(

    
    request: Request,
search: str = ""

):



    db = get_db()

    if not has_permission(request, db, "laboratory", "view"):
        return permission_denied()



    try:



        search = (search or "").strip()



        query = db.query(

            LaboratoryTest

        )



        if search:



            term = f"%{search}%"



            query = query.filter(

                or_(

                    LaboratoryTest.name.ilike(term),

                    LaboratoryTest.category.ilike(term)

                )

            )



        tests = (

            query

            .order_by(

                LaboratoryTest.category,

                LaboratoryTest.name

            )

            .all()

        )



        rows = ""



        for test in tests:



            active = (

                '<span class="badge badge-green">'

                'فعال'

                '</span>'

                if test.is_active

                else

                '<span class="badge badge-red">'

                'متوقف'

                '</span>'

            )



            toggle_text = (

                "إيقاف"

                if test.is_active

                else

                "تفعيل"

            )



            toggle_class = (

                "btn-danger"

                if test.is_active

                else

                "btn-success"

            )



            rows += f"""

<tr>



<td>

    {test.id}

</td>



<td>

    <strong>

        {safe(test.name)}

    </strong>

</td>



<td>

    {safe(test.category)}

</td>



<td>

    {safe(test.unit)}

</td>



<td>

    {safe(test.normal_range)}

</td>



<td>

    {test.price or 0:g}

</td>



<td>

    {active}

</td>



<td>



<div class="actions">



<a

    href="/laboratory/tests/{test.id}/edit"

    class="btn btn-info"

>

    ✏️ تعديل

</a>



<form method="post" action="/laboratory/tests/{test.id}/toggle" style="display:inline" onsubmit="return confirm('هل تريد تأكيد هذا الإجراء؟')"><button type="submit" class="btn {toggle_class}">

    {toggle_text}

</button></form>



</div>



</td>



</tr>

"""



        if not rows:



            rows = """

<tr>

    <td colspan="8">

        <div class="empty">

            لا توجد تحاليل.

        </div>

    </td>

</tr>

"""



        html = page_start(

            "إدارة التحاليل"

        )



        html += f"""



<div class="page-header">



    <div>



        <h1 class="page-title">

            🧪 إدارة التحاليل

        </h1>



        <div class="page-subtitle">

            إضافة وتعديل وإدارة التحاليل المخبرية

        </div>



    </div>



    <div class="actions">



        <a

            href="/laboratory/tests/add"

            class="btn btn-success"

        >

            ➕ إضافة تحليل

        </a>



        <a

            href="/laboratory"

            class="btn btn-secondary"

        >

            ↩ المختبر

        </a>



    </div>



</div>



<div class="card">



<form

    method="get"

    action="/laboratory/tests"

    class="search"

>



<input

    name="search"

    value="{safe(search)}"

    placeholder="ابحث باسم التحليل أو التصنيف..."

>



<button type="submit">

    🔎 بحث

</button>



<a

    href="/laboratory/tests"

    class="btn btn-secondary"

>

    إعادة ضبط

</a>



</form>



</div>



<div class="card">



<div style="overflow-x:auto;">



<table>



<thead>



<tr>



<th>

    ID

</th>



<th>

    اسم التحليل

</th>



<th>

    التصنيف

</th>



<th>

    الوحدة

</th>



<th>

    المجال الطبيعي

</th>



<th>

    السعر

</th>



<th>

    الحالة

</th>



<th>

    الإجراءات

</th>



</tr>



</thead>



<tbody>



{rows}



</tbody>



</table>



</div>



</div>



"""



        html += page_end()



        return HTMLResponse(

            html

        )



    finally:



        db.close()





# ============================================================

# إضافة تحليل

# ============================================================



@router.get(

    "/laboratory/tests/add",

    response_class=HTMLResponse

)

def add_test_page(
    request: Request,
):



    permission_db = get_db()
    try:
        allowed = has_permission(request, permission_db, "laboratory", "full")
    finally:
        permission_db.close()

    if not allowed:
        return permission_denied()

    html = page_start(

        "إضافة تحليل"

    )



    html += """



<div class="page-header">



    <div>



        <h1 class="page-title">

            ➕ إضافة تحليل مخبري

        </h1>



    </div>



    <a

        href="/laboratory/tests"

        class="btn btn-secondary"

    >

        ↩ العودة

    </a>



</div>



<div class="card">



<form

    method="post"

    action="/laboratory/tests/add"

>



<div class="form-grid">



<div class="field">



<label>

    اسم التحليل *

</label>



<input

    name="name"

    required

>



</div>



<div class="field">



<label>

    التصنيف

</label>



<input

    name="category"

    value="عام"

>



</div>



<div class="field">



<label>

    الوحدة

</label>



<input

    name="unit"

>



</div>



<div class="field">



<label>

    المجال الطبيعي

</label>



<input

    name="normal_range"

>



</div>



<div class="field">



<label>

    السعر

</label>



<input

    type="number"

    step="0.01"

    name="price"

    value="0"

>



</div>



<div class="field full">



<label>

    الوصف

</label>



<textarea

    name="description"

></textarea>



</div>



</div>



<br>



<button type="submit">

    💾 حفظ التحليل

</button>



</form>



</div>



"""



    html += page_end()



    return HTMLResponse(

        html

    )





@router.post(

    "/laboratory/tests/add"

)

def add_test(

    
    request: Request,
name: str = Form(...),

    category: str = Form("عام"),

    unit: str = Form(""),

    normal_range: str = Form(""),

    price: float = Form(0),

    description: str = Form("")

):



    name = required_name(name, "اسم التحليل")
    price = nonnegative_price(price)

    db = get_db()

    if not has_permission(request, db, "laboratory", "full"):
        return permission_denied()



    try:



        name = name.strip()



        if not name:



            return HTMLResponse(

                "اسم التحليل مطلوب.",

                status_code=400

            )



        exists = (

            db.query(LaboratoryTest)

            .filter(

                LaboratoryTest.name == name

            )

            .first()

        )



        if exists:



            return HTMLResponse(

                "هذا التحليل موجود مسبقًا.",

                status_code=400

            )



        test = LaboratoryTest(

            name=name,

            category=category.strip() or "عام",

            unit=unit.strip(),

            normal_range=normal_range.strip(),

            price=price or 0,

            description=description.strip(),

            is_active=1,

            created_at=now()

        )



        db.add(test)



        db.commit()



        return RedirectResponse(

            "/laboratory/tests",

            status_code=303

        )



    finally:



        db.close()





# ============================================================

# تعديل تحليل

# ============================================================



@router.get(

    "/laboratory/tests/{test_id}/edit",

    response_class=HTMLResponse

)

def edit_test_page(

    
    request: Request,
test_id: int

):



    db = get_db()

    if not has_permission(request, db, "laboratory", "full"):
        return permission_denied()



    try:



        test = (

            db.query(LaboratoryTest)

            .filter(

                LaboratoryTest.id == test_id

            )

            .first()

        )



        if not test:



            return HTMLResponse(

                "التحليل غير موجود.",

                status_code=404

            )



        html = page_start(

            "تعديل التحليل"

        )



        html += f"""



<div class="page-header">



    <div>



        <h1 class="page-title">

            ✏️ تعديل التحليل

        </h1>



    </div>



    <a

        href="/laboratory/tests"

        class="btn btn-secondary"

    >

        ↩ العودة

    </a>



</div>



<div class="card">



<form

    method="post"

    action="/laboratory/tests/{test.id}/edit"

>



<div class="form-grid">



<div class="field">



<label>

    اسم التحليل *

</label>



<input

    name="name"

    value="{safe(test.name)}"

    required

>



</div>



<div class="field">



<label>

    التصنيف

</label>



<input

    name="category"

    value="{safe(test.category)}"

>



</div>



<div class="field">



<label>

    الوحدة

</label>



<input

    name="unit"

    value="{safe(test.unit)}"

>



</div>



<div class="field">



<label>

    المجال الطبيعي

</label>



<input

    name="normal_range"

    value="{safe(test.normal_range)}"

>



</div>



<div class="field">



<label>

    السعر

</label>



<input

    type="number"

    step="0.01"

    name="price"

    value="{test.price or 0}"

>



</div>



<div class="field full">



<label>

    الوصف

</label>



<textarea name="description">{safe(test.description)}</textarea>



</div>



</div>



<br>



<button type="submit">

    💾 حفظ التعديلات

</button>



</form>



</div>



"""



        html += page_end()



        return HTMLResponse(

            html

        )



    finally:



        db.close()





@router.post(

    "/laboratory/tests/{test_id}/edit"

)

def edit_test(

    
    request: Request,
test_id: int,

    name: str = Form(...),

    category: str = Form("عام"),

    unit: str = Form(""),

    normal_range: str = Form(""),

    price: float = Form(0),

    description: str = Form("")

):



    name = required_name(name, "اسم التحليل")
    price = nonnegative_price(price)

    db = get_db()

    if not has_permission(request, db, "laboratory", "full"):
        return permission_denied()



    try:



        test = (

            db.query(LaboratoryTest)

            .filter(

                LaboratoryTest.id == test_id

            )

            .first()

        )



        if not test:



            return HTMLResponse(

                "التحليل غير موجود.",

                status_code=404

            )



        test.name = name.strip()



        test.category = (

            category.strip()

            or "عام"

        )



        test.unit = unit.strip()



        test.normal_range = (

            normal_range.strip()

        )



        test.price = price or 0



        test.description = (

            description.strip()

        )



        db.commit()



        return RedirectResponse(

            "/laboratory/tests",

            status_code=303

        )



    finally:



        db.close()





# ============================================================

# تفعيل / إيقاف التحليل

# ============================================================



@router.post(

    "/laboratory/tests/{test_id}/toggle"

)

def toggle_test(

    
    request: Request,
test_id: int

):



    db = get_db()

    if not has_permission(request, db, "laboratory", "full"):
        return permission_denied()



    try:



        test = (

            db.query(LaboratoryTest)

            .filter(

                LaboratoryTest.id == test_id

            )

            .first()

        )



        if not test:



            return HTMLResponse(

                "التحليل غير موجود.",

                status_code=404

            )



        test.is_active = (

            0

            if test.is_active

            else 1

        )



        db.commit()



        return RedirectResponse(

            "/laboratory/tests",

            status_code=303

        )



    finally:



        db.close()





# ============================================================

# إنشاء طلب مخبري جديد

# ============================================================



@router.get(

    "/laboratory/new-order",

    response_class=HTMLResponse

)

def new_order_page(

    
    request: Request,
patient_id: int | None = None,

    search: str = ""

):



    db = get_db()

    if not has_permission(request, db, "laboratory", "request"):
        return permission_denied()



    try:



        search = (search or "").strip()



        patient_query = db.query(

            Patient

        )



        if search:



            term = f"%{search}%"



            patient_query = patient_query.filter(

                or_(

                    Patient.full_name.ilike(term),

                    Patient.medical_number.ilike(term),

                    Patient.file_number.ilike(term),

                    Patient.phone.ilike(term)

                )

            )



        patients = (

            patient_query

            .order_by(

                Patient.full_name

            )

            .limit(200)

            .all()

        )



        selected_patient = None



        if patient_id:



            selected_patient = (

                db.query(Patient)

                .filter(

                    Patient.id == patient_id

                )

                .first()

            )



        visits = []



        if selected_patient:



            visits = (

                db.query(Visit)

                .filter(

                    Visit.patient_id

                    == selected_patient.id

                )

                .order_by(

                    Visit.id.desc()

                )

                .limit(50)

                .all()

            )



        tests = (

            db.query(LaboratoryTest)

            .filter(

                LaboratoryTest.is_active == 1

            )

            .order_by(

                LaboratoryTest.category,

                LaboratoryTest.name

            )

            .all()

        )



        categories = {}



        for test in tests:



            category = (

                test.category

                or "عام"

            )



            categories.setdefault(

                category,

                []

            ).append(test)



        patient_options = """

<option value="">

    اختر المريض

</option>

"""



        for patient in patients:



            selected = (

                "selected"

                if selected_patient

                and patient.id

                == selected_patient.id

                else ""

            )



            patient_options += f"""

<option

    value="{patient.id}"

    {selected}

>

    {safe(patient.full_name)}

    -

    {safe(patient.medical_number)}

    -

    {safe(patient.file_number)}

</option>

"""



        visit_options = """

<option value="">

    بدون ربط بزيارة محددة

</option>

"""



        for visit in visits:



            doctor = (

                visit.doctor_name

                or ""

            )



            complaint = (

                visit.chief_complaint

                or ""

            )



            visit_options += f"""

<option

    value="{visit.id}"

    data-doctor="{safe(doctor)}"

>

    #{visit.id}

    -

    {safe(visit.visit_date)}

    -

    الطبيب:

    {safe(doctor or "-")}

    -

    {safe(complaint[:60])}

</option>

"""



        test_options = """

<option value="">

    اختر التحليل

</option>

"""



        for category, category_tests in categories.items():



            test_options += f"""

<optgroup

    label="{safe(category)}"

>

"""



            for test in category_tests:



                test_options += f"""

<option value="{test.id}">

    {safe(test.name)}

    {(

        " - "

        + safe(test.unit)

    ) if test.unit else ""}

</option>

"""



            test_options += """

</optgroup>

"""



        html = page_start(

            "طلب مخبري جديد"

        )



        html += f"""



<div class="page-header">



    <div>



        <h1 class="page-title">

            ➕ طلب مخبري جديد

        </h1>



        <div class="page-subtitle">

            اختر المريض ثم الزيارة ثم أضف تحليلًا أو عدة تحاليل

        </div>



    </div>



    <a

        href="/laboratory"

        class="btn btn-secondary"

    >

        ↩ المختبر

    </a>



</div>



<div class="card">



    <h2 class="card-title">

        👤 اختيار المريض

    </h2>



    <form

        method="get"

        action="/laboratory/order/create"

    >



        <div class="form-grid">



            <div class="field">



                <label>

                    البحث عن المريض

                </label>



                <input

                    name="search"

                    value="{safe(search)}"

                    placeholder="الاسم أو الرقم الطبي أو الهاتف..."

                >



            </div>



            <div

                class="field"

                style="align-self:end;"

            >



                <button type="submit">

                    🔎 البحث

                </button>



            </div>



        </div>



    </form>



    <br>



    <div class="field">



        <label>

            المريض *

        </label>



        <select

            id="patient_id"

            onchange="reloadPatient()"

        >



            {patient_options}



        </select>



    </div>



</div>

"""



        if not selected_patient:



            html += """

<div class="notice">

    اختر المريض أولًا حتى تظهر زياراته ويمكن إنشاء الطلب المخبري.

</div>

"""



        else:



            html += f"""



<div class="card">



<div class="patient-header">



    <div>



        <div class="patient-name">

            {safe(selected_patient.full_name)}

        </div>



        <div class="patient-info">

            المريض المحدد للطلب المخبري

        </div>



    </div>



    <a

        href="/patients/{selected_patient.id}"

        class="btn btn-info"

    >

        📁 ملف المريض

    </a>



</div>



<div class="info-grid">



<div class="info">



<strong>

    الرقم الطبي

</strong>



{safe(selected_patient.medical_number) or "-"}



</div>



<div class="info">



<strong>

    رقم الملف

</strong>



{safe(selected_patient.file_number) or "-"}



</div>



<div class="info">



<strong>

    الهاتف

</strong>



{safe(selected_patient.phone) or "-"}



</div>



<div class="info">



<strong>

    الجنس

</strong>



{safe(selected_patient.gender) or "-"}



</div>



</div>



</div>



<div class="card">



<h2 class="card-title">

    🧪 تفاصيل الطلب

</h2>



<form

    method="post"

    action="/laboratory/order/create"

>



<input

    type="hidden"

    name="patient_id"

    value="{selected_patient.id}"

>



<div class="form-grid">



<div class="field">



<label>

    زيارة المريض

</label>



<select

    name="visit_id"

    id="visit_id"

    onchange="setDoctor()"

>



    {visit_options}



</select>



</div>



<div class="field">



<label>

    الطبيب المحيل

</label>



<input

    name="doctor_name"

    id="doctor_name"

    placeholder="اسم الطبيب"

>



</div>



<div class="field full">



<label>

    الملاحظات السريرية

</label>



<textarea

    name="clinical_notes"

    placeholder="الأعراض أو المعلومات السريرية المهمة..."

></textarea>



</div>



</div>



<h3 class="section-title">

    🔬 التحاليل المطلوبة

</h3>



<div id="tests-container">



<div class="test-row">



<select

    name="test_ids"

    required

>

    {test_options}

</select>



<button

    type="button"

    class="remove"

    onclick="removeTest(this)"

>

    حذف

</button>



</div>



</div>



<div

    class="actions"

    style="justify-content:flex-start;"

>



<button

    type="button"

    class="btn-info"

    onclick="addTest()"

>

    ➕ إضافة تحليل آخر

</button>



</div>



<br>



<div class="notice">

    يمكنك إضافة عدة تحاليل في نفس الطلب، وسيتم منع تكرار التحليل تلقائيًا عند الحفظ.

</div>



<button

    type="submit"

    class="btn-success"

>

    💾 إنشاء الطلب المخبري

</button>



</form>



</div>



<script>



function reloadPatient() {{



    const patientId =

        document.getElementById(

            "patient_id"

        ).value;



    if (patientId) {{



        window.location.href =

            "/laboratory/new-order?patient_id="

            + patientId;

    }}

}}



function setDoctor() {{



    const select =

        document.getElementById(

            "visit_id"

        );



    if (!select) {{

        return;

    }}



    const option =

        select.options[

            select.selectedIndex

        ];



    if (!option) {{

        return;

    }}



    const doctor =

        option.getAttribute(

            "data-doctor"

        );



    if (doctor) {{



        document.getElementById(

            "doctor_name"

        ).value = doctor;

    }}

}}



function addTest() {{



    const container =

        document.getElementById(

            "tests-container"

        );



    const rows =

        container.querySelectorAll(

            ".test-row"

        );



    const first =

        rows[0];



    if (!first) {{

        return;

    }}



    const newRow =

        first.cloneNode(true);



    const select =

        newRow.querySelector(

            "select"

        );



    if (select) {{

        select.selectedIndex = 0;

    }}



    container.appendChild(

        newRow

    );

}}



function removeTest(button) {{



    const container =

        document.getElementById(

            "tests-container"

        );



    const rows =

        container.querySelectorAll(

            ".test-row"

        );



    if (rows.length > 1) {{



        button

            .parentElement

            .remove();



    }} else {{



        const select =

            button

                .parentElement

                .querySelector(

                    "select"

                );



        if (select) {{

            select.selectedIndex = 0;

        }}

    }}

}}



</script>



"""



        html += page_end()



        return HTMLResponse(

            html

        )



    finally:



        db.close()





# ============================================================

# إنشاء الطلب

# ============================================================



@router.post(

    "/laboratory/order/create"

)

def create_order(

    
    request: Request,
patient_id: int = Form(...),

    visit_id: int | None = Form(None),

    doctor_name: str = Form(""),

    clinical_notes: str = Form(""),

    test_ids: list[int] = Form(...)

):



    db = get_db()

    if not has_permission(request, db, "laboratory", "request"):
        return permission_denied()



    try:



        patient = (

            db.query(Patient)

            .filter(

                Patient.id == patient_id

            )

            .first()

        )



        if not patient:



            return HTMLResponse(

                "المريض غير موجود.",

                status_code=404

            )



        visit = None



        if visit_id:



            visit = (

                db.query(Visit)

                .filter(

                    Visit.id == visit_id,

                    Visit.patient_id == patient_id

                )

                .first()

            )



            if not visit:



                return HTMLResponse(

                    "الزيارة غير مرتبطة بهذا المريض.",

                    status_code=400

                )



            if visit.doctor_name:



                doctor_name = (

                    visit.doctor_name

                )



        # ----------------------------------------------------

        # إزالة التكرار

        # ----------------------------------------------------



        unique_ids = []



        for test_id in test_ids:



            if test_id not in unique_ids:



                unique_ids.append(

                    test_id

                )



        if not unique_ids:



            return HTMLResponse(

                "يجب اختيار تحليل واحد على الأقل.",

                status_code=400

            )



        # ----------------------------------------------------

        # جلب التحاليل

        # ----------------------------------------------------



        tests = (

            db.query(LaboratoryTest)

            .filter(

                LaboratoryTest.id.in_(

                    unique_ids

                ),

                LaboratoryTest.is_active == 1

            )

            .all()

        )



        test_map = {

            test.id: test

            for test in tests

        }



        if len(test_map) != len(unique_ids):



            return HTMLResponse(

                "لم يتم العثور على التحاليل المطلوبة.",

                status_code=400

            )



        # ----------------------------------------------------

        # إنشاء الطلب

        # ----------------------------------------------------



        order = LaboratoryOrder(

            order_number=generate_order_number(

                db

            ),

            patient_id=patient_id,

            visit_id=visit_id,

            doctor_name=(

                doctor_name.strip()

            ),

            order_date=now(),

            clinical_notes=(

                clinical_notes.strip()

            ),

            status="جديد",

            laboratory_notes="",

            created_at=now()

        )



        db.add(order)



        db.flush()



        # ----------------------------------------------------

        # إضافة التحاليل

        # ----------------------------------------------------



        for test_id in unique_ids:



            test = test_map.get(

                test_id

            )



            if not test:

                continue



            item = LaboratoryOrderItem(



                order_id=order.id,



                test_id=test.id,



                result="",



                unit=(

                    test.unit

                    or ""

                ),



                normal_range=(

                    test.normal_range

                    or ""

                ),



                result_status="لم تظهر",



                notes="",



                result_date=""

            )



            db.add(item)



        db.commit()



        return RedirectResponse(

            f"/laboratory/order/{order.id}",

            status_code=303

        )



    except Exception:



        db.rollback()



        raise



    finally:



        db.close()





# ============================================================

# تفاصيل الطلب

# ============================================================



@router.get(

    "/laboratory/order/{order_id}",

    response_class=HTMLResponse

)

def order_details(

    
    request: Request,
order_id: int

):



    db = get_db()

    if not has_permission(request, db, "laboratory", "view"):
        return permission_denied()



    try:



        order = (

            db.query(LaboratoryOrder)

            .filter(

                LaboratoryOrder.id == order_id

            )

            .first()

        )



        if not order:



            return HTMLResponse(

                "الطلب المخبري غير موجود.",

                status_code=404

            )



        patient = order.patient



        rows = ""



        for item in order.items:



            test_name = (

                item.test.name

                if item.test

                else "-"

            )



            rows += f"""

<tr>



<td>

    <strong>

        {safe(test_name)}

    </strong>

</td>



<td>

    {safe(item.result) or "-"}

</td>



<td>

    {safe(item.unit) or "-"}

</td>



<td>

    {safe(item.normal_range) or "-"}

</td>



<td>

    {result_status_badge(

        item.result_status

    )}

</td>



<td>

    {safe(item.notes) or "-"}

</td>



</tr>

"""



        if not rows:



            rows = """

<tr>

    <td colspan="6">

        لا توجد تحاليل ضمن هذا الطلب.

    </td>

</tr>

"""



        visit_text = "-"



        if order.visit:



            visit_text = (

                f"#{order.visit.id} - "

                f"{safe(order.visit.visit_date)}"

            )



        html = page_start(

            "تفاصيل الطلب المخبري"

        )



        html += f"""



<div class="page-header">



    <div>



        <h1 class="page-title">

            🧪 الطلب {safe(order.order_number)}

        </h1>



        <div class="page-subtitle">

            تفاصيل الطلب المخبري والنتائج

        </div>



    </div>



    <div class="actions no-print">



        <a

            href="/laboratory"

            class="btn btn-secondary"

        >

            ↩ المختبر

        </a>



        <a

            href="/laboratory/order/{order.id}/results"

            class="btn btn-warning"

        >

            📝 إدخال النتائج

        </a>



        <a

            href="/laboratory/order/{order.id}/report"

            class="btn btn-success"

        >

            📄 التقرير

        </a>



    </div>



</div>



<div class="card">



<div class="patient-header">



<div>



<div class="patient-name">

    {safe(

        patient.full_name

        if patient

        else "غير معروف"

    )}

</div>



<div class="page-subtitle">

    بيانات المريض المرتبط بالطلب

</div>



</div>



<a

    href="/laboratory/patient/{patient.id}"

    class="btn btn-info no-print"

>

    🧪 سجل مختبر المريض

</a>



</div>



<div class="info-grid">



<div class="info">



<strong>

    الرقم الطبي

</strong>



{safe(patient.medical_number) or "-"}



</div>



<div class="info">



<strong>

    رقم الملف

</strong>



{safe(patient.file_number) or "-"}



</div>



<div class="info">



<strong>

    الهاتف

</strong>



{safe(patient.phone) or "-"}



</div>



<div class="info">



<strong>

    الطبيب المحيل

</strong>



{safe(order.doctor_name) or "-"}



</div>



<div class="info">



<strong>

    تاريخ الطلب

</strong>



{safe(order.order_date)}



</div>



<div class="info">



<strong>

    الزيارة

</strong>



{visit_text}



</div>



<div class="info">



<strong>

    الحالة

</strong>



{status_badge(order.status)}



</div>



</div>



</div>



<div class="card">



<h2 class="card-title">

    🔬 التحاليل والنتائج

</h2>



<div style="overflow-x:auto;">



<table>



<thead>



<tr>



<th>

    التحليل

</th>



<th>

    النتيجة

</th>



<th>

    الوحدة

</th>



<th>

    المجال الطبيعي

</th>



<th>

    الحالة

</th>



<th>

    ملاحظات

</th>



</tr>



</thead>



<tbody>



{rows}



</tbody>



</table>



</div>



</div>



<div class="card">



<h2 class="card-title">

    📝 الملاحظات السريرية

</h2>



<div>

    {safe(order.clinical_notes) or "لا توجد ملاحظات"}

</div>



</div>



<div class="card">



<h2 class="card-title">

    🧪 ملاحظات المختبر

</h2>



<div>

    {safe(order.laboratory_notes) or "لا توجد ملاحظات"}

</div>



</div>



"""



        html += page_end()



        return HTMLResponse(

            html

        )



    finally:



        db.close()





# ============================================================

# إدخال النتائج

# ============================================================



@router.get(

    "/laboratory/order/{order_id}/results",

    response_class=HTMLResponse

)

def results_page(

    
    request: Request,
order_id: int

):



    db = get_db()

    if not has_permission(request, db, "laboratory", "view"):
        return permission_denied()



    try:



        order = (

            db.query(LaboratoryOrder)

            .filter(

                LaboratoryOrder.id == order_id

            )

            .first()

        )



        if not order:



            return HTMLResponse(

                "الطلب غير موجود.",

                status_code=404

            )



        rows = ""



        for item in order.items:



            status = (

                item.result_status

                or "لم تظهر"

            )



            rows += f"""

<tr>



<td>



<strong>

    {safe(

        item.test.name

        if item.test

        else "-"

    )}

</strong>



</td>



<td>



<input

    name="result_{item.id}"

    value="{safe(item.result)}"

>



</td>



<td>



<input

    name="unit_{item.id}"

    value="{safe(item.unit)}"

>



</td>



<td>



<input

    name="normal_{item.id}"

    value="{safe(item.normal_range)}"

>



</td>



<td>



<select

    name="status_{item.id}"

>



<option

    value="لم تظهر"

    {"selected" if status == "لم تظهر" else ""}

>

    لم تظهر

</option>



<option

    value="طبيعي"

    {"selected" if status == "طبيعي" else ""}

>

    طبيعي

</option>



<option

    value="غير طبيعي"

    {"selected" if status == "غير طبيعي" else ""}

>

    غير طبيعي

</option>



<option

    value="نتيجة حرجة"

    {"selected" if status == "نتيجة حرجة" else ""}

>

    نتيجة حرجة

</option>



</select>



</td>



<td>



<input

    name="notes_{item.id}"

    value="{safe(item.notes)}"

    placeholder="ملاحظات"

>



</td>



</tr>

"""



        html = page_start(

            "إدخال النتائج"

        )



        html += f"""



<div class="page-header">



<div>



<h1 class="page-title">

    📝 نتائج الطلب {safe(order.order_number)}

</h1>



<div class="page-subtitle">

    إدخال وتحديث نتائج التحاليل

</div>



</div>



<div class="actions no-print">



<a

    href="/laboratory/order/{order.id}"

    class="btn btn-secondary"

>

    ↩ تفاصيل الطلب

</a>



<a

    href="/laboratory/order/{order.id}/report"

    class="btn btn-info"

>

    📄 التقرير

</a>



</div>



</div>



<div class="card">



<div class="notice">



المريض:

<strong>

    {safe(

        order.patient.full_name

        if order.patient

        else "-"

    )}

</strong>



&nbsp; | &nbsp;



الطلب:

<strong>

    {safe(order.order_number)}

</strong>



</div>



<form

    method="post"

    action="/laboratory/order/{order.id}/results"

>



<div style="overflow-x:auto;">



<table>



<thead>



<tr>



<th>

    التحليل

</th>



<th>

    النتيجة

</th>



<th>

    الوحدة

</th>



<th>

    المجال الطبيعي

</th>



<th>

    حالة النتيجة

</th>



<th>

    ملاحظات

</th>



</tr>



</thead>



<tbody>



{rows}



</tbody>



</table>



</div>



<br>



<div class="field">



<label>

    ملاحظات المختبر

</label>



<textarea

    name="laboratory_notes"

    placeholder="الملاحظات العامة للمختبر..."

>{safe(order.laboratory_notes)}</textarea>



</div>



<br>



<button

    type="submit"

    class="btn-success"

>

    💾 حفظ النتائج

</button>



</form>



</div>



"""



        html += page_end()



        return HTMLResponse(

            html

        )



    finally:



        db.close()





# ============================================================

# حفظ النتائج

# ============================================================



@router.post(

    "/laboratory/order/{order_id}/results"

)

async def save_results(

    order_id: int,

    request: Request

):



    db = get_db()

    if not has_permission(request, db, "laboratory", "full"):
        return permission_denied()



    try:



        order = (

            db.query(LaboratoryOrder)

            .filter(

                LaboratoryOrder.id == order_id

            )

            .first()

        )



        if not order:



            return HTMLResponse(

                "الطلب غير موجود.",

                status_code=404

            )



        form = await request.form()



        has_results = False



        critical = False



        completed_count = 0



        # ----------------------------------------------------

        # حفظ كل نتيجة

        # ----------------------------------------------------



        for item in order.items:



            result = str(

                form.get(

                    f"result_{item.id}",

                    ""

                )

                or ""

            ).strip()



            unit = str(

                form.get(

                    f"unit_{item.id}",

                    ""

                )

                or ""

            ).strip()



            normal_range = str(

                form.get(

                    f"normal_{item.id}",

                    ""

                )

                or ""

            ).strip()



            result_status = str(

                form.get(

                    f"status_{item.id}",

                    "لم تظهر"

                )

                or "لم تظهر"

            ).strip()



            notes = str(

                form.get(

                    f"notes_{item.id}",

                    ""

                )

                or ""

            ).strip()



            item.result = result



            item.unit = unit



            item.normal_range = (

                normal_range

            )



            item.result_status = (

                result_status

            )



            item.notes = notes



            if result:



                has_results = True



                completed_count += 1



                item.result_date = now()



            else:



                item.result_date = ""



            if result_status == "نتيجة حرجة":



                critical = True



        # ----------------------------------------------------

        # الملاحظات العامة

        # ----------------------------------------------------



        order.laboratory_notes = str(

            form.get(

                "laboratory_notes",

                ""

            )

            or ""

        ).strip()



        # ----------------------------------------------------

        # تحديد حالة الطلب

        # ----------------------------------------------------



        total_items = len(

            order.items

        )



        if critical:



            order.status = (

                "نتيجة حرجة"

            )



        elif total_items > 0 and (

            completed_count

            == total_items

        ):



            order.status = (

                "مكتمل"

            )



        elif has_results:



            order.status = (

                "قيد العمل"

            )



        else:



            order.status = (

                "جديد"

            )



        db.commit()



        return RedirectResponse(

            f"/laboratory/order/{order.id}",

            status_code=303

        )



    except Exception:



        db.rollback()



        raise



    finally:



        db.close()





# ============================================================

# التقرير المخبري

# ============================================================



@router.get(

    "/laboratory/order/{order_id}/report",

    response_class=HTMLResponse

)

def laboratory_report(

    
    request: Request,
order_id: int

):



    db = get_db()

    if not has_permission(request, db, "laboratory", "view"):
        return permission_denied()



    try:



        order = (

            db.query(LaboratoryOrder)

            .filter(

                LaboratoryOrder.id == order_id

            )

            .first()

        )



        if not order:



            return HTMLResponse(

                "الطلب غير موجود.",

                status_code=404

            )



        patient = order.patient



        rows = ""



        for item in order.items:



            rows += f"""

<tr>



<td>

    {safe(

        item.test.name

        if item.test

        else "-"

    )}

</td>



<td>

    <strong>

        {safe(item.result) or "-"}

    </strong>

</td>



<td>

    {safe(item.unit) or "-"}

</td>



<td>

    {safe(item.normal_range) or "-"}

</td>



<td>

    {result_status_badge(

        item.result_status

    )}

</td>



</tr>

"""



        visit_text = "-"



        if order.visit:



            visit_text = (

                f"#{order.visit.id} - "

                f"{safe(order.visit.visit_date)}"

            )



        html = page_start(

            "التقرير المخبري"

        )



        html += f"""



<div class="no-print actions"

style="justify-content:flex-start;margin-bottom:20px;">



<a

    href="/laboratory/order/{order.id}"

    class="btn btn-secondary"

>

    ↩ العودة للطلب

</a>



<button

    onclick="window.print()"

    class="btn btn-success"

>

    🖨️ طباعة التقرير

</button>



</div>



<div class="card">



<div class="report-header">



<div class="report-title">

    CLINOVA

</div>



<div class="report-subtitle">

    نظام إدارة العيادات الذكي والمتكامل

</div>



<h1>

    التقرير المخبري

</h1>



<div>

    رقم الطلب:

    <strong>

        {safe(order.order_number)}

    </strong>

</div>



</div>



<div class="info-grid">



<div class="info">



<strong>

    اسم المريض

</strong>



{safe(

    patient.full_name

    if patient

    else "-"

)}



</div>



<div class="info">



<strong>

    الرقم الطبي

</strong>



{safe(

    patient.medical_number

    if patient

    else "-"

)}



</div>



<div class="info">



<strong>

    رقم الملف

</strong>



{safe(

    patient.file_number

    if patient

    else "-"

)}



</div>



<div class="info">



<strong>

    الهاتف

</strong>



{safe(

    patient.phone

    if patient

    else "-"

)}



</div>



<div class="info">



<strong>

    الطبيب المحيل

</strong>



{safe(order.doctor_name) or "-"}



</div>



<div class="info">



<strong>

    تاريخ الطلب

</strong>



{safe(order.order_date)}



</div>



<div class="info">



<strong>

    الزيارة

</strong>



{visit_text}



</div>



<div class="info">



<strong>

    حالة الطلب

</strong>



{status_badge(order.status)}



</div>



</div>



<h2 class="section-title">

    نتائج التحاليل

</h2>



<div style="overflow-x:auto;">



<table>



<thead>



<tr>



<th>

    التحليل

</th>



<th>

    النتيجة

</th>



<th>

    الوحدة

</th>



<th>

    المجال الطبيعي

</th>



<th>

    الحالة

</th>



</tr>



</thead>



<tbody>



{rows}



</tbody>



</table>



</div>



<div class="card">



<h3>

    الملاحظات السريرية

</h3>



<p>

    {safe(order.clinical_notes) or "لا توجد ملاحظات"}

</p>



</div>



<div class="card">



<h3>

    ملاحظات المختبر

</h3>



<p>

    {safe(order.laboratory_notes) or "لا توجد ملاحظات"}

</p>



</div>



<div class="signature-grid">



<div class="signature">

    اسم الطبيب / التوقيع

</div>



<div class="signature">

    مسؤول المختبر / التوقيع

</div>



</div>



</div>



"""



        html += page_end()



        return HTMLResponse(

            html

        )



    finally:



        db.close()





# ============================================================

# سجل مختبر المريض

# ============================================================



@router.get(

    "/laboratory/patient/{patient_id}",

    response_class=HTMLResponse

)

def patient_laboratory_history(

    
    request: Request,
patient_id: int

):



    db = get_db()

    if not has_permission(request, db, "laboratory", "view"):
        return permission_denied()



    try:



        patient = (

            db.query(Patient)

            .filter(

                Patient.id == patient_id

            )

            .first()

        )



        if not patient:



            return HTMLResponse(

                "المريض غير موجود.",

                status_code=404

            )



        orders = (

            db.query(LaboratoryOrder)

            .filter(

                LaboratoryOrder.patient_id

                == patient_id

            )

            .order_by(

                LaboratoryOrder.id.desc()

            )

            .all()

        )



        orders_html = ""



        for order in orders:



            items_html = ""



            for item in order.items:



                items_html += f"""

<tr>



<td>

    {safe(

        item.test.name

        if item.test

        else "-"

    )}

</td>



<td>

    {safe(item.result) or "-"}

</td>



<td>

    {safe(item.unit) or "-"}

</td>



<td>

    {result_status_badge(

        item.result_status

    )}

</td>



</tr>

"""



            if not items_html:



                items_html = """

<tr>

<td colspan="4">

    لا توجد تحاليل.

</td>

</tr>

"""



            orders_html += f"""



<div class="card">



<div class="patient-header">



<div>



<h2 class="card-title">

    🧪 {safe(order.order_number)}

</h2>



<div class="page-subtitle">



التاريخ:

{safe(order.order_date)}



&nbsp; | &nbsp;



الطبيب:

{safe(order.doctor_name) or "-"}



&nbsp; | &nbsp;



{status_badge(order.status)}



</div>



</div>



<div class="actions">



<a

    href="/laboratory/order/{order.id}"

    class="btn btn-info"

>

    عرض الطلب

</a>



<a

    href="/laboratory/order/{order.id}/results"

    class="btn btn-warning"

>

    النتائج

</a>



<a

    href="/laboratory/order/{order.id}/report"

    class="btn btn-success"

>

    التقرير

</a>



</div>



</div>



<br>



<div style="overflow-x:auto;">



<table>



<thead>



<tr>



<th>

    التحليل

</th>



<th>

    النتيجة

</th>



<th>

    الوحدة

</th>



<th>

    الحالة

</th>



</tr>



</thead>



<tbody>



{items_html}



</tbody>



</table>



</div>



</div>



"""



        if not orders_html:



            orders_html = """

<div class="card">



<div class="empty">

    لا توجد طلبات مخبرية لهذا المريض.

</div>



</div>

"""



        html = page_start(

            "السجل المخبري للمريض"

        )



        html += f"""



<div class="page-header">



<div>



<h1 class="page-title">

    🧪 السجل المخبري

</h1>



<div class="page-subtitle">

    جميع طلبات وتحاليل المريض

</div>



</div>



<div class="actions">



<a

    href="/patients/{patient.id}"

    class="btn btn-secondary"

>

    📁 ملف المريض

</a>



<a

    href="/laboratory/new-order?patient_id={patient.id}"

    class="btn btn-success"

>

    ➕ طلب مخبري جديد

</a>



</div>



</div>



<div class="card">



<div class="patient-name">

    {safe(patient.full_name)}

</div>



<div class="info-grid">



<div class="info">



<strong>

    الرقم الطبي

</strong>



{safe(patient.medical_number) or "-"}



</div>



<div class="info">



<strong>

    رقم الملف

</strong>



{safe(patient.file_number) or "-"}



</div>



<div class="info">



<strong>

    الهاتف

</strong>



{safe(patient.phone) or "-"}



</div>



<div class="info">



<strong>

    عدد الطلبات

</strong>



{len(orders)}



</div>



</div>



</div>



{orders_html}



"""



        html += page_end()



        return HTMLResponse(

            html

        )



    finally:



        db.close()





# ============================================================

# نهاية الملف

# ============================================================
