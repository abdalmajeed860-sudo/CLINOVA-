"""Persist a per-installation session signing secret, with an environment override."""
import os
import secrets
import hashlib
import hmac
from pathlib import Path


def session_secret():
    configured = os.environ.get("CLINOVA_SECRET_KEY")
    path = Path(__file__).parent / ".session_secret"
    if not configured:
        try:
            with path.open("x", encoding="ascii") as stream:
                stream.write(secrets.token_urlsafe(48))
        except FileExistsError:
            pass
    value = configured or path.read_text(encoding="ascii").strip()
    if len(value) < 32:
        raise RuntimeError("Session signing key is missing or invalid")
    # Preview and production databases must never accept each other's cookies,
    # even when served on different ports of the same computer.
    return hmac.new(value.encode("utf-8"), database_identity().encode("utf-8"), hashlib.sha256).hexdigest()


def database_identity():
    return str(Path(os.environ.get("CLINOVA_DATABASE_PATH", str(Path(__file__).parent / "clinic.db"))).resolve()).casefold()


def session_cookie_name():
    return "clinova_session_" + hashlib.sha256(database_identity().encode("utf-8")).hexdigest()[:12]
