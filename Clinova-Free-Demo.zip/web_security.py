"""Request protections shared by every clinic section."""
import os
import re
import secrets
import time
from collections import OrderedDict, deque
from html import escape
from urllib.parse import urlsplit

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import HTMLResponse, Response

UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}
FORM = re.compile(r"<form\b[^>]*>", re.I)


class WebSecurityMiddleware(BaseHTTPMiddleware):
    def __init__(self, app):
        super().__init__(app)
        self.login_attempts = OrderedDict()

    async def dispatch(self, request, call_next):
        path = request.url.path
        production = os.getenv("CLINOVA_PRODUCTION") == "1"
        allowed = {"clinova-demo.onrender.com"} if production else {"localhost", "127.0.0.1", "testserver"}
        allowed.update(x.strip() for x in os.getenv("CLINOVA_ALLOWED_HOSTS", "").split(",") if x.strip())
        if request.url.hostname not in allowed:
            return self.protect(HTMLResponse("Invalid host", 400), production)
        if path in {"/docs", "/redoc", "/openapi.json", "/debug/routes"} or (production and path == "/__routes"):
            return self.protect(HTMLResponse("Not found", 404), production)
        token = request.session.setdefault("web_csrf", secrets.token_urlsafe(32))
        if request.method == "GET" and path == "/logout":
            return self.protect(HTMLResponse(
                '<html lang="ar" dir="rtl"><meta charset="utf-8"><form method="post" action="/logout">'
                '<input type="hidden" name="_csrf" value="' + escape(token, quote=True) + '">'
                '<button type="submit">تأكيد تسجيل الخروج</button></form></html>'
            ), production)
        if request.method in UNSAFE:
            # Reject requests from other origins even when a token is supplied.
            origin = request.headers.get("origin")
            referer = request.headers.get("referer")
            source = origin or referer
            if request.headers.get("sec-fetch-site") == "cross-site" or (source and (
                urlsplit(source).netloc.lower() != request.url.netloc.lower() or
                urlsplit(source).scheme != request.url.scheme
            )):
                return self.protect(HTMLResponse("مصدر الطلب غير مسموح", 403), production)
            length = request.headers.get("content-length", "0")
            if not length.isdigit() or int(length) > 1024 * 1024:
                return self.protect(HTMLResponse("حجم الطلب أكبر من المسموح", 413), production)
            body = bytearray()
            async for chunk in request.stream():
                body.extend(chunk)
                if len(body) > 1024 * 1024:
                    return self.protect(HTMLResponse("حجم الطلب أكبر من المسموح", 413), production)
            request._body = bytes(body)
            supplied = request.headers.get("x-csrf-token", "")
            if not supplied:
                try:
                    form = await request.form()
                    supplied = form.get("_csrf", "")
                except Exception:
                    supplied = ""
            if not isinstance(supplied, str) or not supplied.isascii() or not secrets.compare_digest(token, supplied):
                return self.protect(HTMLResponse("انتهت صلاحية النموذج؛ حدّث الصفحة وحاول مجددًا", 403), production)
            if path == "/login":
                now = time.monotonic()
                # Do not trust client-supplied forwarded-IP headers.
                ip = request.client.host if request.client else "unknown"
                attempts = self.login_attempts.pop(ip, deque())
                while attempts and attempts[0] <= now - 300:
                    attempts.popleft()
                self.login_attempts[ip] = attempts
                if len(attempts) >= 10:
                    return self.protect(HTMLResponse("محاولات كثيرة؛ حاول بعد خمس دقائق", 429,
                                                    headers={"Retry-After": "300"}), production)
                attempts.append(now)
                while len(self.login_attempts) > 10000:
                    self.login_attempts.popitem(last=False)
        response = await call_next(request)
        if path == "/login" and request.method == "POST" and response.status_code == 303:
            self.login_attempts.pop(request.client.host if request.client else "unknown", None)
        if "text/html" in response.headers.get("content-type", ""):
            body = b"".join([chunk async for chunk in response.body_iterator])
            text = body.decode("utf-8")
            hidden = '<input type="hidden" name="_csrf" value="' + escape(token, quote=True) + '">'
            meta = '<meta name="csrf-token" content="' + escape(token, quote=True) + '">'
            text = re.sub(r"</head\s*>", meta + "</head>", text, count=1, flags=re.I)
            # Existing server-generated forms and Jinja templates share this path.
            text = FORM.sub(lambda match: match.group(0) + hidden, text)
            if os.getenv("CLINOVA_PUBLIC_DEMO") == "1":
                banner = ('<div dir="rtl" role="note" style="padding:12px;background:#fff4d6;'
                          'color:#533b00;text-align:center;font-family:Tahoma,Arial">'
                          'نسخة عرض عامة ببيانات وهمية — لا تدخل بيانات مرضى حقيقية.'
                          '</div>')
                text = re.sub(r"(<body\b[^>]*>)", lambda match: match[0] + banner,
                              text, count=1, flags=re.I)
            if "content-length" in response.headers:
                del response.headers["content-length"]
            response = Response(text, status_code=response.status_code, headers=dict(response.headers),
                                background=response.background)
            response.headers["X-CSRF-Token"] = token
        return self.protect(response, production)

    @staticmethod
    def protect(response, production):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Cache-Control"] = "no-store"
        # Legacy forms use inline handlers; retain compatibility while denying
        # external script execution, plugins, framing, and off-origin forms.
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            "font-src 'self'; connect-src 'self'; object-src 'none'; "
            "base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
        )
        if production:
            response.headers["Strict-Transport-Security"] = "max-age=31536000"
        return response
