from clinic_security import protect_referenced_record
from input_validation import calendar_date, appointment_clock, required_name
from datetime import datetime
from html import escape

from fastapi import APIRouter, Depends, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from clinic_security import tenant_text as text, section_guard
from sqlalchemy.orm import Session

from database import get_db


router = APIRouter(dependencies=[section_guard("doctors")])


# =========================================================
# أدوات مساعدة
# =========================================================

def safe(value):
    if value is None:
        return ""
    return escape(str(value))


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# =========================================================
# التصميم العام
# =========================================================

def page_template(title, content):

    return f"""
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">

    <head>

        <meta charset="UTF-8">

        <meta name="viewport"
              content="width=device-width, initial-scale=1.0">

        <title>{safe(title)} - نظام العيادات</title>

        <style>

            * {{
                box-sizing: border-box;
            }}

            body {{
                margin: 0;
                font-family: Tahoma, Arial, sans-serif;
                background: #f4f7fb;
                color: #1f2937;
            }}

            .container {{
                max-width: 1200px;
                margin: 35px auto;
                padding: 0 20px;
            }}

            .header {{
                background: white;
                border-radius: 16px;
                padding: 22px 25px;
                margin-bottom: 22px;
                box-shadow: 0 3px 15px rgba(0,0,0,0.07);

                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 15px;
                flex-wrap: wrap;
            }}

            .header h1 {{
                margin: 0;
                font-size: 24px;
            }}

            .header p {{
                margin: 7px 0 0;
                color: #6b7280;
            }}

            .btn {{
                display: inline-block;
                border: none;
                border-radius: 10px;
                padding: 11px 18px;
                cursor: pointer;
                text-decoration: none;
                font-size: 14px;
                font-weight: bold;
            }}

            .btn-primary {{
                background: #2563eb;
                color: white;
            }}

            .btn-primary:hover {{
                background: #1d4ed8;
            }}

            .btn-secondary {{
                background: #e5e7eb;
                color: #374151;
            }}

            .btn-danger {{
                background: #dc2626;
                color: white;
            }}

            .btn-warning {{
                background: #f59e0b;
                color: white;
            }}

            .card {{
                background: white;
                border-radius: 16px;
                padding: 25px;
                box-shadow: 0 3px 15px rgba(0,0,0,0.07);
                margin-bottom: 20px;
            }}

            .search {{
                display: flex;
                gap: 10px;
                margin-bottom: 20px;
            }}

            .search input {{
                flex: 1;
            }}

            label {{
                display: block;
                margin-bottom: 7px;
                font-weight: bold;
                color: #374151;
            }}

            input,
            textarea {{
                width: 100%;
                border: 1px solid #d1d5db;
                border-radius: 10px;
                padding: 12px;
                font-size: 15px;
                outline: none;
                background: white;
            }}

            input:focus,
            textarea:focus {{
                border-color: #2563eb;
                box-shadow: 0 0 0 3px rgba(37,99,235,0.10);
            }}

            textarea {{
                min-height: 110px;
                resize: vertical;
            }}

            .form-grid {{
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
            }}

            .form-group.full {{
                grid-column: 1 / -1;
            }}

            .actions {{
                display: flex;
                gap: 10px;
                margin-top: 25px;
                flex-wrap: wrap;
            }}

            table {{
                width: 100%;
                border-collapse: collapse;
            }}

            th {{
                background: #f3f4f6;
                padding: 14px 10px;
                text-align: right;
                font-size: 14px;
            }}

            td {{
                padding: 13px 10px;
                border-bottom: 1px solid #e5e7eb;
            }}

            tr:hover td {{
                background: #f9fafb;
            }}

            .empty {{
                text-align: center;
                padding: 40px;
                color: #6b7280;
            }}

            .actions-cell {{
                white-space: nowrap;
            }}

            .badge {{
                display: inline-block;
                background: #eff6ff;
                color: #2563eb;
                padding: 5px 10px;
                border-radius: 20px;
                font-size: 12px;
            }}

            @media (max-width: 700px) {{

                .form-grid {{
                    grid-template-columns: 1fr;
                }}

                .form-group.full {{
                    grid-column: auto;
                }}

                .table-wrapper {{
                    overflow-x: auto;
                }}

                table {{
                    min-width: 700px;
                }}

            }}

        </style>

    </head>

    <body>

        <div class="container">

            {content}

        </div>

    </body>

    </html>
    """


# =========================================================
# قائمة الأطباء
# =========================================================

@router.get("/doctors", response_class=HTMLResponse)
def doctors_list(
    search: str = "",
    db: Session = Depends(get_db)
):

    search = search.strip()

    if search:

        result = db.execute(
            text('\n                SELECT\n                    id,\n                    full_name,\n                    specialization,\n                    phone,\n                    address,\n                    notes,\n                    created_at\n                FROM (SELECT * FROM doctors WHERE clinic_id=:active_clinic_id) AS doctors\n                WHERE\n                    full_name LIKE :search\n                    OR specialization LIKE :search\n                    OR phone LIKE :search\n                ORDER BY id DESC\n            '),
            {
                "search": f"%{search}%"
            }
        )

    else:

        result = db.execute(
            text('\n                SELECT\n                    id,\n                    full_name,\n                    specialization,\n                    phone,\n                    address,\n                    notes,\n                    created_at\n                FROM (SELECT * FROM doctors WHERE clinic_id=:active_clinic_id) AS doctors\n                ORDER BY id DESC\n            ')
        )

    doctors = result.mappings().all()

    rows = ""

    for doctor in doctors:

        rows += f"""
        <tr>

            <td>
                {doctor["id"]}
            </td>

            <td>
                <strong>
                    👨‍⚕️ {safe(doctor["full_name"])}
                </strong>
            </td>

            <td>
                <span class="badge">
                    {safe(doctor["specialization"]) or "غير محدد"}
                </span>
            </td>

            <td>
                {safe(doctor["phone"]) or "-"}
            </td>

            <td>
                {safe(doctor["address"]) or "-"}
            </td>

            <td class="actions-cell">

                <a
                    href="/doctors/edit/{doctor['id']}"
                    class="btn btn-warning"
                >
                    ✏️ تعديل
                </a>

                <form method="post" action="/doctors/delete/{doctor['id']}" style="display:inline" onsubmit="return confirm('هل تريد تأكيد هذا الإجراء؟')"><button type="submit" class="btn btn-danger">
                    🗑️ حذف
                </button></form>

            </td>

        </tr>
        """

    if not rows:

        rows = """
        <tr>
            <td colspan="6" class="empty">
                لا يوجد أطباء مسجلون حاليًا
            </td>
        </tr>
        """

    content = f"""

        <div class="header">

            <div>
                <h1>👨‍⚕️ إدارة الأطباء</h1>

                <p>
                    إضافة وإدارة بيانات الأطباء في العيادة
                </p>
            </div>

            <a
                href="/doctors/new"
                class="btn btn-primary"
            >
                ➕ إضافة طبيب جديد
            </a>

        </div>


        <div class="card">

            <form
                method="get"
                action="/doctors"
                class="search"
            >

                <input
                    type="text"
                    name="search"
                    value="{safe(search)}"
                    placeholder="🔍 ابحث باسم الطبيب أو الاختصاص أو الهاتف..."
                >

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    بحث
                </button>

                <a
                    href="/doctors"
                    class="btn btn-secondary"
                >
                    إعادة
                </a>

            </form>


            <div class="table-wrapper">

                <table>

                    <thead>

                        <tr>

                            <th>الرقم</th>

                            <th>اسم الطبيب</th>

                            <th>الاختصاص</th>

                            <th>الهاتف</th>

                            <th>العنوان</th>

                            <th>الإجراءات</th>

                        </tr>

                    </thead>

                    <tbody>

                        {rows}

                    </tbody>

                </table>

            </div>

        </div>

        <a
            href="/"
            class="btn btn-secondary"
        >
            🏠 العودة للرئيسية
        </a>

    """

    return page_template(
        "إدارة الأطباء",
        content
    )


# =========================================================
# صفحة إضافة طبيب
# =========================================================

@router.get("/doctors/new", response_class=HTMLResponse)
def new_doctor():

    content = """

        <div class="header">

            <div>

                <h1>👨‍⚕️ إضافة طبيب جديد</h1>

                <p>
                    أدخل بيانات الطبيب ثم اضغط حفظ
                </p>

            </div>

        </div>


        <div class="card">

            <form
                method="post"
                action="/doctors/create"
            >

                <div class="form-grid">


                    <div class="form-group full">

                        <label>
                            اسم الطبيب *
                        </label>

                        <input
                            type="text"
                            name="full_name"
                            required
                            placeholder="مثال: د. أحمد محمد"
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            الاختصاص
                        </label>

                        <input
                            type="text"
                            name="specialization"
                            placeholder="مثال: طب الأطفال"
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            رقم الهاتف
                        </label>

                        <input
                            type="text"
                            name="phone"
                            placeholder="مثال: 09XXXXXXXX"
                        >

                    </div>


                    <div class="form-group full">

                        <label>
                            العنوان
                        </label>

                        <input
                            type="text"
                            name="address"
                            placeholder="عنوان الطبيب"
                        >

                    </div>


                    <div class="form-group full">

                        <label>
                            ملاحظات
                        </label>

                        <textarea
                            name="notes"
                            placeholder="أي معلومات إضافية عن الطبيب..."
                        ></textarea>

                    </div>

                </div>


                <div class="actions">

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >
                        💾 حفظ الطبيب
                    </button>

                    <a
                        href="/doctors"
                        class="btn btn-secondary"
                    >
                        ↩ إلغاء
                    </a>

                </div>

            </form>

        </div>

    """

    return page_template(
        "إضافة طبيب",
        content
    )


# =========================================================
# حفظ الطبيب
# =========================================================

@router.post("/doctors/create")
def create_doctor(
    full_name: str = Form(...),
    specialization: str = Form(""),
    phone: str = Form(""),
    address: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db)
):

    full_name = required_name(full_name, "اسم الطبيب")

    full_name = full_name.strip()

    if not full_name:

        raise HTTPException(
            status_code=400,
            detail="اسم الطبيب مطلوب"
        )

    db.execute(
        text('\n            INSERT INTO doctors\n            (clinic_id, \n                full_name,\n                specialization,\n                phone,\n                address,\n                notes,\n                created_at\n            )\n            VALUES\n            (:active_clinic_id, \n                :full_name,\n                :specialization,\n                :phone,\n                :address,\n                :notes,\n                :created_at\n            )\n        '),
        {
            "full_name": full_name,
            "specialization": specialization.strip(),
            "phone": phone.strip(),
            "address": address.strip(),
            "notes": notes.strip(),
            "created_at": now()
        }
    )

    db.commit()

    return RedirectResponse(
        url="/doctors",
        status_code=303
    )


# =========================================================
# تعديل الطبيب
# =========================================================

@router.get(
    "/doctors/edit/{doctor_id}",
    response_class=HTMLResponse
)
def edit_doctor(
    doctor_id: int,
    db: Session = Depends(get_db)
):

    result = db.execute(
        text('\n            SELECT\n                id,\n                full_name,\n                specialization,\n                phone,\n                address,\n                notes\n            FROM (SELECT * FROM doctors WHERE clinic_id=:active_clinic_id) AS doctors\n            WHERE id = :id\n        '),
        {
            "id": doctor_id
        }
    )

    doctor = result.mappings().first()

    if not doctor:

        raise HTTPException(
            status_code=404,
            detail="الطبيب غير موجود"
        )

    content = f"""

        <div class="header">

            <div>

                <h1>✏️ تعديل بيانات الطبيب</h1>

                <p>
                    تعديل بيانات الطبيب رقم {doctor["id"]}
                </p>

            </div>

        </div>


        <div class="card">

            <form
                method="post"
                action="/doctors/update/{doctor_id}"
            >

                <div class="form-grid">


                    <div class="form-group full">

                        <label>
                            اسم الطبيب *
                        </label>

                        <input
                            type="text"
                            name="full_name"
                            required
                            value="{safe(doctor['full_name'])}"
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            الاختصاص
                        </label>

                        <input
                            type="text"
                            name="specialization"
                            value="{safe(doctor['specialization'])}"
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            رقم الهاتف
                        </label>

                        <input
                            type="text"
                            name="phone"
                            value="{safe(doctor['phone'])}"
                        >

                    </div>


                    <div class="form-group full">

                        <label>
                            العنوان
                        </label>

                        <input
                            type="text"
                            name="address"
                            value="{safe(doctor['address'])}"
                        >

                    </div>


                    <div class="form-group full">

                        <label>
                            ملاحظات
                        </label>

                        <textarea
                            name="notes"
                        >{safe(doctor['notes'])}</textarea>

                    </div>

                </div>


                <div class="actions">

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >
                        💾 حفظ التعديلات
                    </button>

                    <a
                        href="/doctors"
                        class="btn btn-secondary"
                    >
                        ↩ إلغاء
                    </a>

                </div>

            </form>

        </div>

    """

    return page_template(
        "تعديل الطبيب",
        content
    )


# =========================================================
# تحديث الطبيب
# =========================================================

@router.post("/doctors/update/{doctor_id}")
def update_doctor(
    doctor_id: int,
    full_name: str = Form(...),
    specialization: str = Form(""),
    phone: str = Form(""),
    address: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db)
):

    full_name = required_name(full_name, "اسم الطبيب")

    full_name = full_name.strip()

    if not full_name:

        raise HTTPException(
            status_code=400,
            detail="اسم الطبيب مطلوب"
        )

    result = db.execute(
        text('\n            SELECT id\n            FROM (SELECT * FROM doctors WHERE clinic_id=:active_clinic_id) AS doctors\n            WHERE id = :id\n        '),
        {
            "id": doctor_id
        }
    )

    doctor = result.first()

    if not doctor:

        raise HTTPException(
            status_code=404,
            detail="الطبيب غير موجود"
        )

    db.execute(
        text('\n            UPDATE doctors\n            SET\n                full_name = :full_name,\n                specialization = :specialization,\n                phone = :phone,\n                address = :address,\n                notes = :notes\n            WHERE id = :id AND (clinic_id=:active_clinic_id)\n'),
        {
            "id": doctor_id,
            "full_name": full_name,
            "specialization": specialization.strip(),
            "phone": phone.strip(),
            "address": address.strip(),
            "notes": notes.strip()
        }
    )

    db.commit()

    return RedirectResponse(
        url="/doctors",
        status_code=303
    )


# =========================================================
# حذف الطبيب
# =========================================================

@router.post("/doctors/delete/{doctor_id}")
def delete_doctor(
    doctor_id: int,
    db: Session = Depends(get_db)
):

    protect_referenced_record(db, [("appointments", "doctor_id"), ("visits", "doctor_id"), ("invoices", "doctor_id")], doctor_id)

    result = db.execute(
        text('\n            SELECT id\n            FROM (SELECT * FROM doctors WHERE clinic_id=:active_clinic_id) AS doctors\n            WHERE id = :id\n        '),
        {
            "id": doctor_id
        }
    )

    doctor = result.first()

    if not doctor:

        raise HTTPException(
            status_code=404,
            detail="الطبيب غير موجود"
        )

    db.execute(
        text('\n            DELETE FROM doctors\n            WHERE id = :id AND (clinic_id=:active_clinic_id)\n'),
        {
            "id": doctor_id
        }
    )

    db.commit()

    return RedirectResponse(
        url="/doctors",
        status_code=303
    )
