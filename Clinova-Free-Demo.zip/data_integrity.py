"""Report broken references without deleting records or inventing ownership."""
from sqlalchemy import inspect, text

RELATIONS = [
    ("appointments", "patient_id", "patients", "المواعيد"),
    ("visits", "patient_id", "patients", "الزيارات"),
    ("pregnancies", "patient_id", "patients", "الحمل"),
    ("family_planning", "patient_id", "patients", "تنظيم الأسرة"),
    ("prescriptions", "patient_id", "patients", "الوصفات"),
    ("invoices", "patient_id", "patients", "الفواتير"),
    ("laboratory_orders", "patient_id", "patients", "طلبات المختبر"),
    ("radiology_requests", "patient_id", "patients", "طلبات الأشعة"),
    ("pregnancy_followups", "pregnancy_id", "pregnancies", "متابعات الحمل"),
    ("prescription_items", "prescription_id", "prescriptions", "أدوية الوصفات"),
    ("laboratory_order_items", "order_id", "laboratory_orders", "نتائج المختبر"),
    ("radiology_reports", "radiology_request_id", "radiology_requests", "تقارير الأشعة"),
    ("radiology_appointments", "radiology_request_id", "radiology_requests", "مواعيد الأشعة"),
]


def integrity_issues(db, clinic_id):
    inspector = inspect(db.get_bind())
    single = db.execute(text("SELECT COUNT(*) FROM clinics")).scalar() == 1
    issues = []
    for table, column, parent, label in RELATIONS:
        if not inspector.has_table(table) or not inspector.has_table(parent): continue
        columns = {item["name"] for item in inspector.get_columns(table)}
        if column not in columns: continue
        if "clinic_id" in columns:
            owner = "(c.clinic_id=:clinic_id" + (" OR c.clinic_id IS NULL)" if single else ")")
        elif single:
            owner = "1=1"
        else:
            continue  # A record with no remaining owner cannot be assigned by guesswork.
        rows = db.execute(text(f'''SELECT c.id, c."{column}" AS missing_id
            FROM "{table}" c LEFT JOIN "{parent}" p ON p.id=c."{column}"
            WHERE c."{column}" IS NOT NULL AND p.id IS NULL AND {owner} ORDER BY c.id'''),
            {"clinic_id": clinic_id}).mappings().all()
        issues.extend({"section": label, "table": table, "id": row["id"], "missing_id": row["missing_id"]} for row in rows)
    return issues
