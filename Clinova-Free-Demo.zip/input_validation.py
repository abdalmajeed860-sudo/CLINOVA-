"""Form validation and canonical calendar values; no medical decisions."""
from datetime import date, time
from decimal import Decimal, InvalidOperation
from fastapi import HTTPException


def calendar_date(value, label="التاريخ", required=False, allow_future=True):
    value = str(value or "").strip()
    if not value:
        if required: raise HTTPException(400, f"{label} مطلوب")
        return ""
    try:
        parsed = date.fromisoformat(value)
    except ValueError:
        raise HTTPException(400, f"{label} غير صالح")
    if not allow_future and parsed > date.today():
        raise HTTPException(400, f"{label} لا يمكن أن يكون في المستقبل")
    return parsed.isoformat()


def appointment_clock(value):
    try:
        parsed = time.fromisoformat(str(value or "").strip())
        if parsed.tzinfo: raise ValueError()
        return parsed.strftime("%H:%M")
    except ValueError:
        raise HTTPException(400, "وقت الموعد غير صالح")


def required_name(value, label="الاسم", maximum=200):
    value = str(value or "").strip()
    if not value or len(value) > maximum:
        raise HTTPException(400, f"{label} مطلوب ويجب ألا يتجاوز{maximum} حرف")
    return value


def nonnegative_price(value):
    try:
        amount = Decimal(str(value))
        if not amount.is_finite() or amount < 0 or amount > Decimal("9999999999.99"):
            raise ValueError()
        return float(amount.quantize(Decimal("0.01")))
    except (ValueError, InvalidOperation):
        raise HTTPException(400, "السعر غير صالح")
