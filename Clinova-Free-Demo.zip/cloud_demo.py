"""Cloud entry point: isolated fictional demonstration, never the local clinic DB."""
import os
from pathlib import Path

os.environ["CLINOVA_PRODUCTION"] = "1"
os.environ["CLINOVA_PUBLIC_DEMO"] = "1"
os.chdir(Path(__file__).resolve().parent)
import create_demo_preview

create_demo_preview.seed()
from main import app
