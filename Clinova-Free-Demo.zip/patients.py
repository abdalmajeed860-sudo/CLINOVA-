from input_validation import calendar_date, appointment_clock, required_name
from clinic_security import tenant_text, patient_access, protect_referenced_record
# ============================================================
# CLINOVA
# نظام إدارة العيادات الذكي والمتكامل
# patients.py
#
# إدارة المرضى - Multi Clinic / Tenant Isolation
# Permissions Integrated
# ============================================================

from datetime import date, datetime
from html import escape

from fastapi import APIRouter, Depends, Form, Query, Request, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from clinic_security import tenant_text as text, patient_owner_id
from sqlalchemy.orm import Session

from database import get_db
from auth import has_permission


# ============================================================
# Router
# ============================================================

router = APIRouter(dependencies=[Depends(patient_access)])


# ============================================================
# Helpers
# ============================================================

def safe(value):
    """حماية النصوص المستخدمة داخل HTML."""
    if value is None:
        return ""
    return escape(str(value))


def today():
    """تاريخ اليوم بصيغة مناسبة لـ HTML date."""
    return date.today().isoformat()


def now():
    """الوقت الحالي."""
    return datetime.now()


def normalize_date(value):
    """تحويل التاريخ القادم من النموذج إلى ISO."""
    if value is None:
        return None

    value = str(value).strip()

    if not value:
        return None

    try:
        datetime.strptime(value, "%Y-%m-%d")
        return value
    except ValueError:
        return None


def table_exists(db: Session, table_name: str):
    """التحقق من وجود جدول في SQLite."""
    try:
        result = db.execute(
            text(
                """
                SELECT name
                FROM sqlite_master
                WHERE type='table'
                  AND name=:table_name
                """
            ),
            {"table_name": table_name},
        ).fetchone()

        return result is not None

    except Exception:
        return False


def has_column(db: Session, table_name: str, column_name: str):
    """التحقق من وجود عمود في جدول SQLite."""
    try:
        rows = db.execute(
            text(f"PRAGMA table_info({table_name})")
        ).fetchall()

        return any(row[1] == column_name for row in rows)

    except Exception:
        return False


def get_current_clinic_id(request: Request, db: Session):
    from auth import get_current_user
    from models import Clinic
    from fastapi import HTTPException
    user = get_current_user(request, db)
    if not user or not user.clinic_id or not db.query(Clinic.id).filter_by(id=user.clinic_id, is_active=True).first():
        raise HTTPException(403, "الحساب غير مرتبط بمنشأة فعالة")
    return user.clinic_id


def clinic_condition(
    db: Session,
    table_name: str,
    clinic_id,
    params: dict,
):
    """
    إنشاء شرط clinic_id بشكل آمن حسب وجود العمود.
    """

    if clinic_id is None:
        return ""

    if not has_column(db, table_name, "clinic_id"):
        return ""

    params["clinic_id"] = clinic_id

    return " AND clinic_id=:clinic_id "


def generate_medical_number(db: Session):
    """Generate without inspecting other accounts' private patient sequences."""
    from uuid import uuid4
    return "MED-" + uuid4().hex[:16].upper()


# ============================================================
# Permission Helpers
# ============================================================

def permission_denied(
    title="غير مصرح",
    back_url="/patients",
):
    """
    صفحة موحدة عند عدم امتلاك المستخدم للصلاحية.
    """

    content = f"""
    <div class="card">

        <div class="alert alert-danger">
            ليس لديك صلاحية لتنفيذ هذه العملية.
        </div>

        <a
            href="{safe(back_url)}"
            class="btn btn-primary"
        >
            العودة
        </a>

    </div>
    """

    return HTMLResponse(
        render_page(title, content),
        status_code=403,
    )


def can_view_patients(request: Request, db: Session):
    return has_permission(
        request,
        db,
        "patients",
        "view",
    )


def can_manage_patients(request: Request, db: Session):
    return has_permission(
        request,
        db,
        "patients",
        "full",
    )


def can_manage_visits(request: Request, db: Session):
    return has_permission(
        request,
        db,
        "visits",
        "full",
    )


def can_manage_appointments(request: Request, db: Session):
    return has_permission(
        request,
        db,
        "appointments",
        "full",
    )


def can_view_laboratory(request: Request, db: Session):
    return has_permission(
        request,
        db,
        "laboratory",
        "view",
    )


def can_view_billing(request: Request, db: Session):
    return has_permission(
        request,
        db,
        "billing",
        "view",
    )


# ============================================================
# HTML Template
# ============================================================

PAGE_TEMPLATE = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>{title} - CLINOVA</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 0;

    font-family:
        "Segoe UI",
        Tahoma,
        Arial,
        sans-serif;

    background:
        linear-gradient(
            135deg,
            #f5f7fb,
            #eef2f7
        );

    color: #1f2937;
}

a {
    text-decoration: none;
}

.container {
    width: min(1400px, 94%);
    margin: 30px auto;
}

/* Header */

.header {
    background: #ffffff;

    border-radius: 20px;

    padding: 22px 26px;

    margin-bottom: 22px;

    display: flex;

    justify-content: space-between;

    align-items: center;

    box-shadow:
        0 8px 30px rgba(
            15,
            23,
            42,
            0.08
        );
}

.brand {
    display: flex;

    align-items: center;

    gap: 14px;
}

.logo {
    width: 54px;
    height: 54px;

    border-radius: 15px;

    display: flex;

    align-items: center;

    justify-content: center;

    background:
        linear-gradient(
            135deg,
            #2563eb,
            #0ea5e9
        );

    color: white;

    font-size: 25px;

    font-weight: 800;
}

.brand h1 {
    margin: 0;

    font-size: 24px;
}

.brand p {
    margin: 5px 0 0;

    color: #64748b;

    font-size: 13px;
}

.header-actions {
    display: flex;

    gap: 10px;

    flex-wrap: wrap;
}

/* Buttons */

.btn {
    border: none;

    border-radius: 11px;

    padding: 11px 16px;

    font-size: 14px;

    font-weight: 700;

    cursor: pointer;

    display: inline-flex;

    align-items: center;

    justify-content: center;

    transition: 0.2s;
}

.btn:hover {
    transform: translateY(-1px);
}

.btn-primary {
    background: #2563eb;
    color: white;
}

.btn-success {
    background: #16a34a;
    color: white;
}

.btn-danger {
    background: #dc2626;
    color: white;
}

.btn-warning {
    background: #d97706;
    color: white;
}

.btn-secondary {
    background: #475569;
    color: white;
}

.btn-light {
    background: #e2e8f0;
    color: #1e293b;
}

/* Cards */

.card {
    background: white;

    border-radius: 20px;

    padding: 24px;

    margin-bottom: 22px;

    box-shadow:
        0 8px 30px rgba(
            15,
            23,
            42,
            0.07
        );
}

.card-title {
    font-size: 20px;

    font-weight: 800;

    margin-bottom: 18px;

    display: flex;

    align-items: center;

    gap: 8px;
}

/* Stats */

.stats {
    display: grid;

    grid-template-columns:
        repeat(
            auto-fit,
            minmax(190px, 1fr)
        );

    gap: 16px;

    margin-bottom: 22px;
}

.stat {
    background: white;

    border-radius: 18px;

    padding: 20px;

    box-shadow:
        0 8px 25px rgba(
            15,
            23,
            42,
            0.06
        );
}

.stat-title {
    color: #64748b;

    font-size: 14px;

    margin-bottom: 8px;
}

.stat-value {
    font-size: 28px;

    font-weight: 800;

    color: #0f172a;
}

/* Search */

.search-box {
    display: grid;

    grid-template-columns:
        minmax(250px, 1fr)
        auto
        auto;

    gap: 10px;
}

input,
select,
textarea {
    width: 100%;

    border: 1px solid #dbe2ea;

    border-radius: 11px;

    padding: 12px 14px;

    background: #fff;

    font-family: inherit;

    font-size: 14px;

    outline: none;

    transition: 0.2s;
}

input:focus,
select:focus,
textarea:focus {
    border-color: #2563eb;

    box-shadow:
        0 0 0 3px rgba(
            37,
            99,
            235,
            0.10
        );
}

textarea {
    min-height: 110px;

    resize: vertical;
}

/* Table */

.table-wrapper {
    overflow-x: auto;
}

table {
    width: 100%;

    border-collapse: collapse;

    min-width: 900px;
}

th {
    background: #f8fafc;

    color: #475569;

    font-size: 13px;

    font-weight: 800;

    padding: 14px;

    text-align: right;

    border-bottom:
        1px solid #e2e8f0;
}

td {
    padding: 14px;

    border-bottom:
        1px solid #eef2f7;

    vertical-align: middle;
}

tr:hover td {
    background: #fafcff;
}

/* Patient */

.patient-name {
    font-weight: 800;

    color: #0f172a;
}

.patient-number {
    color: #2563eb;

    font-size: 13px;

    margin-top: 4px;
}

.badge {
    display: inline-block;

    padding: 5px 9px;

    border-radius: 8px;

    font-size: 12px;

    font-weight: 700;
}

.badge-blue {
    background: #dbeafe;

    color: #1d4ed8;
}

.badge-green {
    background: #dcfce7;

    color: #15803d;
}

.badge-gray {
    background: #f1f5f9;

    color: #475569;
}

/* Actions */

.actions {
    display: flex;

    gap: 7px;

    flex-wrap: wrap;
}

/* Form */

.form-grid {
    display: grid;

    grid-template-columns:
        repeat(
            2,
            minmax(0, 1fr)
        );

    gap: 18px;
}

.form-group {
    display: flex;

    flex-direction: column;

    gap: 7px;
}

.form-group.full {
    grid-column: 1 / -1;
}

.form-label {
    font-size: 13px;

    font-weight: 800;

    color: #334155;
}

.form-actions {
    display: flex;

    gap: 10px;

    margin-top: 22px;

    flex-wrap: wrap;
}

/* Profile */

.profile-header {
    display: flex;

    justify-content: space-between;

    gap: 20px;

    align-items: flex-start;
}

.profile-name {
    font-size: 27px;

    font-weight: 900;

    margin-bottom: 7px;
}

.profile-meta {
    color: #64748b;

    font-size: 14px;
}

.info-grid {
    display: grid;

    grid-template-columns:
        repeat(
            auto-fit,
            minmax(220px, 1fr)
        );

    gap: 14px;
}

.info-item {
    background: #f8fafc;

    border-radius: 13px;

    padding: 15px;
}

.info-label {
    color: #64748b;

    font-size: 12px;

    margin-bottom: 5px;
}

.info-value {
    font-weight: 700;

    color: #0f172a;

    word-break: break-word;
}

/* Empty */

.empty {
    text-align: center;

    padding: 50px 20px;

    color: #64748b;
}

.empty-icon {
    font-size: 42px;

    margin-bottom: 12px;
}

/* Alert */

.alert {
    border-radius: 13px;

    padding: 14px 16px;

    margin-bottom: 18px;

    font-size: 14px;

    font-weight: 700;
}

.alert-danger {
    background: #fee2e2;

    color: #991b1b;
}

.alert-success {
    background: #dcfce7;

    color: #166534;
}

.alert-info {
    background: #dbeafe;

    color: #1e40af;
}

/* Responsive */

@media (max-width: 800px) {

    .header {
        flex-direction: column;

        align-items: stretch;
    }

    .header-actions {
        width: 100%;
    }

    .search-box {
        grid-template-columns: 1fr;
    }

    .form-grid {
        grid-template-columns: 1fr;
    }

    .form-group.full {
        grid-column: auto;
    }

    .profile-header {
        flex-direction: column;
    }

}

</style>

</head>

<body>

<div class="container">

{content}

</div>

</body>

</html>
"""


def render_page(title, content):
    """إخراج صفحة HTML كاملة."""
    # CSS contains literal braces; str.format treats them as field names.
    # Replace the two template slots before inserting unmodified HTML content.
    import re
    return re.sub(r"\{(title|content)\}", lambda match: {"title": safe(title), "content": content}[match.group(1)], PAGE_TEMPLATE)


# ============================================================
# Patients List
# ============================================================

@router.get("/patients", response_class=HTMLResponse)
def patients_page(
    request: Request,
    q: str = Query(default=""),
    db: Session = Depends(get_db),
):

    if not can_view_patients(request, db):
        return permission_denied()

    clinic_id = get_current_clinic_id(request, db)

    params = {}

    where = " WHERE 1=1 "

    # --------------------------------------------------------
    # Tenant isolation
    # --------------------------------------------------------

    if (
        clinic_id is not None
        and has_column(db, "patients", "clinic_id")
    ):

        where += " AND clinic_id=:clinic_id "

        params["clinic_id"] = clinic_id

    # --------------------------------------------------------
    # Search
    # --------------------------------------------------------

    q = (q or "").strip()

    if q:

        where += """
            AND (
                full_name LIKE :search
                OR medical_number LIKE :search
                OR phone LIKE :search
                OR file_number LIKE :search
            )
        """

        params["search"] = f"%{q}%"

    # --------------------------------------------------------
    # Query
    # --------------------------------------------------------

    try:

        patients = db.execute(
            text(
                f"""
                SELECT
                    id,
                    clinic_id,
                    medical_number,
                    file_number,
                    full_name,
                    gender,
                    birth_date,
                    phone,
                    address,
                    blood_type,
                    allergies,
                    chronic_diseases,
                    notes,
                    created_at
                FROM patients
                {where}
                ORDER BY id DESC
                """
            ),
            params,
        ).mappings().all()

    except Exception as e:

        content = f"""
        <div class="card">

            <div class="alert alert-danger">
                حدث خطأ أثناء تحميل المرضى:
                {safe(e)}
            </div>

            <a href="/" class="btn btn-primary">
                العودة للرئيسية
            </a>

        </div>
        """

        return HTMLResponse(
            render_page("المرضى", content),
            status_code=500,
        )

    # --------------------------------------------------------
    # Permission visibility
    # --------------------------------------------------------

    can_manage = can_manage_patients(
        request,
        db,
    )

    can_appointment = can_manage_appointments(
        request,
        db,
    )

    # --------------------------------------------------------
    # Rows
    # --------------------------------------------------------

    rows = ""

    for patient in patients:

        patient_id = patient["id"]

        gender = patient["gender"] or "-"

        phone = patient["phone"] or "-"

        file_number = (
            patient["file_number"]
            or "-"
        )

        medical_number = (
            patient["medical_number"]
            or f"MED-{patient_id:06d}"
        )

        actions = f"""
        <a
            class="btn btn-primary"
            href="/patients/{patient_id}"
        >
            الملف
        </a>
        """

        if can_appointment:

            actions += f"""
            <a
                class="btn btn-success"
                href="/appointments/new?patient_id={patient_id}"
            >
                موعد
            </a>
            """

        if can_manage:

            actions += f"""
            <a
                class="btn btn-secondary"
                href="/patients/edit/{patient_id}"
            >
                تعديل
            </a>

            <form method="post" action="/patients/delete/{patient_id}" style="display:inline" onsubmit="return confirm('هل تريد تأكيد هذا الإجراء؟')"><button type="submit" class="btn btn-danger">
                حذف
            </button></form>
            """

        rows += f"""
        <tr>

            <td>

                <div class="patient-name">
                    {safe(patient["full_name"])}
                </div>

                <div class="patient-number">
                    {safe(medical_number)}
                </div>

            </td>

            <td>
                <span class="badge badge-blue">
                    {safe(file_number)}
                </span>
            </td>

            <td>
                {safe(gender)}
            </td>

            <td>
                {safe(phone)}
            </td>

            <td>
                {safe(patient["birth_date"] or "-")}
            </td>

            <td>

                <div class="actions">

                    {actions}

                </div>

            </td>

        </tr>
        """

    if not rows:

        rows = """
        <tr>

            <td colspan="6">

                <div class="empty">

                    <div class="empty-icon">
                        👨‍⚕️
                    </div>

                    <div>
                        لا توجد سجلات مرضى.
                    </div>

                </div>

            </td>

        </tr>
        """

    # --------------------------------------------------------
    # Add button
    # --------------------------------------------------------

    add_button = ""

    if can_manage:

        add_button = """
        <a
            href="/patients/new"
            class="btn btn-primary"
        >
            + إضافة مريض
        </a>
        """

    content = f"""

    <div class="header">

        <div class="brand">

            <div class="logo">
                C
            </div>

            <div>

                <h1>
                    إدارة المرضى
                </h1>

                <p>
                    CLINOVA — نظام إدارة العيادات الذكي والمتكامل
                </p>

            </div>

        </div>

        <div class="header-actions">

            <a
                href="/"
                class="btn btn-light"
            >
                الرئيسية
            </a>

            {add_button}

        </div>

    </div>


    <div class="stats">

        <div class="stat">

            <div class="stat-title">
                إجمالي المرضى
            </div>

            <div class="stat-value">
                {len(patients)}
            </div>

        </div>

        <div class="stat">

            <div class="stat-title">
                العيادة الحالية
            </div>

            <div class="stat-value">
                #{clinic_id if clinic_id is not None else "-"}
            </div>

        </div>

        <div class="stat">

            <div class="stat-title">
                حالة النظام
            </div>

            <div
                class="stat-value"
                style="font-size:18px;"
            >
                متصل
            </div>

        </div>

    </div>


    <div class="card">

        <div class="card-title">
            🔎 البحث عن مريض
        </div>

        <form
            method="get"
            action="/patients"
        >

            <div class="search-box">

                <input
                    type="text"
                    name="q"
                    value="{safe(q)}"
                    placeholder="
                        الاسم أو الرقم الطبي
                        أو رقم الملف أو الهاتف
                    "
                />

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    بحث
                </button>

                <a
                    href="/patients"
                    class="btn btn-light"
                >
                    مسح
                </a>

            </div>

        </form>

    </div>


    <div class="card">

        <div class="card-title">
            👥 قائمة المرضى
        </div>

        <div class="table-wrapper">

            <table>

                <thead>

                    <tr>

                        <th>
                            المريض
                        </th>

                        <th>
                            رقم الملف
                        </th>

                        <th>
                            الجنس
                        </th>

                        <th>
                            الهاتف
                        </th>

                        <th>
                            تاريخ الميلاد
                        </th>

                        <th>
                            الإجراءات
                        </th>

                    </tr>

                </thead>

                <tbody>

                    {rows}

                </tbody>

            </table>

        </div>

    </div>

    """

    return HTMLResponse(
        render_page("المرضى", content)
    )


# ============================================================
# New Patient Form
# ============================================================

@router.get(
    "/patients/new",
    response_class=HTMLResponse,
)
def new_patient_page(
    request: Request,
    db: Session = Depends(get_db),
):

    if not can_manage_patients(request, db):
        return permission_denied()

    clinic_id = get_current_clinic_id(
        request,
        db,
    )

    content = f"""

    <div class="header">

        <div class="brand">

            <div class="logo">
                C
            </div>

            <div>

                <h1>
                    إضافة مريض جديد
                </h1>

                <p>
                    تسجيل ملف مريض جديد في CLINOVA
                </p>

            </div>

        </div>

        <div class="header-actions">

            <a
                href="/patients"
                class="btn btn-light"
            >
                ← المرضى
            </a>

        </div>

    </div>


    <div class="card">

        <div class="alert alert-info">

            سيتم ربط المريض تلقائيًا بالعيادة الحالية
            رقم #{clinic_id if clinic_id is not None else "-"}.

        </div>


        <form
            method="post"
            action="/patients/add"
        >

            <div class="form-grid">

                <div class="form-group">

                    <label class="form-label">
                        الاسم الكامل *
                    </label>

                    <input
                        type="text"
                        name="full_name"
                        required
                        autofocus
                        placeholder="اسم المريض الكامل"
                    />

                </div>


                <div class="form-group">

                    <label class="form-label">
                        رقم الملف
                    </label>

                    <input
                        type="text"
                        name="file_number"
                        placeholder="رقم الملف"
                    />

                </div>


                <div class="form-group">

                    <label class="form-label">
                        الجنس
                    </label>

                    <select name="gender">

                        <option value="">
                            اختر الجنس
                        </option>

                        <option value="ذكر">
                            ذكر
                        </option>

                        <option value="أنثى">
                            أنثى
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label class="form-label">
                        تاريخ الميلاد
                    </label>

                    <input
                        type="date"
                        name="birth_date"
                        max="{today()}"
                    />

                </div>


                <div class="form-group">

                    <label class="form-label">
                        رقم الهاتف
                    </label>

                    <input
                        type="text"
                        name="phone"
                        placeholder="رقم الهاتف"
                    />

                </div>


                <div class="form-group">

                    <label class="form-label">
                        فصيلة الدم
                    </label>

                    <select name="blood_type">

                        <option value="">
                            غير محدد
                        </option>

                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>

                    </select>

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        العنوان
                    </label>

                    <input
                        type="text"
                        name="address"
                        placeholder="عنوان المريض"
                    />

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        الحساسية
                    </label>

                    <textarea
                        name="allergies"
                        placeholder="الأدوية أو المواد التي تسبب حساسية للمريض"
                    ></textarea>

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        الأمراض المزمنة
                    </label>

                    <textarea
                        name="chronic_diseases"
                        placeholder="مثل السكري، الضغط، الربو..."
                    ></textarea>

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        ملاحظات
                    </label>

                    <textarea
                        name="notes"
                        placeholder="ملاحظات إضافية"
                    ></textarea>

                </div>

            </div>


            <div class="form-actions">

                <button
                    type="submit"
                    class="btn btn-success"
                >
                    حفظ المريض
                </button>

                <a
                    href="/patients"
                    class="btn btn-light"
                >
                    إلغاء
                </a>

            </div>

        </form>

    </div>

    """

    return HTMLResponse(
        render_page(
            "إضافة مريض",
            content,
        )
    )


# ============================================================
# Add Patient
# ============================================================

@router.post("/patients/add")
def add_patient(
    request: Request,

    full_name: str = Form(...),
    gender: str = Form(default=""),
    birth_date: str = Form(default=""),
    phone: str = Form(default=""),
    address: str = Form(default=""),
    blood_type: str = Form(default=""),
    allergies: str = Form(default=""),
    chronic_diseases: str = Form(default=""),
    notes: str = Form(default=""),
    file_number: str = Form(default=""),

    db: Session = Depends(get_db),
):

    full_name = required_name(full_name, "اسم المريض")
    birth_date = calendar_date(birth_date, "تاريخ الميلاد", allow_future=False)

    if not can_manage_patients(request, db):
        return permission_denied()

    full_name = (full_name or "").strip()

    if not full_name:

        return HTMLResponse(
            render_page(
                "خطأ",
                """
                <div class="card">

                    <div class="alert alert-danger">
                        يجب إدخال اسم المريض.
                    </div>

                    <a
                        href="/patients/new"
                        class="btn btn-primary"
                    >
                        العودة
                    </a>

                </div>
                """
            ),
            status_code=400,
        )

    clinic_id = get_current_clinic_id(
        request,
        db,
    )

    medical_number = generate_medical_number(db)

    normalized_birth_date = normalize_date(
        birth_date
    )

    columns = [
        "medical_number",
        "full_name",
        "gender",
        "birth_date",
        "phone",
        "address",
        "blood_type",
        "allergies",
        "chronic_diseases",
        "notes",
    ]

    values = [
        ":medical_number",
        ":full_name",
        ":gender",
        ":birth_date",
        ":phone",
        ":address",
        ":blood_type",
        ":allergies",
        ":chronic_diseases",
        ":notes",
    ]

    params = {
        "medical_number": medical_number,
        "full_name": full_name,
        "gender": gender.strip() or None,
        "birth_date": normalized_birth_date,
        "phone": phone.strip() or None,
        "address": address.strip() or None,
        "blood_type": blood_type.strip() or None,
        "allergies": allergies.strip() or None,
        "chronic_diseases": chronic_diseases.strip() or None,
        "notes": notes.strip() or None,
    }

    if has_column(
        db,
        "patients",
        "file_number",
    ):

        columns.append("file_number")
        values.append(":file_number")

        params["file_number"] = (
            file_number.strip()
            or None
        )

    if (
        clinic_id is not None
        and has_column(
            db,
            "patients",
            "clinic_id",
        )
    ):

        columns.append("clinic_id")
        values.append(":clinic_id")

        params["clinic_id"] = clinic_id

    if has_column(
        db,
        "patients",
        "created_at",
    ):

        columns.append("created_at")
        values.append(":created_at")

        params["created_at"] = now()

    columns.append("owner_user_id")
    values.append(":owner_user_id")
    params["owner_user_id"] = patient_owner_id()

    try:

        query = f"""
            INSERT INTO patients
            ({", ".join(columns)})
            VALUES
            ({", ".join(values)})
        """

        result = db.execute(
            text(query),
            params,
        )

        db.commit()

        patient_id = result.lastrowid

        return RedirectResponse(
            url=f"/patients/{patient_id}",
            status_code=303,
        )

    except Exception as e:

        db.rollback()

        content = f"""

        <div class="card">

            <div class="alert alert-danger">

                <strong>
                    تعذر حفظ المريض.
                </strong>

                <br><br>

                {safe(e)}

            </div>

            <a
                href="/patients/new"
                class="btn btn-primary"
            >
                العودة إلى نموذج المريض
            </a>

        </div>

        """

        return HTMLResponse(
            render_page(
                "خطأ في الحفظ",
                content,
            ),
            status_code=500,
        )


# ============================================================
# Patient Profile
# ============================================================

@router.get(
    "/patients/{patient_id}",
    response_class=HTMLResponse,
)
def patient_profile(
    request: Request,
    patient_id: int,
    db: Session = Depends(get_db),
):

    if not can_view_patients(request, db):
        return permission_denied()

    clinic_id = get_current_clinic_id(
        request,
        db,
    )

    params = {
        "patient_id": patient_id,
    }

    where = " WHERE id=:patient_id "

    if (
        clinic_id is not None
        and has_column(
            db,
            "patients",
            "clinic_id",
        )
    ):

        where += """
            AND clinic_id=:clinic_id
        """

        params["clinic_id"] = clinic_id

    patient = db.execute(
        text(
            f"""
            SELECT *
            FROM patients
            {where}
            LIMIT 1
            """
        ),
        params,
    ).mappings().first()

    if not patient:

        return HTMLResponse(
            render_page(
                "المريض غير موجود",
                """
                <div class="card">

                    <div class="alert alert-danger">
                        المريض غير موجود أو لا ينتمي إلى العيادة الحالية.
                    </div>

                    <a
                        href="/patients"
                        class="btn btn-primary"
                    >
                        العودة إلى المرضى
                    </a>

                </div>
                """
            ),
            status_code=404,
        )

    # --------------------------------------------------------
    # Visits
    # --------------------------------------------------------

    visits = []

    if table_exists(db, "visits"):

        visit_params = {
            "patient_id": patient_id
        }

        visit_where = """
            WHERE patient_id=:patient_id
        """

        if (
            clinic_id is not None
            and has_column(
                db,
                "visits",
                "clinic_id",
            )
        ):

            visit_where += """
                AND clinic_id=:clinic_id
            """

            visit_params["clinic_id"] = clinic_id

        try:

            visits = db.execute(
                text(
                    f"""
                    SELECT *
                    FROM visits
                    {visit_where}
                    ORDER BY
                        visit_date DESC,
                        id DESC
                    LIMIT 50
                    """
                ),
                visit_params,
            ).mappings().all()

        except Exception:
            visits = []

    # --------------------------------------------------------
    # Appointments
    # --------------------------------------------------------

    appointments = []

    if table_exists(db, "appointments"):

        appointment_params = {
            "patient_id": patient_id
        }

        appointment_where = """
            WHERE patient_id=:patient_id
        """

        if (
            clinic_id is not None
            and has_column(
                db,
                "appointments",
                "clinic_id",
            )
        ):

            appointment_where += """
                AND clinic_id=:clinic_id
            """

            appointment_params["clinic_id"] = clinic_id

        try:

            appointments = db.execute(
                text(
                    f"""
                    SELECT *
                    FROM appointments
                    {appointment_where}
                    ORDER BY id DESC
                    LIMIT 20
                    """
                ),
                appointment_params,
            ).mappings().all()

        except Exception:
            appointments = []

    # --------------------------------------------------------
    # Prescriptions
    # --------------------------------------------------------

    prescriptions = []

    if table_exists(
        db,
        "prescriptions",
    ):

        prescription_params = {
            "patient_id": patient_id
        }

        prescription_where = """
            WHERE patient_id=:patient_id
        """

        if (
            clinic_id is not None
            and has_column(
                db,
                "prescriptions",
                "clinic_id",
            )
        ):

            prescription_where += """
                AND clinic_id=:clinic_id
            """

            prescription_params["clinic_id"] = clinic_id

        try:

            prescriptions = db.execute(
                text(
                    f"""
                    SELECT *
                    FROM prescriptions
                    {prescription_where}
                    ORDER BY id DESC
                    LIMIT 20
                    """
                ),
                prescription_params,
            ).mappings().all()

        except Exception:
            prescriptions = []

    # --------------------------------------------------------
    # Permission states
    # --------------------------------------------------------

    can_manage = can_manage_patients(
        request,
        db,
    )

    can_visit = can_manage_visits(
        request,
        db,
    )

    can_appointment = can_manage_appointments(
        request,
        db,
    )

    can_lab = can_view_laboratory(
        request,
        db,
    )

    can_billing = can_view_billing(
        request,
        db,
    )

    # --------------------------------------------------------
    # Medical number
    # --------------------------------------------------------

    medical_number = (
        patient.get("medical_number")
        or f"MED-{patient_id:06d}"
    )

    # --------------------------------------------------------
    # Visit rows
    # --------------------------------------------------------

    visit_rows = ""

    for visit in visits:

        visit_rows += f"""
        <tr>

            <td>
                {safe(
                    visit.get("visit_date")
                    or "-"
                )}
            </td>

            <td>
                {safe(
                    visit.get("doctor_name")
                    or "-"
                )}
            </td>

            <td>
                {safe(
                    visit.get("chief_complaint")
                    or "-"
                )}
            </td>

            <td>
                {safe(
                    visit.get("diagnosis")
                    or "-"
                )}
            </td>

            <td>
                {safe(
                    visit.get("treatment")
                    or "-"
                )}
            </td>

        </tr>
        """

    if not visit_rows:

        visit_rows = """
        <tr>
            <td colspan="5">
                <div class="empty">
                    لا توجد زيارات مسجلة.
                </div>
            </td>
        </tr>
        """

    # --------------------------------------------------------
    # Appointment rows
    # --------------------------------------------------------

    appointment_rows = ""

    for appointment in appointments:

        appointment_date = (
            appointment.get("appointment_date")
            or appointment.get("date")
            or "-"
        )

        appointment_time = (
            appointment.get("appointment_time")
            or appointment.get("time")
            or "-"
        )

        status = (
            appointment.get("status")
            or "غير محدد"
        )

        appointment_rows += f"""
        <tr>

            <td>
                {safe(appointment_date)}
            </td>

            <td>
                {safe(appointment_time)}
            </td>

            <td>
                <span class="badge badge-blue">
                    {safe(status)}
                </span>
            </td>

        </tr>
        """

    if not appointment_rows:

        appointment_rows = """
        <tr>
            <td colspan="3">
                <div class="empty">
                    لا توجد مواعيد مسجلة.
                </div>
            </td>
        </tr>
        """

    # --------------------------------------------------------
    # Header buttons
    # --------------------------------------------------------

    edit_button = ""

    if can_manage:

        edit_button = f"""
        <a
            href="/patients/edit/{patient_id}"
            class="btn btn-secondary"
        >
            تعديل الملف
        </a>
        """

    appointment_button = ""

    if can_appointment:

        appointment_button = f"""
        <a
            href="/appointments/new?patient_id={patient_id}"
            class="btn btn-success"
        >
            + موعد
        </a>
        """

    visit_button = ""

    if can_visit:

        visit_button = f"""
        <a
            href="/patients/{patient_id}/visits/new"
            class="btn btn-primary"
        >
            + زيارة
        </a>
        """

    prescription_button = ""

    if can_visit:

        prescription_button = f"""
        <a
            href="/patients/{patient_id}/prescriptions/new"
            class="btn btn-warning"
        >
            + وصفة
        </a>
        """

    laboratory_button = ""

    if can_lab:

        laboratory_button = f"""
        <a
            href="/laboratory?patient_id={patient_id}"
            class="btn btn-light"
        >
            المختبر
        </a>
        """

    billing_button = ""

    if can_billing:

        billing_button = f"""
        <a
            href="/billing?patient_id={patient_id}"
            class="btn btn-light"
        >
            الفوترة
        </a>
        """

    # --------------------------------------------------------
    # Profile content
    # --------------------------------------------------------

    is_female = str(patient.get("gender") or "").strip().lower() in {"أنثى", "انثى", "female", "f", "female انثى", "female أنثى"}
    gynecology_button = f'<a href="/gynecology/patient/{patient_id}" class="btn btn-light">عيادة النساء</a>' if is_female else ""

    content = f"""

    <div class="header">

        <div class="brand">

            <div class="logo">
                C
            </div>

            <div>

                <h1>
                    ملف المريض
                </h1>

                <p>
                    CLINOVA — الملف الطبي للمريض
                </p>

            </div>

        </div>

        <div class="header-actions">

            <a
                href="/patients"
                class="btn btn-light"
            >
                ← المرضى
            </a>

            {edit_button}

        </div>

    </div>


    <div class="card">

        <div class="profile-header">

            <div>

                <div class="profile-name">
                    {safe(patient.get("full_name"))}
                </div>

                <div class="profile-meta">
                    الرقم الطبي:
                    <strong>
                        {safe(medical_number)}
                    </strong>
                </div>

                <div class="profile-meta">
                    رقم الملف:
                    <strong>
                        {safe(patient.get("file_number") or "-")}
                    </strong>
                </div>

            </div>

            <div class="actions">

                {appointment_button}

                {visit_button}

                {prescription_button}

                <a href="/pharmacy/orders?patient_id={patient_id}" class="btn btn-light">الصيدلية وسجل الصرف</a>

            </div>

        </div>

    </div>


    <div class="stats">

        <div class="stat">

            <div class="stat-title">
                الزيارات
            </div>

            <div class="stat-value">
                {len(visits)}
            </div>

        </div>

        <div class="stat">

            <div class="stat-title">
                المواعيد
            </div>

            <div class="stat-value">
                {len(appointments)}
            </div>

        </div>

        <div class="stat">

            <div class="stat-title">
                الوصفات
            </div>

            <div class="stat-value">
                {len(prescriptions)}
            </div>

        </div>

    </div>


    <div class="card">

        <div class="card-title">
            👤 المعلومات الأساسية
        </div>

        <div class="info-grid">

            <div class="info-item">

                <div class="info-label">
                    الاسم الكامل
                </div>

                <div class="info-value">
                    {safe(patient.get("full_name") or "-")}
                </div>

            </div>


            <div class="info-item">

                <div class="info-label">
                    الجنس
                </div>

                <div class="info-value">
                    {safe(patient.get("gender") or "-")}
                </div>

            </div>


            <div class="info-item">

                <div class="info-label">
                    تاريخ الميلاد
                </div>

                <div class="info-value">
                    {safe(patient.get("birth_date") or "-")}
                </div>

            </div>


            <div class="info-item">

                <div class="info-label">
                    الهاتف
                </div>

                <div class="info-value">
                    {safe(patient.get("phone") or "-")}
                </div>

            </div>


            <div class="info-item">

                <div class="info-label">
                    فصيلة الدم
                </div>

                <div class="info-value">
                    {safe(patient.get("blood_type") or "-")}
                </div>

            </div>


            <div class="info-item">

                <div class="info-label">
                    العنوان
                </div>

                <div class="info-value">
                    {safe(patient.get("address") or "-")}
                </div>

            </div>


            <div class="info-item">

                <div class="info-label">
                    الحساسية
                </div>

                <div class="info-value">
                    {safe(patient.get("allergies") or "-")}
                </div>

            </div>


            <div class="info-item">

                <div class="info-label">
                    الأمراض المزمنة
                </div>

                <div class="info-value">
                    {safe(patient.get("chronic_diseases") or "-")}
                </div>

            </div>


            <div class="info-item">

                <div class="info-label">
                    ملاحظات
                </div>

                <div class="info-value">
                    {safe(patient.get("notes") or "-")}
                </div>

            </div>

        </div>

    </div>


    <div class="card">

        <div class="card-title">
            🩺 الزيارات الطبية
        </div>

        <div class="table-wrapper">

            <table>

                <thead>

                    <tr>

                        <th>
                            التاريخ
                        </th>

                        <th>
                            الطبيب
                        </th>

                        <th>
                            الشكوى
                        </th>

                        <th>
                            التشخيص
                        </th>

                        <th>
                            العلاج
                        </th>

                    </tr>

                </thead>

                <tbody>

                    {visit_rows}

                </tbody>

            </table>

        </div>

    </div>


    <div class="card">

        <div class="card-title">
            📅 المواعيد
        </div>

        <div class="table-wrapper">

            <table>

                <thead>

                    <tr>

                        <th>
                            التاريخ
                        </th>

                        <th>
                            الوقت
                        </th>

                        <th>
                            الحالة
                        </th>

                    </tr>

                </thead>

                <tbody>

                    {appointment_rows}

                </tbody>

            </table>

        </div>

    </div>


    <div class="card">

        <div class="card-title">
            ⚙️ خدمات المريض
        </div>

        <div class="actions">

            {laboratory_button}

            {billing_button}

            {gynecology_button}

        </div>

    </div>

    """

    return HTMLResponse(
        render_page(
            "ملف المريض",
            content,
        )
    )


# ============================================================
# Edit Patient
# ============================================================

@router.get(
    "/patients/edit/{patient_id}",
    response_class=HTMLResponse,
)
def edit_patient_page(
    request: Request,
    patient_id: int,
    db: Session = Depends(get_db),
):

    if not can_manage_patients(request, db):
        return permission_denied()

    clinic_id = get_current_clinic_id(
        request,
        db,
    )

    params = {
        "patient_id": patient_id,
    }

    where = " WHERE id=:patient_id "

    if (
        clinic_id is not None
        and has_column(
            db,
            "patients",
            "clinic_id",
        )
    ):

        where += """
            AND clinic_id=:clinic_id
        """

        params["clinic_id"] = clinic_id

    patient = db.execute(
        text(
            f"""
            SELECT *
            FROM patients
            {where}
            LIMIT 1
            """
        ),
        params,
    ).mappings().first()

    if not patient:

        return HTMLResponse(
            render_page(
                "المريض غير موجود",
                """
                <div class="card">

                    <div class="alert alert-danger">
                        المريض غير موجود.
                    </div>

                    <a
                        href="/patients"
                        class="btn btn-primary"
                    >
                        العودة إلى المرضى
                    </a>

                </div>
                """
            ),
            status_code=404,
        )

    gender = patient.get("gender") or ""

    blood_type = patient.get("blood_type") or ""

    content = f"""

    <div class="header">

        <div class="brand">

            <div class="logo">
                C
            </div>

            <div>

                <h1>
                    تعديل ملف المريض
                </h1>

                <p>
                    {safe(patient.get("full_name"))}
                </p>

            </div>

        </div>

        <div class="header-actions">

            <a
                href="/patients/{patient_id}"
                class="btn btn-light"
            >
                ← ملف المريض
            </a>

        </div>

    </div>


    <div class="card">

        <form
            method="post"
            action="/patients/update/{patient_id}"
        >

            <div class="form-grid">

                <div class="form-group">

                    <label class="form-label">
                        الاسم الكامل *
                    </label>

                    <input
                        type="text"
                        name="full_name"
                        value="{safe(patient.get("full_name") or "")}"
                        required
                    />

                </div>


                <div class="form-group">

                    <label class="form-label">
                        الرقم الطبي
                    </label>

                    <input
                        type="text"
                        value="{safe(patient.get("medical_number") or "")}"
                        disabled
                    />

                </div>


                <div class="form-group">

                    <label class="form-label">
                        رقم الملف
                    </label>

                    <input
                        type="text"
                        name="file_number"
                        value="{safe(patient.get("file_number") or "")}"
                    />

                </div>


                <div class="form-group">

                    <label class="form-label">
                        الجنس
                    </label>

                    <select name="gender">

                        <option value="">
                            اختر الجنس
                        </option>

                        <option
                            value="ذكر"
                            {"selected" if gender == "ذكر" else ""}
                        >
                            ذكر
                        </option>

                        <option
                            value="أنثى"
                            {"selected" if gender == "أنثى" else ""}
                        >
                            أنثى
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label class="form-label">
                        تاريخ الميلاد
                    </label>

                    <input
                        type="date"
                        name="birth_date"
                        value="{safe(patient.get("birth_date") or "")}"
                    />

                </div>


                <div class="form-group">

                    <label class="form-label">
                        رقم الهاتف
                    </label>

                    <input
                        type="text"
                        name="phone"
                        value="{safe(patient.get("phone") or "")}"
                    />

                </div>


                <div class="form-group">

                    <label class="form-label">
                        فصيلة الدم
                    </label>

                    <select name="blood_type">

                        <option value="">
                            غير محدد
                        </option>

                        <option value="A+" {"selected" if blood_type == "A+" else ""}>
                            A+
                        </option>

                        <option value="A-" {"selected" if blood_type == "A-" else ""}>
                            A-
                        </option>

                        <option value="B+" {"selected" if blood_type == "B+" else ""}>
                            B+
                        </option>

                        <option value="B-" {"selected" if blood_type == "B-" else ""}>
                            B-
                        </option>

                        <option value="AB+" {"selected" if blood_type == "AB+" else ""}>
                            AB+
                        </option>

                        <option value="AB-" {"selected" if blood_type == "AB-" else ""}>
                            AB-
                        </option>

                        <option value="O+" {"selected" if blood_type == "O+" else ""}>
                            O+
                        </option>

                        <option value="O-" {"selected" if blood_type == "O-" else ""}>
                            O-
                        </option>

                    </select>

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        العنوان
                    </label>

                    <input
                        type="text"
                        name="address"
                        value="{safe(patient.get("address") or "")}"
                    />

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        الحساسية
                    </label>

                    <textarea
                        name="allergies"
                    >{safe(patient.get("allergies") or "")}</textarea>

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        الأمراض المزمنة
                    </label>

                    <textarea
                        name="chronic_diseases"
                    >{safe(patient.get("chronic_diseases") or "")}</textarea>

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        ملاحظات
                    </label>

                    <textarea
                        name="notes"
                    >{safe(patient.get("notes") or "")}</textarea>

                </div>

            </div>


            <div class="form-actions">

                <button
                    type="submit"
                    class="btn btn-success"
                >
                    حفظ التعديلات
                </button>

                <a
                    href="/patients/{patient_id}"
                    class="btn btn-light"
                >
                    إلغاء
                </a>

            </div>

        </form>

    </div>

    """

    return HTMLResponse(
        render_page(
            "تعديل المريض",
            content,
        )
    )


# ============================================================
# Update Patient
# ============================================================

@router.post("/patients/update/{patient_id}")
def update_patient(
    request: Request,
    patient_id: int,

    full_name: str = Form(...),
    gender: str = Form(default=""),
    birth_date: str = Form(default=""),
    phone: str = Form(default=""),
    address: str = Form(default=""),
    blood_type: str = Form(default=""),
    allergies: str = Form(default=""),
    chronic_diseases: str = Form(default=""),
    notes: str = Form(default=""),
    file_number: str = Form(default=""),

    db: Session = Depends(get_db),
):

    full_name = required_name(full_name, "اسم المريض")
    birth_date = calendar_date(birth_date, "تاريخ الميلاد", allow_future=False)

    if not can_manage_patients(request, db):
        return permission_denied()

    full_name = (full_name or "").strip()

    if not full_name:

        return HTMLResponse(
            render_page(
                "خطأ",
                """
                <div class="card">

                    <div class="alert alert-danger">
                        يجب إدخال اسم المريض.
                    </div>

                    <a
                        href="/patients"
                        class="btn btn-primary"
                    >
                        العودة
                    </a>

                </div>
                """
            ),
            status_code=400,
        )

    clinic_id = get_current_clinic_id(
        request,
        db,
    )

    params = {
        "patient_id": patient_id,
    }

    where = " WHERE id=:patient_id "

    if (
        clinic_id is not None
        and has_column(
            db,
            "patients",
            "clinic_id",
        )
    ):

        where += """
            AND clinic_id=:clinic_id
        """

        params["clinic_id"] = clinic_id

    existing = db.execute(
        text(
            f"""
            SELECT id
            FROM patients
            {where}
            LIMIT 1
            """
        ),
        params,
    ).fetchone()

    if not existing:

        return HTMLResponse(
            render_page(
                "المريض غير موجود",
                """
                <div class="card">

                    <div class="alert alert-danger">
                        المريض غير موجود أو لا ينتمي إلى العيادة الحالية.
                    </div>

                    <a
                        href="/patients"
                        class="btn btn-primary"
                    >
                        العودة إلى المرضى
                    </a>

                </div>
                """
            ),
            status_code=404,
        )

    # --------------------------------------------------------
    # Dynamic UPDATE
    # --------------------------------------------------------

    fields = [
        "full_name=:full_name",
        "gender=:gender",
        "birth_date=:birth_date",
        "phone=:phone",
        "address=:address",
        "blood_type=:blood_type",
        "allergies=:allergies",
        "chronic_diseases=:chronic_diseases",
        "notes=:notes",
    ]

    update_params = {
        "patient_id": patient_id,
        "full_name": full_name,
        "gender": gender.strip() or None,
        "birth_date": normalize_date(
            birth_date
        ),
        "phone": phone.strip() or None,
        "address": address.strip() or None,
        "blood_type": blood_type.strip() or None,
        "allergies": allergies.strip() or None,
        "chronic_diseases": (
            chronic_diseases.strip()
            or None
        ),
        "notes": notes.strip() or None,
    }

    if has_column(
        db,
        "patients",
        "file_number",
    ):

        fields.append(
            "file_number=:file_number"
        )

        update_params["file_number"] = (
            file_number.strip()
            or None
        )

    try:

        query = f"""
            UPDATE patients
            SET {", ".join(fields)}
            WHERE id=:patient_id
        """

        if (
            clinic_id is not None
            and has_column(
                db,
                "patients",
                "clinic_id",
            )
        ):

            query += """
                AND clinic_id=:clinic_id
            """

            update_params["clinic_id"] = clinic_id

        db.execute(
            text(query),
            update_params,
        )

        db.commit()

        return RedirectResponse(
            url=f"/patients/{patient_id}",
            status_code=303,
        )

    except Exception as e:

        db.rollback()

        content = f"""

        <div class="card">

            <div class="alert alert-danger">

                تعذر تحديث بيانات المريض.

                <br><br>

                {safe(e)}

            </div>

            <a
                href="/patients/{patient_id}"
                class="btn btn-primary"
            >
                العودة إلى الملف
            </a>

        </div>

        """

        return HTMLResponse(
            render_page(
                "خطأ في التحديث",
                content,
            ),
            status_code=500,
        )


# ============================================================
# Delete Patient
# ============================================================

@router.post(
    "/patients/delete/{patient_id}"
)
def delete_patient(
    request: Request,
    patient_id: int,
    db: Session = Depends(get_db),
):

    protect_referenced_record(db, [(name, "patient_id") for name in ("visits", "prescriptions", "pregnancies", "family_planning", "laboratory_orders", "radiology_requests", "invoices", "appointments", "pharmacy_orders")], patient_id)

    if not can_manage_patients(request, db):
        return permission_denied()

    clinic_id = get_current_clinic_id(
        request,
        db,
    )

    params = {
        "patient_id": patient_id,
    }

    where = """
        WHERE id=:patient_id
    """

    if (
        clinic_id is not None
        and has_column(
            db,
            "patients",
            "clinic_id",
        )
    ):

        where += """
            AND clinic_id=:clinic_id
        """

        params["clinic_id"] = clinic_id

    patient = db.execute(
        text(
            f"""
            SELECT id
            FROM patients
            {where}
            LIMIT 1
            """
        ),
        params,
    ).fetchone()

    if not patient:

        return RedirectResponse(
            url="/patients",
            status_code=303,
        )

    try:

        # ----------------------------------------------------
        # Delete visits
        # ----------------------------------------------------

        if table_exists(
            db,
            "visits",
        ):

            visit_params = {
                "patient_id": patient_id
            }

            visit_where = """
                WHERE patient_id=:patient_id
            """

            if (
                clinic_id is not None
                and has_column(
                    db,
                    "visits",
                    "clinic_id",
                )
            ):

                visit_where += """
                    AND clinic_id=:clinic_id
                """

                visit_params["clinic_id"] = clinic_id

            db.execute(
                text(
                    f"""
                    DELETE FROM visits
                    {visit_where}
                    """
                ),
                visit_params,
            )

        # ----------------------------------------------------
        # Delete patient
        # ----------------------------------------------------

        db.execute(
            text(
                f"""
                DELETE FROM patients
                {where}
                """
            ),
            params,
        )

        db.commit()

        return RedirectResponse(
            url="/patients",
            status_code=303,
        )

    except Exception:

        db.rollback()

        return RedirectResponse(
            url=f"/patients/{patient_id}",
            status_code=303,
        )


# ============================================================
# New Visit
# ============================================================

@router.get(
    "/patients/{patient_id}/visits/new",
    response_class=HTMLResponse,
)
def new_visit_page(
    request: Request,
    patient_id: int,
    db: Session = Depends(get_db),
):

    if not can_manage_visits(request, db):
        return permission_denied()

    clinic_id = get_current_clinic_id(
        request,
        db,
    )

    params = {
        "patient_id": patient_id,
    }

    where = """
        WHERE id=:patient_id
    """

    if (
        clinic_id is not None
        and has_column(
            db,
            "patients",
            "clinic_id",
        )
    ):

        where += """
            AND clinic_id=:clinic_id
        """

        params["clinic_id"] = clinic_id

    patient = db.execute(
        text(
            f"""
            SELECT *
            FROM patients
            {where}
            LIMIT 1
            """
        ),
        params,
    ).mappings().first()

    if not patient:

        return HTMLResponse(
            render_page(
                "المريض غير موجود",
                """
                <div class="card">

                    <div class="alert alert-danger">
                        المريض غير موجود.
                    </div>

                    <a
                        href="/patients"
                        class="btn btn-primary"
                    >
                        العودة إلى المرضى
                    </a>

                </div>
                """
            ),
            status_code=404,
        )

    # --------------------------------------------------------
    # Doctors
    # --------------------------------------------------------

    doctors = []

    if table_exists(
        db,
        "doctors",
    ):

        try:

            doctors = db.execute(
                tenant_text("SELECT * FROM doctors WHERE clinic_id=:active_clinic_id ORDER BY id DESC")
            ).mappings().all()

        except Exception:
            doctors = []

    doctor_options = """
        <option value="">
            اختر الطبيب
        </option>
    """

    for doctor in doctors:

        doctor_name = (
            doctor.get("full_name")
            or doctor.get("name")
            or doctor.get("doctor_name")
            or "-"
        )

        doctor_id = doctor.get("id")

        doctor_options += f"""
        <option value="{safe(doctor_id)}">
            {safe(doctor_name)}
        </option>
        """

    content = f"""

    <div class="header">

        <div class="brand">

            <div class="logo">
                C
            </div>

            <div>

                <h1>
                    إضافة زيارة
                </h1>

                <p>
                    {safe(patient.get("full_name"))}
                </p>

            </div>

        </div>

        <div class="header-actions">

            <a
                href="/patients/{patient_id}"
                class="btn btn-light"
            >
                ← ملف المريض
            </a>

        </div>

    </div>


    <div class="card">

        <form
            method="post"
            action="/patients/{patient_id}/visits/add"
        >

            <div class="form-grid">

                <div class="form-group">

                    <label class="form-label">
                        الطبيب
                    </label>

                    <select name="doctor_id">
                        {doctor_options}
                    </select>

                </div>


                <div class="form-group">

                    <label class="form-label">
                        تاريخ الزيارة
                    </label>

                    <input
                        type="date"
                        name="visit_date"
                        value="{today()}"
                    />

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        الشكوى الرئيسية
                    </label>

                    <textarea
                        name="chief_complaint"
                        placeholder="الشكوى الرئيسية للمريض"
                    ></textarea>

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        التشخيص
                    </label>

                    <textarea
                        name="diagnosis"
                        placeholder="التشخيص الطبي"
                    ></textarea>

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        العلاج
                    </label>

                    <textarea
                        name="treatment"
                        placeholder="الخطة العلاجية"
                    ></textarea>

                </div>


                <div class="form-group">

                    <label class="form-label">
                        ضغط الدم
                    </label>

                    <input
                        type="text"
                        name="blood_pressure"
                        placeholder="120/80"
                    />

                </div>


                <div class="form-group">

                    <label class="form-label">
                        الحرارة
                    </label>

                    <input
                        type="text"
                        name="temperature"
                        placeholder="36.5"
                    />

                </div>


                <div class="form-group">

                    <label class="form-label">
                        الوزن
                    </label>

                    <input
                        type="text"
                        name="weight"
                        placeholder="الوزن"
                    />

                </div>


                <div class="form-group full">

                    <label class="form-label">
                        ملاحظات الطبيب
                    </label>

                    <textarea
                        name="notes"
                        placeholder="ملاحظات إضافية"
                    ></textarea>

                </div>

            </div>


            <div class="form-actions">

                <button
                    type="submit"
                    class="btn btn-success"
                >
                    حفظ الزيارة
                </button>

                <a
                    href="/patients/{patient_id}"
                    class="btn btn-light"
                >
                    إلغاء
                </a>

            </div>

        </form>

    </div>

    """

    return HTMLResponse(
        render_page(
            "إضافة زيارة",
            content,
        )
    )


# ============================================================
# Add Visit
# ============================================================

@router.post(
    "/patients/{patient_id}/visits/add"
)
def add_visit(
    request: Request,
    patient_id: int,

    doctor_id: str = Form(default=""),
    visit_date: str = Form(default=""),
    chief_complaint: str = Form(default=""),
    diagnosis: str = Form(default=""),
    treatment: str = Form(default=""),
    blood_pressure: str = Form(default=""),
    temperature: str = Form(default=""),
    weight: str = Form(default=""),
    notes: str = Form(default=""),

    db: Session = Depends(get_db),
):

    if not can_manage_visits(request, db):
        return permission_denied()

    clinic_id = get_current_clinic_id(
        request,
        db,
    )

    # --------------------------------------------------------
    # Validate patient
    # --------------------------------------------------------

    patient_params = {
        "patient_id": patient_id,
    }

    patient_where = """
        WHERE id=:patient_id
    """

    if (
        clinic_id is not None
        and has_column(
            db,
            "patients",
            "clinic_id",
        )
    ):

        patient_where += """
            AND clinic_id=:clinic_id
        """

        patient_params["clinic_id"] = clinic_id

    patient = db.execute(
        text(
            f"""
            SELECT id
            FROM patients
            {patient_where}
            LIMIT 1
            """
        ),
        patient_params,
    ).fetchone()

    if not patient:

        return HTMLResponse(
            render_page(
                "المريض غير موجود",
                """
                <div class="card">

                    <div class="alert alert-danger">
                        المريض غير موجود أو لا ينتمي إلى العيادة الحالية.
                    </div>

                    <a
                        href="/patients"
                        class="btn btn-primary"
                    >
                        العودة إلى المرضى
                    </a>

                </div>
                """
            ),
            status_code=404,
        )

    # --------------------------------------------------------
    # Visits table
    # --------------------------------------------------------

    if not table_exists(
        db,
        "visits",
    ):

        return HTMLResponse(
            render_page(
                "الزيارات",
                """
                <div class="card">

                    <div class="alert alert-danger">
                        جدول الزيارات غير موجود في قاعدة البيانات.
                    </div>

                </div>
                """
            ),
            status_code=500,
        )

    # --------------------------------------------------------
    # Dynamic INSERT
    # --------------------------------------------------------

    columns = [
        "patient_id"
    ]

    values = [
        ":patient_id"
    ]

    params = {
        "patient_id": patient_id
    }

    # --------------------------------------------------------
    # visit_date
    # --------------------------------------------------------

    if has_column(
        db,
        "visits",
        "visit_date",
    ):

        columns.append(
            "visit_date"
        )

        values.append(
            ":visit_date"
        )

        params["visit_date"] = (
            normalize_date(visit_date)
            or today()
        )

    # --------------------------------------------------------
    # Optional fields
    # --------------------------------------------------------

    optional_fields = {
        "doctor_id": doctor_id,
        "chief_complaint": chief_complaint,
        "diagnosis": diagnosis,
        "treatment": treatment,
        "blood_pressure": blood_pressure,
        "temperature": temperature,
        "weight": weight,
        "notes": notes,
    }

    for column, value in optional_fields.items():

        if has_column(
            db,
            "visits",
            column,
        ):

            columns.append(column)

            values.append(
                f":{column}"
            )

            params[column] = (
                value.strip()
                if isinstance(value, str)
                else value
            ) or None

    # --------------------------------------------------------
    # clinic_id
    # --------------------------------------------------------

    if (
        clinic_id is not None
        and has_column(
            db,
            "visits",
            "clinic_id",
        )
    ):

        columns.append(
            "clinic_id"
        )

        values.append(
            ":clinic_id"
        )

        params["clinic_id"] = clinic_id

    # --------------------------------------------------------
    # created_at
    # --------------------------------------------------------

    if has_column(
        db,
        "visits",
        "created_at",
    ):

        columns.append(
            "created_at"
        )

        values.append(
            ":created_at"
        )

        params["created_at"] = now()

    # --------------------------------------------------------
    # Insert
    # --------------------------------------------------------

    try:

        query = f"""
            INSERT INTO visits
            ({", ".join(columns)})
            VALUES
            ({", ".join(values)})
        """

        db.execute(
            text(query),
            params,
        )

        db.commit()

        return RedirectResponse(
            url=f"/patients/{patient_id}",
            status_code=303,
        )

    except Exception as e:

        db.rollback()

        content = f"""

        <div class="card">

            <div class="alert alert-danger">

                تعذر حفظ الزيارة.

                <br><br>

                {safe(e)}

            </div>

            <a
                href="/patients/{patient_id}/visits/new"
                class="btn btn-primary"
            >
                العودة
            </a>

        </div>

        """

        return HTMLResponse(
            render_page(
                "خطأ في حفظ الزيارة",
                content,
            ),
            status_code=500,
        )


# ============================================================
# Prescription Compatibility Route
# ============================================================

@router.get("/patients/{patient_id}/visits/{visit_id}")
def patient_visit_compatibility(patient_id: int, visit_id: int):
    # Router authorization validates both ownership and the patient/visit pair.
    return RedirectResponse(f"/visits/{visit_id}", status_code=303)

@router.get(
    "/patients/{patient_id}/prescriptions/new",
    response_class=HTMLResponse,
)
def patient_prescription_redirect(request: Request, patient_id: int, db: Session = Depends(get_db)):
    return RedirectResponse(url=f"/pharmacy/prescriptions/new?patient_id={patient_id}", status_code=303)
